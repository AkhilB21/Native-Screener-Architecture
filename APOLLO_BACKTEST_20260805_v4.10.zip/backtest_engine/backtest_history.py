"""Apollo Backtest Studio — SQLite History Manager.

Provides persistent storage for backtest runs using SQLite.
Each backtest run is saved with its parameters and complete results,
enabling historical comparison and parameter optimization workflows.
"""

from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Any


# =====================================================================
# Configuration
# =====================================================================

DEFAULT_DB_PATH = Path(__file__).parent / "data" / "backtest_history.db"

# Maximum number of trade events to store per stock per run
# (Set to 0 or None to store ALL events — may be large!)
MAX_TRADE_EVENTS_PER_STOCK = 500


# =====================================================================
# Database Connection Manager
# =====================================================================

class BacktestHistory:
    """Manages SQLite persistence for backtest results."""
    
    def __init__(self, db_path: str | Path = DEFAULT_DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._init_db()
    
    @property
    def conn(self) -> sqlite3.Connection:
        """Lazy connection initialization."""
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            # Enable foreign keys
            self._conn.execute("PRAGMA foreign_keys = ON")
        return self._conn
    
    def close(self):
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False
    
    # -----------------------------------------------------------------
    # Schema Initialization
    # -----------------------------------------------------------------
    
    def _init_db(self):
        """Create tables if they don't exist."""
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.executescript("""
                -- Runs table
                CREATE TABLE IF NOT EXISTS runs (
                    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    start_date TEXT NOT NULL,
                    end_date TEXT NOT NULL,
                    entry_threshold INTEGER NOT NULL,
                    exit_threshold INTEGER NOT NULL,
                    exit_mode TEXT NOT NULL,
                    sl_percent REAL NOT NULL,
                    divergence_rsi_drop REAL NOT NULL,
                    divergence_cooldown INTEGER NOT NULL,
                    total_stocks INTEGER DEFAULT 0,
                    total_trades INTEGER DEFAULT 0,
                    total_entries INTEGER DEFAULT 0,
                    winning_trades INTEGER DEFAULT 0,
                    losing_trades INTEGER DEFAULT 0,
                    win_rate REAL DEFAULT 0.0,
                    avg_pnl_per_trade REAL DEFAULT 0.0,
                    total_cumulative_pnl REAL DEFAULT 0.0,
                    avg_max_drawdown REAL DEFAULT 0.0,
                    worst_max_drawdown REAL DEFAULT 0.0,
                    duration_seconds REAL DEFAULT 0.0,
                    failed_count INTEGER DEFAULT 0,
                    notes TEXT DEFAULT '',
                    is_bookmarked INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'completed'
                );
                
                -- Stock results table
                CREATE TABLE IF NOT EXISTS stock_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    symbol TEXT NOT NULL,
                    sector TEXT DEFAULT '',
                    n_trades INTEGER DEFAULT 0,
                    n_entries INTEGER DEFAULT 0,
                    n_completed INTEGER DEFAULT 0,
                    win_rate REAL DEFAULT 0.0,
                    cum_pnl REAL DEFAULT 0.0,
                    avg_pnl_per_trade REAL DEFAULT 0.0,
                    max_drawdown REAL DEFAULT 0.0,
                    avg_score REAL DEFAULT 0.0,
                    peak_score REAL DEFAULT 0.0,
                    n_days INTEGER DEFAULT 0,
                    sl_exits INTEGER DEFAULT 0,
                    div_exits INTEGER DEFAULT 0,
                    score_exits INTEGER DEFAULT 0,
                    period_end_exits INTEGER DEFAULT 0,
                    FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );
                
                -- Trade events table
                CREATE TABLE IF NOT EXISTS trade_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    symbol TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    date TEXT NOT NULL,
                    close_price REAL,
                    score REAL,
                    classification TEXT,
                    pool_a REAL,
                    pool_b REAL,
                    pool_c REAL,
                    bonus REAL,
                    entry_price REAL,
                    pnl_percentage REAL,
                    exit_reason TEXT,
                    bars_from_trough INTEGER,
                    FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );
                
                -- Indexes
                CREATE INDEX IF NOT EXISTS idx_stock_results_run_id 
                    ON stock_results(run_id);
                CREATE INDEX IF NOT EXISTS idx_stock_results_symbol 
                    ON stock_results(symbol);
                CREATE INDEX IF NOT EXISTS idx_trade_events_run_id 
                    ON trade_events(run_id);
                CREATE INDEX IF NOT EXISTS idx_trade_events_symbol 
                    ON trade_events(symbol);
                CREATE INDEX IF NOT EXISTS idx_trade_events_type 
                    ON trade_events(event_type);
            """)
    
    # -----------------------------------------------------------------
    # SAVE OPERATIONS
    # -----------------------------------------------------------------
    
    def save_backtest_run(
        self,
        results: list[dict],
        params: dict,
        duration_seconds: float = 0.0,
        failed_stocks: list[dict] | None = None,
        status: str = "completed",
    ) -> int:
        """
        Save a complete backtest run to the database.
        
        Parameters
        ----------
        results : list[dict]
            List of per-stock result dicts from run_stock_backtest()
        params : dict
            Strategy parameters used for this run
        duration_seconds : float
            How long the backtest took to run
        failed_stocks : list[dict]
            Stocks that failed during processing
        status : str
            'completed', 'stopped', or 'error'
        
        Returns
        -------
        int — The run_id of the newly created run
        """
        # Generate unique run name
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_name = f"BT_{timestamp}"
        
        # Compute aggregate metrics
        aggregates = self._compute_aggregates(results, failed_stocks)
        
        # Insert into runs table
        cursor = self.conn.execute(
            """
            INSERT INTO runs (
                run_name, created_at,
                start_date, end_date,
                entry_threshold, exit_threshold,
                exit_mode, sl_percent,
                divergence_rsi_drop, divergence_cooldown,
                total_stocks, total_trades, total_entries,
                winning_trades, losing_trades,
                win_rate, avg_pnl_per_trade,
                total_cumulative_pnl, avg_max_drawdown,
                worst_max_drawdown, duration_seconds,
                failed_count, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_name,
                datetime.now().isoformat(),
                params.get("start_date", ""),
                params.get("end_date", ""),
                params.get("entry_threshold", 70),
                params.get("exit_threshold", 50),
                params.get("exit_mode", "NONE"),
                params.get("sl_percent", 0.0),
                params.get("divergence_rsi_drop", 3.0),
                params.get("divergence_cooldown", 5),
                aggregates["total_stocks"],
                aggregates["total_trades"],
                aggregates["total_entries"],
                aggregates["winning_trades"],
                aggregates["losing_trades"],
                aggregates["win_rate"],
                aggregates["avg_pnl_per_trade"],
                aggregates["total_cumulative_pnl"],
                aggregates["avg_max_drawdown"],
                aggregates["worst_max_drawdown"],
                duration_seconds,
                aggregates["failed_count"],
                status,
            ),
        )
        run_id = cursor.lastrowid
        
        # Insert per-stock results
        for r in results:
            self._save_stock_result(run_id, r)
            
            # Save trade events (with limit to prevent bloat)
            trades = r.get("trades", [])
            if MAX_TRADE_EVENTS_PER_STOCK and len(trades) > MAX_TRADE_EVENTS_PER_STOCK:
                # Keep ENTRY and EXIT events, sample HOLD events
                critical = [t for t in trades if t.get("type") in ("ENTRY", "EXIT")]
                holds = [t for t in trades if t.get("type") not in ("ENTRY", "EXIT")]
                # Sample holds evenly
                step = max(1, len(holds) // (MAX_TRADE_EVENTS_PER_STOCK - len(critical)))
                sampled_holds = holds[::step][:MAX_TRADE_EVENTS_PER_STOCK - len(critical)]
                trades = critical + sampled_holds
            
            for trade in trades:
                self._save_trade_event(run_id, r.get("symbol", ""), trade)
        
        self.conn.commit()
        return run_id
    
    def _save_stock_result(self, run_id: int, result: dict):
        """Save a single stock's result."""
        # Compute avg_score and peak_score from trades
        trades = result.get("trades", [])
        scores = [e.get("score", 0) for e in trades if e.get("score") is not None]
        avg_sc = round(sum(scores) / len(scores), 2) if scores else 0.0
        peak_sc = round(max(scores), 2) if scores else 0.0
        
        self.conn.execute(
            """
            INSERT INTO stock_results (
                run_id, symbol, sector,
                n_trades, n_entries, n_completed,
                win_rate, cum_pnl, avg_pnl_per_trade,
                max_drawdown, avg_score, peak_score, n_days,
                sl_exits, div_exits, score_exits, period_end_exits
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                result.get("symbol", ""),
                result.get("sector", ""),
                result.get("n_trades", 0),
                len(result.get("entries", [])),
                len(result.get("completed", [])),
                result.get("win_rate", 0.0),
                result.get("cum_pnl", 0.0),
                result.get("avg_pnl_per_trade", 0.0),
                result.get("max_drawdown", 0.0),
                avg_sc,
                peak_sc,
                result.get("n_days", 0),
                len(result.get("sl_exits", [])),
                len(result.get("div_exits", [])),
                len(result.get("score_exits", [])),
                len(result.get("period_end_exits", [])),
            ),
        )
    
    def _save_trade_event(self, run_id: int, symbol: str, event: dict):
        """Save a single trade event."""
        self.conn.execute(
            """
            INSERT INTO trade_events (
                run_id, symbol, event_type, date,
                close_price, score, classification,
                pool_a, pool_b, pool_c, bonus,
                entry_price, pnl_percentage, exit_reason,
                bars_from_trough
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                symbol,
                event.get("type", ""),
                str(event.get("date", "")),
                event.get("close"),
                event.get("score"),
                event.get("classification"),
                event.get("pool_a"),
                event.get("pool_b"),
                event.get("pool_c"),
                event.get("bonus"),
                event.get("entry_price"),
                event.get("pnl"),
                event.get("exit_reason"),
                event.get("bars_from_trough"),
            ),
        )
    
    def _compute_aggregates(self, results: list[dict], failed: list[dict] | None) -> dict:
        """Compute portfolio-level aggregate metrics."""
        all_completed = []
        for r in results:
            all_completed.extend(r.get("completed", []))
        
        winning = [e for e in all_completed if e.get("pnl", 0) > 0]
        losing = [e for e in all_completed if e.get("pnl", 0) <= 0]
        
        total_trades = sum(r.get("n_trades", 0) for r in results)
        total_entries = sum(len(r.get("entries", [])) for r in results)
        
        win_rate = (len(winning) / len(all_completed) * 100) if all_completed else 0.0
        
        stocks_with_trades = [r for r in results if r.get("n_trades", 0) > 0]
        avg_pnl = (
            sum(r.get("avg_pnl_per_trade", 0) for r in stocks_with_trades) /
            max(1, len(stocks_with_trades))
        )
        
        max_dd_vals = [
            r.get("max_drawdown", 0) for r in results
            if r.get("max_drawdown", 0) != 0.0
        ]
        avg_dd = sum(max_dd_vals) / len(max_dd_vals) if max_dd_vals else 0.0
        worst_dd = min(max_dd_vals) if max_dd_vals else 0.0
        
        return {
            "total_stocks": len(results),
            "total_trades": total_trades,
            "total_entries": total_entries,
            "winning_trades": len(winning),
            "losing_trades": len(losing),
            "win_rate": round(win_rate, 2),
            "avg_pnl_per_trade": round(avg_pnl, 2),
            "total_cumulative_pnl": round(sum(r.get("cum_pnl", 0) for r in results), 2),
            "avg_max_drawdown": round(avg_dd, 2),
            "worst_max_drawdown": round(worst_dd, 2),
            "failed_count": len(failed) if failed else 0,
        }
    
    # -----------------------------------------------------------------
    # RETRIEVE OPERATIONS
    # -----------------------------------------------------------------
    
    def get_all_runs(
        self,
        limit: int = 50,
        offset: int = 0,
        order_by: str = "created_at",
        descending: bool = True,
    ) -> list[dict]:
        """
        Get list of all backtest runs (metadata only).
        
        Returns
        -------
        list[dict] — Each dict contains run metadata + aggregates
        """
        direction = "DESC" if descending else "ASC"
        
        # Validate order_by to prevent SQL injection
        valid_columns = {
            "created_at", "run_name", "total_cumulative_pnl",
            "win_rate", "total_trades", "duration_seconds"
        }
        col = order_by if order_by in valid_columns else "created_at"
        
        rows = self.conn.execute(
            f"""
            SELECT * FROM runs 
            ORDER BY {col} {direction}
            LIMIT ? OFFSET ?
            """,
            (limit, offset),
        ).fetchall()
        
        return [dict(row) for row in rows]
    
    def get_run(self, run_id: int) -> dict | None:
        """Get a single run's metadata by ID."""
        row = self.conn.execute(
            "SELECT * FROM runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        return dict(row) if row else None
    
    def get_stock_results(self, run_id: int) -> list[dict]:
        """Get all stock results for a specific run."""
        rows = self.conn.execute(
            "SELECT * FROM stock_results WHERE run_id = ? ORDER BY cum_pnl DESC",
            (run_id,),
        ).fetchall()
        return [dict(row) for row in rows]
    
    def get_trade_events(
        self,
        run_id: int,
        symbol: str | None = None,
        event_types: list[str] | None = None,
    ) -> list[dict]:
        """
        Get trade events for a run, optionally filtered by stock or type.
        """
        query = "SELECT * FROM trade_events WHERE run_id = ?"
        params: list[Any] = [run_id]
        
        if symbol:
            query += " AND UPPER(symbol) = UPPER(?)"
            params.append(symbol)
        
        if event_types:
            placeholders = ",".join("?" * len(event_types))
            query += f" AND event_type IN ({placeholders})"
            params.extend(event_types)
        
        query += " ORDER BY symbol, date"
        
        rows = self.conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]
    
    def get_run_comparison(self, run_ids: list[int]) -> list[dict]:
        """
        Get comparison data for multiple runs (aggregate metrics only).
        Useful for side-by-side parameter comparison.
        """
        placeholders = ",".join("?" * len(run_ids))
        rows = self.conn.execute(
            f"""
            SELECT run_id, run_name, created_at,
                   entry_threshold, exit_threshold, exit_mode, sl_percent,
                   total_stocks, total_trades, win_rate,
                   total_cumulative_pnl, avg_pnl_per_trade,
                   avg_max_drawdown, worst_max_drawdown,
                   duration_seconds
            FROM runs 
            WHERE run_id IN ({placeholders})
            ORDER BY created_at
            """,
            run_ids,
        ).fetchall()
        return [dict(row) for row in rows]
    
    # -----------------------------------------------------------------
    # UPDATE/DELETE OPERATIONS
    # -----------------------------------------------------------------
    
    def update_notes(self, run_id: int, notes: str):
        """Add/edit user notes for a run."""
        self.conn.execute(
            "UPDATE runs SET notes = ? WHERE run_id = ?",
            (notes, run_id),
        )
        self.conn.commit()
    
    def toggle_bookmark(self, run_id: int) -> bool:
        """Toggle bookmark status. Returns new bookmark state."""
        run = self.get_run(run_id)
        if not run:
            return False
        new_state = 0 if run["is_bookmarked"] else 1
        self.conn.execute(
            "UPDATE runs SET is_bookmarked = ? WHERE run_id = ?",
            (new_state, run_id),
        )
        self.conn.commit()
        return bool(new_state)
    
    def delete_run(self, run_id: int) -> bool:
        """
        Delete a run and all its associated data (stock_results, trade_events).
        Uses CASCADE delete.
        """
        result = self.conn.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
        self.conn.commit()
        return result.rowcount > 0
    
    def delete_multiple_runs(self, run_ids: list[int]) -> int:
        """Delete multiple runs at once. Returns count deleted."""
        placeholders = ",".join("?" * len(run_ids))
        result = self.conn.execute(
            f"DELETE FROM runs WHERE run_id IN ({placeholders})",
            run_ids,
        )
        self.conn.commit()
        return result.rowcount
    
    def delete_old_runs(self, keep_latest: int = 20) -> int:
        """
        Delete old runs, keeping only the N most recent.
        Useful for cleanup when too many accumulate.
        
        Returns
        -------
        int — Number of runs deleted
        """
        # Get IDs of runs to keep
        keep_rows = self.conn.execute(
            "SELECT run_id FROM runs ORDER BY created_at DESC LIMIT ?",
            (keep_latest,),
        ).fetchall()
        keep_ids = {row["run_id"] for row in keep_rows}
        
        # Delete everything else
        all_rows = self.conn.execute("SELECT run_id FROM runs").fetchall()
        delete_ids = [row["run_id"] for row in all_rows if row["run_id"] not in keep_ids]
        
        if delete_ids:
            return self.delete_multiple_runs(delete_ids)
        return 0
    
    # -----------------------------------------------------------------
    # UTILITY METHODS
    # -----------------------------------------------------------------
    
    def get_stats(self) -> dict:
        """Get database statistics."""
        total_runs = self.conn.execute("SELECT COUNT(*) as c FROM runs").fetchone()["c"]
        total_stocks = self.conn.execute("SELECT COUNT(*) as c FROM stock_results").fetchone()["c"]
        total_events = self.conn.execute("SELECT COUNT(*) as c FROM trade_events").fetchone()["c"]
        
        db_size_mb = self.db_path.stat().st_size / (1024 * 1024)
        
        latest_run = self.conn.execute(
            "SELECT created_at FROM runs ORDER BY created_at DESC LIMIT 1"
        ).fetchone()
        
        return {
            "total_runs": total_runs,
            "total_stocks": total_stocks,
            "total_events": total_events,
            "db_size_mb": round(db_size_mb, 2),
            "latest_run": latest_run["created_at"] if latest_run else "Never",
        }
    
    def export_run_to_dict(self, run_id: int) -> dict:
        """
        Export a complete run's data as a dictionary (for JSON export).
        Includes metadata, stock results, and trade events.
        """
        run = self.get_run(run_id)
        if not run:
            return {}
        
        stocks = self.get_stock_results(run_id)
        trades = self.get_trade_events(run_id)
        
        return {
            "metadata": run,
            "stock_results": stocks,
            "trade_events": trades,
        }


# =====================================================================
# Convenience Functions
# =====================================================================

def get_history() -> BacktestHistory:
    """Get the default history instance."""
    return BacktestHistory()


def save_current_backtest(
    results: list[dict],
    session_state: object,
    duration: float = 0.0,
    failed: list[dict] | None = None,
) -> int:
    """
    Convenience function to save current Streamlit session's backtest.
    
    Parameters
    ----------
    results : list[dict]
        st.session_state.backtest_results
    session_state : object
        st.session_state (for extracting params)
    duration : float
        st.session_state.backtest_duration
    failed : list[dict]
        st.session_state.failed_stocks
    
    Returns
    -------
    int — The saved run_id
    """
    params = {
        "start_date": str(getattr(session_state, "start_date", "")),
        "end_date": str(getattr(session_state, "end_date", "")),
        "entry_threshold": getattr(session_state, "entry_threshold", 70),
        "exit_threshold": getattr(session_state, "exit_threshold", 50),
        "exit_mode": getattr(session_state, "exit_mode", "NONE"),
        "sl_percent": getattr(session_state, "sl_percent", 0.0),
        "trailing_sl_percent": getattr(session_state, "trailing_sl_percent", 3.0),
        "trailing_activate_pct": getattr(session_state, "trailing_activate_pct", 5.0),
        "divergence_rsi_drop": getattr(session_state, "divergence_rsi_drop", 3.0),
        "divergence_cooldown": getattr(session_state, "divergence_cooldown", 5),
    }
    
    with get_history() as hist:
        return hist.save_backtest_run(results, params, duration, failed)
