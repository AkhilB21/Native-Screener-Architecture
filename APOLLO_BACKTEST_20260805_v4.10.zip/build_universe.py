"""Apollo Dynamic Universe Builder (v4.8)

Scans all available data sources and builds a unified ``apollo_universe.json``
that replaces all hardcoded stock lists across the application.

Sources merged (priority order):
  1. my_watchlist.json        — user-curated NSE Engine output (515 stocks)
  2. apollo_data/ manifest    — symbols with Parquet data
  3. smallcap500.json         — Nifty Smallcap 500 universe
  4. etmoney_stocks_list.json — ET Money full NSE stock list (~1700 stocks)
  5. ipo_listing_dates.json   — 2026 IPO listing dates & metadata

Output: ``apollo_universe.json`` at project root — a JSON array of objects::

    [
        {"sym": "CYIENTDLM", "name": "Cyient DLM", "sector": "",
         "has_parquet": true, "in_watchlist": true, "in_smallcap500": true,
         "in_etmoney": true, "is_ipo": false,
         "ipo_listing_date": "", "ipo_issue_price": 0,
         "date_start": "2020-01-01", "date_end": "2026-07-31", "rows": 1500},
        ...
    ]

Usage::

    python build_universe.py
    python build_universe.py --watchlist my_watchlist.json --data-dir apollo_data/

Run this AFTER syncing Parquet data (``python -m data_repo.sync ...``)
to get accurate has_parquet / date ranges.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent


def _strip_ns(sym: str) -> str:
    """Strip .NS / .BO suffix and return clean UPPERCASE symbol."""
    return sym.replace(".NS", "").replace(".BO", "").strip().upper()


def load_watchlist(path: Path) -> dict[str, dict]:
    """Load my_watchlist.json. Returns {SYMBOL: {name, sector}}."""
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        return {}
    result = {}
    for entry in data:
        if not isinstance(entry, dict) or not entry.get("sym"):
            continue
        sym = _strip_ns(entry["sym"])
        result[sym] = {
            "name": entry.get("name", sym),
            "sector": entry.get("sector", ""),
        }
    return result


def load_smallcap500(path: Path) -> dict[str, dict]:
    """Load smallcap500.json. Returns {SYMBOL: {name, sector}}."""
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        return {}
    result = {}
    for entry in data:
        if not isinstance(entry, dict):
            continue
        sym_raw = entry.get("sym", entry.get("symbol", ""))
        if not sym_raw:
            continue
        sym = _strip_ns(sym_raw)
        result[sym] = {
            "name": entry.get("name", sym),
            "sector": entry.get("sector", ""),
        }
    return result


def load_etmoney(path: Path) -> dict[str, dict]:
    """Load etmoney_stocks_list.json. Returns {SYMBOL: {name, sector, mkt_cap}}.

    Format: [{"scripCode": "RELIANCE", "displayName": "Reliance Industries Ltd.",
              "industryName": "Refineries", "mktCapDesc": "Large Cap", ...}, ...]
    """
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        return {}
    result = {}
    for entry in data:
        if not isinstance(entry, dict) or not entry.get("scripCode"):
            continue
        sym = entry["scripCode"].strip().upper()
        result[sym] = {
            "name": entry.get("displayName", sym),
            "sector": entry.get("industryName", ""),
            "mkt_cap_desc": entry.get("mktCapDesc", ""),
        }
    return result


def load_ipo_listing(path: Path) -> dict[str, dict]:
    """Load ipo_listing_dates.json. Returns {SYMBOL: {company, listing_date, issue_price, status}}.

    Format: {"SBIFUNDS": {"company": "...", "listing_date": "2026-07-21",
              "issue_price": 574.0, "listing_close": 609.75, "_status": "listed"}, ...}
    """
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        return {}
    result = {}
    for sym, info in data.items():
        if sym.startswith("_"):
            continue  # skip _metadata
        if not isinstance(info, dict):
            continue
        sym = sym.strip().upper()
        status = info.get("_status", "listed" if info.get("listing_date") else "upcoming")
        result[sym] = {
            "name": info.get("company", sym),
            "ipo_listing_date": info.get("listing_date", "") or "",
            "ipo_issue_price": info.get("issue_price", 0) or 0,
            "ipo_listing_close": info.get("listing_close", 0) or 0,
            "ipo_status": status,
        }
    return result


def load_parquet_manifest(data_dir: Path) -> dict[str, dict]:
    """Load manifest.json from the Parquet repo for metadata."""
    manifest_path = data_dir / "manifest.json"
    if not manifest_path.exists():
        return {}
    with open(manifest_path, "r", encoding="utf-8") as f:
        return json.load(f)


def scan_parquet_files(data_dir: Path) -> dict[str, bool]:
    """Quick scan: which symbols have Parquet files?"""
    result = {}
    if not data_dir.is_dir():
        return result
    for pq in data_dir.glob("*.parquet"):
        result[pq.stem.upper()] = True
    return result


def build_universe(
    watchlist_path: Path,
    data_dir: Path,
    smallcap_path: Path,
    etmoney_path: Path,
    ipo_path: Path,
) -> list[dict]:
    """Build the unified universe list from all sources."""
    # Load all sources
    wl = load_watchlist(watchlist_path)
    sc500 = load_smallcap500(smallcap_path)
    etm = load_etmoney(etmoney_path)
    ipo = load_ipo_listing(ipo_path)
    manifest = load_parquet_manifest(data_dir)
    parquet_files = scan_parquet_files(data_dir)

    # Load exclusion list
    excludes_path = _PROJECT_ROOT / "universe_excludes.json"
    exclude_set: set[str] = set()
    if excludes_path.exists():
        with open(excludes_path, "r", encoding="utf-8") as _ef:
            exclude_set = set(json.load(_ef))

    # Union of all symbols, minus exclusions
    all_syms = (
        set(wl.keys())
        | set(sc500.keys())
        | set(etm.keys())
        | set(ipo.keys())
        | set(manifest.keys())
        | set(parquet_files.keys())
    ) - exclude_set

    if exclude_set:
        print(f"  Exclusions:   {len(exclude_set)} symbols from universe_excludes.json")

    universe = []
    for sym in sorted(all_syms):
        # Gather info from each source (priority: watchlist > etmoney > smallcap500 > ipo)
        wl_info = wl.get(sym, {})
        sc_info = sc500.get(sym, {})
        etm_info = etm.get(sym, {})
        ipo_info = ipo.get(sym, {})
        manifest_info = manifest.get(sym, {})

        # Name: prefer watchlist, then etmoney (has displayName), then smallcap, then ipo, then sym
        name = (
            wl_info.get("name")
            or etm_info.get("name")
            or sc_info.get("name")
            or ipo_info.get("name")
            or sym
        )

        # Sector: prefer watchlist, then etmoney (has industryName), then smallcap
        sector = (
            wl_info.get("sector")
            or etm_info.get("sector")
            or sc_info.get("sector")
            or ""
        )

        universe.append({
            "sym": sym,
            "name": name or sym,
            "sector": sector or "",
            "mkt_cap_desc": etm_info.get("mkt_cap_desc") or "",
            "has_parquet": sym in parquet_files,
            "in_watchlist": sym in wl,
            "in_smallcap500": sym in sc500,
            "in_etmoney": sym in etm,
            "is_ipo": sym in ipo,
            "ipo_listing_date": ipo_info.get("ipo_listing_date", "") or "",
            "ipo_issue_price": ipo_info.get("ipo_issue_price", 0) or 0,
            "ipo_listing_close": ipo_info.get("ipo_listing_close", 0) or 0,
            "ipo_status": ipo_info.get("ipo_status", "") or "",
            "date_start": manifest_info.get("date_start", "") or "",
            "date_end": manifest_info.get("date_end", "") or "",
            "rows": manifest_info.get("rows", 0) or 0,
            "source": manifest_info.get("source", "") or "",
        })

    return universe


def main(argv=None):
    parser = argparse.ArgumentParser(description="Build Apollo Dynamic Universe")
    parser.add_argument("--watchlist", default=str(_PROJECT_ROOT / "my_watchlist.json"))
    parser.add_argument("--data-dir", default=str(_PROJECT_ROOT / "apollo_data"))
    parser.add_argument("--smallcap", default=str(_PROJECT_ROOT / "smallcap500.json"))
    parser.add_argument("--etmoney", default=str(_PROJECT_ROOT / "etmoney_stocks_list.json"))
    parser.add_argument("--ipo", default=str(_PROJECT_ROOT / "ipo_listing_dates.json"))
    parser.add_argument("--output", default=str(_PROJECT_ROOT / "apollo_universe.json"))
    args = parser.parse_args(argv)

    print("Building Apollo Dynamic Universe...")
    print(f"  Watchlist:  {args.watchlist}")
    print(f"  Smallcap:   {args.smallcap}")
    print(f"  ET Money:   {args.etmoney}")
    print(f"  IPO:        {args.ipo}")
    print(f"  Data dir:   {args.data_dir}")
    print()

    universe = build_universe(
        watchlist_path=Path(args.watchlist),
        data_dir=Path(args.data_dir),
        smallcap_path=Path(args.smallcap),
        etmoney_path=Path(args.etmoney),
        ipo_path=Path(args.ipo),
    )

    out_path = Path(args.output)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(universe, f, indent=2)

    # Summary
    n_parquet = sum(1 for e in universe if e["has_parquet"])
    n_watchlist = sum(1 for e in universe if e["in_watchlist"])
    n_sc500 = sum(1 for e in universe if e["in_smallcap500"])
    n_etm = sum(1 for e in universe if e["in_etmoney"])
    n_ipo = sum(1 for e in universe if e["is_ipo"])
    print(f"  Total symbols:    {len(universe)}")
    print(f"  With Parquet:     {n_parquet}")
    print(f"  In Watchlist:     {n_watchlist}")
    print(f"  In Smallcap500:   {n_sc500}")
    print(f"  In ET Money:      {n_etm}")
    print(f"  In IPO listing:   {n_ipo}")
    print(f"  Output:           {out_path}")


if __name__ == "__main__":
    main()
