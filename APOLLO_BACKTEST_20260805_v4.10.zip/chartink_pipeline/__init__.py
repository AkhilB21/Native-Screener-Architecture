"""Chartink Pipeline — Automated data fetch + watchlist curation for Apollo.

One-time setup:
    python -m chartink_pipeline.auth          # Log into Chartink (saves session)

Daily automated pipeline (EOD, after 3:35 PM IST):
    python -m chartink_pipeline.run_pipeline  # Fetch → Score → Update watchlist
    python -m chartink_pipeline.run_pipeline --dry-run  # Preview without updating

VPS cron (automated, zero intervention):
    35 15 * * 1-5 cd /path/to/apollo_engine && python -m chartink_pipeline.run_pipeline >> logs/chartink.log 2>&1

The pipeline:
    1. Calls Chartink screener API (using saved browser session)
    2. Fetches RSI Dashboard (6 timeframes) + NIFTY 500 Gainers (6 timeframes)
    3. Computes Recovery Score (mirrors Apollo's Pool A + Pool C RSI logic)
    4. Cross-references with momentum data from NIFTY 500 Gainers
    5. Generates curated watchlist → updates my_watchlist.json (merges, doesn't replace)
    6. Outputs ranked CSV report + JSON summary

Session refresh:
    Chartink sessions last ~30-60 days. When the pipeline returns 419 errors
    or 0 results, re-run: python -m chartink_pipeline.auth
"""
