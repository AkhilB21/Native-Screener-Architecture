"""Chartink Data Fetcher v5 — Browser UI automation + API fallbacks.

This module fetches data from Chartink's screener by automating the browser
UI (fill form → click Scan → intercept response). This guarantees the
exact same request format as a manual user.

Three methods are attempted in order:
  1. UI Automation (PRIMARY): Fill the screener form, click Scan,
     capture the AJAX response via Playwright's response listener.
  2. In-Page Fetch (FALLBACK): page.evaluate(fetch()) with XSRF from
     Playwright's cookie jar.
  3. APIRequestContext (LAST RESORT): page.request.post() with
     explicit headers.

Why this works when direct API calls fail:
  Chartink's frontend may send additional parameters, headers, or
  cookies that are difficult to replicate with raw HTTP calls. By
  automating the actual browser UI, we ensure every detail matches.

Usage:
    from chartink_pipeline.fetcher import ChartinkClient

    client = ChartinkClient()
    df = client.run_scan(
        scan_condition='( RSI ( 21 , C ) greater than 50 )',
        process='daily',
    )
    client.close()
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Optional
from urllib.parse import unquote

import pandas as pd

# Paths relative to this file inside apollo_engine/chartink_pipeline/
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent  # apollo_engine/
STATE_FILE = _THIS_DIR / "chartink_state.json"
CHARTINK_BASE = "https://chartink.com"
CHARTINK_API = f"{CHARTINK_BASE}/screener/process"


class ChartinkAPIError(Exception):
    """Raised when the Chartink API returns an error."""


# -- DOM selectors for Chartink's screener UI ------------------------------
# These are tried in order; first match wins.

_SCAN_INPUT_SELECTORS = [
    "textarea#scan_condition",
    "textarea[name=\"scan_condition\"]",
    "textarea.scan-condition",
    "#screener-textarea",
    "textarea.form-control",
    "textarea",
]

_CODEMIRROR_SELECTORS = [
    ".CodeMirror",
    ".cm-editor",
    "[contenteditable=\"true\"]",
]

_PROCESS_SELECTORS = [
    "select[name=\"process\"]",
    "select#process",
    "select.timeframe",
    "select.form-control",
]

_EXCHANGE_SELECTORS = [
    "select[name=\"exchange\"]",
    "select[name=\"exchanges\"]",
    "select#exchange",
    "select.form-control",
]

_SCAN_BUTTON_SELECTORS = [
    "button:has-text(\"Scan\")",
    "button:has-text(\"Run\")",
    "button:has-text(\"Execute\")",
    "button[type=\"submit\"]",
    "input[type=\"submit\"]",
    "button.btn-primary",
    "button.btn-success",
]


class ChartinkClient:
    """Authenticated client for the Chartink screener.

    Uses browser UI automation as the primary method, with API
    fallbacks. Call close() when done.
    """

    def __init__(
        self,
        state_file: str | Path = STATE_FILE,
        max_retries: int = 2,
        retry_delay: float = 3.0,
        headless: bool = True,
    ):
        self._state_file = Path(state_file)
        self._max_retries = max_retries
        self._retry_delay = retry_delay
        self._headless = headless

        if not self._state_file.exists():
            raise FileNotFoundError(
                f"No Chartink session found at {self._state_file}.\n"
                "Run: python -m chartink_pipeline.auth"
            )

        # Lazy initialization — browser opens on first use
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None
        self._ready = False

    # -- Browser Lifecycle ------------------------------------------------

    def _close_internal(self) -> None:
        """Close all browser resources without touching flags.

        This is the CRITICAL fix for the 'Sync API inside asyncio loop'
        error. Previously, if _ensure_browser() failed partway through,
        the old Playwright instance was never stopped, leaving a
        dangling asyncio event loop. The next retry would then detect
        the existing loop and refuse to start.
        """
        for attr, closer in [
            ("_page", "close"),
            ("_context", "close"),
            ("_browser", "close"),
            ("_pw", "stop"),
        ]:
            resource = getattr(self, attr, None)
            if resource is None:
                continue
            try:
                # Some resources have is_closed(), some don't
                if hasattr(resource, "is_closed") and resource.is_closed():
                    continue
                getattr(resource, closer)()
            except Exception:
                pass
        self._pw = None
        self._browser = None
        self._context = None
        self._page = None

    def _ensure_browser(self) -> None:
        """Lazily create Playwright browser with saved session state.

        Key fixes vs v4.6.1:
          - Calls _close_internal() first to destroy any previous instance
          - Uses 'domcontentloaded' instead of 'networkidle' (avoids 30s
            timeout on pages with analytics/ads that never go idle)
          - Wraps entire setup in try/except with cleanup
        """
        if self._ready and self._page:
            try:
                if not self._page.is_closed():
                    return
            except Exception:
                pass

        # CRITICAL: Destroy any previous Playwright instance first
        self._close_internal()

        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            raise ChartinkAPIError(
                "playwright not installed.\n"
                "  pip install playwright\n"
                "  playwright install chromium"
            )

        print("  Launching browser with saved session...", file=sys.stderr)

        try:
            self._pw = sync_playwright().start()
            self._browser = self._pw.chromium.launch(
                headless=self._headless,
                args=[
                    "--no-sandbox",
                    "--disable-blink-features=AutomationControlled",
                ],
            )
            self._context = self._browser.new_context(
                storage_state=str(self._state_file),
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/131.0.0.0 Safari/537.36"
                ),
                viewport={"width": 1280, "height": 800},
            )
            self._page = self._context.new_page()

            # Use domcontentloaded — much faster and more reliable than
            # networkidle (which waits for ALL network requests including
            # analytics/tracking that may never finish)
            self._page.goto(
                f"{CHARTINK_BASE}/screener",
                wait_until="domcontentloaded",
                timeout=30000,
            )

            # Wait for the page JavaScript to initialize and set cookies
            self._page.wait_for_timeout(3000)

            # Verify we're on the screener page (not redirected to login)
            current_url = self._page.url
            if (
                "/login" in current_url.lower()
                or "accounts.google.com" in current_url
            ):
                self._close_internal()
                raise ChartinkAPIError(
                    "Session expired — redirected to login page.\n"
                    "Re-run: python -m chartink_pipeline.auth"
                )

            self._ready = True
            print("  Browser ready.", file=sys.stderr)

        except ChartinkAPIError:
            raise
        except Exception as e:
            # CRITICAL: Clean up on ANY failure to prevent asyncio issues
            self._close_internal()
            raise

    def _full_reset(self) -> None:
        """Full browser reset: close everything and mark as not ready.

        Call this between retries to get a completely fresh state.
        """
        self._close_internal()
        self._ready = False

    def _get_xsrf_token(self) -> str:
        """Read and URL-decode the XSRF-TOKEN from Playwright's cookie jar."""
        if not self._context:
            return ""
        try:
            cookies = self._context.cookies(["https://chartink.com"])
            for c in cookies:
                if c["name"] == "XSRF-TOKEN":
                    return unquote(c["value"])
        except Exception:
            pass
        return ""

    def _refresh_session(self) -> None:
        """Re-navigate to screener to get fresh XSRF token and cookies."""
        try:
            self._page.goto(
                f"{CHARTINK_BASE}/screener",
                wait_until="domcontentloaded",
                timeout=20000,
            )
            self._page.wait_for_timeout(2000)
        except Exception:
            pass

    def close(self) -> None:
        """Release browser resources. Call this when done."""
        self._close_internal()
        self._ready = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ==================================================================
    # METHOD 1: Browser UI Automation (PRIMARY)
    # ==================================================================
    # This fills the screener form exactly like a human user and
    # intercepts the AJAX response. It's the most reliable method
    # because it uses Chartink's own frontend code to construct
    # the API request.

    def _fill_input(self, condition: str) -> bool:
        """Fill the scan condition input field.

        Uses JavaScript to set the value via the native property setter
        and dispatch framework-compatible events (input, change).
        This is required because Playwright's type()/fill() may not
        trigger React/Angular/Vue state updates.
        """
        js_code = """(args) => {
            const condition = args.condition;

            // --- Try CodeMirror editors first ---
            const cmSelectors = [
                '.CodeMirror', '.cm-editor', '[contenteditable="true"]'
            ];
            for (const sel of cmSelectors) {
                const cm = document.querySelector(sel);
                if (!cm) continue;
                // Check visibility
                const rect = cm.getBoundingClientRect();
                if (rect.width === 0 || rect.height === 0) continue;

                cm.click();
                cm.focus();

                // CodeMirror: use the CodeMirror API if available
                if (cm.CodeMirror) {
                    cm.CodeMirror.setValue(condition);
                    cm.CodeMirror.refresh();
                    return { found: true, method: 'CodeMirror-API', check: cm.CodeMirror.getValue().substring(0, 40) };
                }

                // Plain contenteditable: use execCommand
                document.execCommand('selectAll');
                document.execCommand('delete');
                document.execCommand('insertText', false, condition);
                return { found: true, method: 'contenteditable', check: 'N/A' };
            }

            // --- Try regular textareas and inputs ---
            const targets = [
                'textarea',
                'textarea.form-control',
                'input[type="text"]',
            ];
            for (const sel of targets) {
                const el = document.querySelector(sel);
                if (!el) continue;

                // Check visibility
                const rect = el.getBoundingClientRect();
                if (rect.width === 0 || rect.height === 0) continue;

                el.focus();

                // React/Angular/Vue compatible: use the native setter
                // to bypass the framework's controlled input wrapper,
                // then dispatch events the framework listens to.
                const descriptor = Object.getOwnPropertyDescriptor(
                    el.tagName === 'TEXTAREA'
                        ? window.HTMLTextAreaElement.prototype
                        : window.HTMLInputElement.prototype,
                    'value'
                );

                if (descriptor && descriptor.set) {
                    descriptor.set.call(el, condition);
                } else {
                    el.value = condition;
                }

                // Dispatch events that React/Angular/Vue listen to
                el.dispatchEvent(new Event('focus', { bubbles: true }));
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                // Some frameworks also listen for keyboard events
                el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
                el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

                return {
                    found: true,
                    method: 'native-setter',
                    selector: sel,
                    tagName: el.tagName,
                    check: el.value.substring(0, 40),
                };
            }

            return { found: false };
        }"""

        result = self._page.evaluate(js_code, {"condition": condition})
        if result.get("found"):
            check_val = result.get("check", "?")
            method = result.get("method", "?")
            print(
                f"  [UI] Filled via {method}: value starts with '{check_val}...'",
                file=sys.stderr,
            )
            # Verify the value was actually set
            if condition[:20] not in check_val and check_val != "N/A":
                print(f"  [UI] WARNING: Value verification failed!",
                      file=sys.stderr)
            return True

        return False

    def _select_dropdown(self, selectors: list[str], value: str) -> bool:
        """Select a value from a dropdown, trying multiple selectors.

        If named selectors fail, falls back to scanning ALL <select>
        elements on the page and matching by option value/text.
        """
        # Phase 1: Try the provided named selectors
        for selector in selectors:
            try:
                el = self._page.locator(selector).first
                if el.is_visible(timeout=1500):
                    if self._try_select_option(el, value):
                        print(f"  [UI] Selected '{value}' via: {selector}",
                              file=sys.stderr)
                        return True
            except Exception:
                continue

        # Phase 2: Scan ALL <select> elements on the page
        # This catches dropdowns with unexpected IDs/names
        try:
            all_selects = self._page.locator("select").all()
            for sel in all_selects:
                try:
                    if not sel.is_visible(timeout=500):
                        continue
                    if self._try_select_option(sel, value):
                        sel_name = sel.get_attribute("name") or sel.get_attribute("id") or "?"
                        print(f"  [UI] Selected '{value}' via scan of all selects ({sel_name})",
                              file=sys.stderr)
                        return True
                except Exception:
                    continue
        except Exception:
            pass

        return False

    def _try_select_option(self, select_el, value: str) -> bool:
        """Try to select 'value' from a <select> element.

        Matches against both the option's value attribute and its
        visible text. Handles partial matches too.
        """
        try:
            options = select_el.locator("option").all()
            for opt in options:
                opt_value = opt.get_attribute("value") or ""
                opt_text = (opt.text_content() or "").strip()

                # Exact value match
                if opt_value.lower() == value.lower():
                    select_el.select_option(value=opt_value)
                    return True
                # Value contains target (e.g. value="1week" matches "weekly")
                if value.lower() in opt_value.lower():
                    select_el.select_option(value=opt_value)
                    return True
                # Text contains target
                if value.lower() in opt_text.lower():
                    select_el.select_option(value=opt_value)
                    return True
                # Reverse: option text is contained in our value
                if opt_text.lower() in value.lower() and len(opt_text) > 2:
                    select_el.select_option(value=opt_value)
                    return True
        except Exception:
            pass
        return False

    def _click_scan_button(self) -> bool:
        """Click the Scan/Run button."""
        for selector in _SCAN_BUTTON_SELECTORS:
            try:
                el = self._page.locator(selector).first
                if el.is_visible(timeout=1500):
                    el.click()
                    print(f"  [UI] Clicked scan button: {selector}",
                          file=sys.stderr)
                    return True
            except Exception:
                continue
        return False

    def _run_scan_via_ui(self, payload: dict) -> dict:
        """Run a scan by automating the browser UI.

        Workflow:
          1. Fill the scan condition via JS native setter (React-compatible)
          2. Select the timeframe (process) dropdown
          3. Click the Run button
          4. Capture the response via THREE strategies:
             a) Intercept ANY chartink.com request with JSON response
             b) Detect page navigation (form submit)
             c) Scrape the results table from the DOM
        """
        self._ensure_browser()

        # --- Capture ALL chartink.com network activity ---
        all_requests = []
        all_responses = []
        page_navigated = False
        old_url = self._page.url

        def on_request(request):
            """Log ALL outgoing requests to chartink.com."""
            try:
                if "chartink.com" in request.url and \
                   not any(x in request.url for x in [
                       'google', 'youtube', 'doubleclick', 'analytics',
                       'ad-score', 'nr-data', 'newrelic'
                   ]):
                    entry = {
                        "method": request.method,
                        "url": request.url[:150],
                        "has_body": request.post_data is not None,
                    }
                    if request.post_data:
                        entry["body_preview"] = request.post_data[:200]
                    all_requests.append(entry)
            except Exception:
                pass

        def on_response(response):
            """Capture chartink.com responses."""
            try:
                if "chartink.com" in response.url and \
                   not any(x in response.url for x in [
                       'google', 'youtube', 'doubleclick', 'analytics',
                       'ad-score', 'nr-data', 'newrelic'
                   ]):
                    entry = {
                        "url": response.url[:150],
                        "status": response.status,
                        "method": response.request.method,
                    }
                    # Try to parse JSON
                    try:
                        body = response.json()
                        entry["json"] = body
                        entry["is_scan"] = isinstance(body, dict) and (
                            "data" in body or "recordsTotal" in body
                            or len(body) > 5
                        )
                    except Exception:
                        entry["json"] = None
                        entry["is_scan"] = False
                    all_responses.append(entry)
            except Exception:
                pass

        def on_navigate():
            nonlocal page_navigated
            page_navigated = True

        self._page.on("request", on_request)
        self._page.on("response", on_response)
        self._page.on("load", on_navigate)

        try:
            # Step 1: Fill scan condition (JS native setter)
            scan_condition = payload["scan_condition"]
            if not self._fill_input(scan_condition):
                raise ChartinkAPIError(
                    "UI automation: Could not find scan condition input. "
                    "The screener page structure may have changed."
                )

            # Step 2: Select timeframe/process
            process = payload["process"]
            if not self._select_dropdown(_PROCESS_SELECTORS, process):
                print(f"  [UI] Warning: Could not select process '{process}', "
                      f"using page default", file=sys.stderr)

            self._page.wait_for_timeout(500)

            # Step 3: Click Scan/Run button
            if not self._click_scan_button():
                raise ChartinkAPIError(
                    "UI automation: Could not find Scan button. "
                    "The screener page structure may have changed."
                )

            # Step 4: Wait for results
            max_wait_ms = 60000
            check_interval = 300
            waited = 0

            while waited < max_wait_ms:
                self._page.wait_for_timeout(check_interval)
                waited += check_interval

                # Check if any chartink response looks like a scan result
                for resp in all_responses:
                    if resp.get("is_scan"):
                        print(
                            f"  [UI] Captured scan response from: {resp['url']} "
                            f"(status={resp['status']}, method={resp['method']})",
                            file=sys.stderr,
                        )
                        result = resp["json"]

                        if resp["status"] == 419:
                            raise ChartinkAPIError(
                                "CSRF mismatch (419) during UI automation. "
                                "Re-run: python -m chartink_pipeline.auth"
                            )
                        if resp["status"] == 401:
                            raise ChartinkAPIError(
                                "Authentication failed (401). "
                                "Re-run: python -m chartink_pipeline.auth"
                            )
                        if resp["status"] != 200:
                            raise ChartinkAPIError(
                                f"UI scan API error (HTTP {resp['status']}): "
                                f"{str(result)[:300]}"
                            )

                        # Normalize: wrap non-standard responses
                        if isinstance(result, dict) and "data" in result:
                            return result
                        if isinstance(result, list):
                            return {"data": result, "recordsTotal": len(result)}
                        if isinstance(result, dict):
                            # Might be the data itself
                            return {"data": [result], "recordsTotal": 1}

                # Check if page navigated
                if page_navigated and self._page.url != old_url:
                    print(
                        f"  [UI] Page navigated to: {self._page.url}",
                        file=sys.stderr,
                    )
                    break

            # --- Log ALL chartink.com network activity for debugging ---
            print("  [UI] Chartink requests after Run click:", file=sys.stderr)
            for r in all_requests:
                body_info = f" body={r.get('body_preview', '')[:80]}" if r.get('has_body') else ""
                print(f"    {r['method']:4s} {r['url']}{body_info}",
                      file=sys.stderr)
            if not all_requests:
                print("    (none — Run click may not have triggered any request)",
                      file=sys.stderr)

            print("  [UI] Chartink responses after Run click:", file=sys.stderr)
            for r in all_responses:
                json_info = f" json_keys={list(r.get('json', {}).keys())[:5]}" \
                    if r.get('json') else ""
                print(f"    {r['method']:4s} {r['url']} status={r['status']}{json_info}",
                      file=sys.stderr)
            if not all_responses:
                print("    (none)", file=sys.stderr)

            # --- Strategy B: DOM table scraping ---
            try:
                self._page.wait_for_load_state("domcontentloaded", timeout=5000)
            except Exception:
                pass

            try:
                self._page.wait_for_selector(
                    "table tbody tr td",
                    timeout=10000,
                )
            except Exception:
                pass

            self._page.wait_for_timeout(2000)

            df = self._scrape_table_from_dom()
            if not df.empty:
                print(
                    f"  [UI] Scraped {len(df)} rows from DOM table",
                    file=sys.stderr,
                )
                return {
                    "data": df.to_dict(orient="records"),
                    "recordsTotal": len(df),
                    "recordsFiltered": len(df),
                }

            # Check for visible error/alert messages
            try:
                errors = self._page.evaluate("""() => {
                    const sel = '.alert, .alert-danger, .error-message, '
                              + '.toast-error, .notification.error, '
                              + '[class*="error"], [class*="alert"]';
                    return Array.from(document.querySelectorAll(sel))
                        .map(e => e.textContent.trim())
                        .filter(t => t.length > 0 && t.length < 500);
                }""")
                if errors:
                    print(f"  [UI] Page errors: {errors[:3]}", file=sys.stderr)
            except Exception:
                pass

            raise ChartinkAPIError(
                "UI automation: No scan data received. "
                "Check the network log above to see what the Run button triggered."
            )

        finally:
            try:
                self._page.remove_listener("request", on_request)
            except Exception:
                pass
            try:
                self._page.remove_listener("response", on_response)
            except Exception:
                pass
            try:
                self._page.remove_listener("load", on_navigate)
            except Exception:
                pass

    # ==================================================================
    # METHOD 2: In-Page Fetch (FALLBACK)
    # ==================================================================
    # Uses page.evaluate(fetch()) to make an API call from within the
    # browser page. The browser adds all standard headers (Sec-Fetch-*,
    # etc.) automatically. We read the XSRF token from Playwright's
    # cookie jar (not document.cookie which can be stale).

    def _run_scan_via_fetch(self, payload: dict) -> dict:
        """Fallback: In-page fetch with XSRF from Playwright's cookie jar.

        Tries both /screener/process and /oapi endpoints.
        """
        self._ensure_browser()

        xsrf = self._get_xsrf_token()
        if not xsrf:
            print("  [fetch] No XSRF token, refreshing...", file=sys.stderr)
            self._refresh_session()
            xsrf = self._get_xsrf_token()

        if not xsrf:
            raise ChartinkAPIError(
                "No XSRF-TOKEN in browser cookies. "
                "Session may be expired. Re-run: python -m chartink_pipeline.auth"
            )

        # Try multiple endpoints
        endpoints = [
            "/screener/process",
            "/oapi",
        ]

        for endpoint in endpoints:
            print(f"  [fetch] Trying {endpoint}...", file=sys.stderr)
            result = self._page.evaluate(
                """async (args) => {
                    try {
                        const resp = await fetch(args.endpoint, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest',
                                'X-XSRF-TOKEN': args.xsrf,
                                'Accept': 'application/json, text/plain, */*',
                            },
                            body: JSON.stringify(args.payload),
                            credentials: 'include',
                        });
                        const text = await resp.text();
                        return { status: resp.status, ok: resp.ok, body: text, endpoint: args.endpoint };
                    } catch (err) {
                        return {
                            status: 0, ok: false,
                            body: 'JS error: ' + err.message,
                            endpoint: args.endpoint
                        };
                    }
                }""",
                {"xsrf": xsrf, "payload": payload, "endpoint": endpoint},
            )

            if not isinstance(result, dict):
                continue

            status = result.get("status", 0)
            body = result.get("body", "")

            if status == 419:
                raise ChartinkAPIError(
                    f"CSRF mismatch (419) via fetch to {endpoint}. "
                    "Re-run: python -m chartink_pipeline.auth"
                )
            if status == 401:
                raise ChartinkAPIError(
                    f"Authentication failed (401) via fetch to {endpoint}."
                )
            if status and status != 200:
                print(f"  [fetch] {endpoint} returned HTTP {status}: {body[:100]}",
                      file=sys.stderr)
                continue

            try:
                parsed = json.loads(body)
            except json.JSONDecodeError:
                print(f"  [fetch] {endpoint} returned non-JSON: {body[:100]}",
                      file=sys.stderr)
                continue

            # Check if this endpoint returned actual data
            if isinstance(parsed, dict):
                records = parsed.get("data", [])
                total = parsed.get("recordsTotal", 0)
                if records or total > 0:
                    print(f"  [fetch] {endpoint} returned {total} total records",
                          file=sys.stderr)
                    return parsed
                # 0 records from this endpoint, try next
                print(f"  [fetch] {endpoint} returned 0 records, trying next...",
                      file=sys.stderr)
            elif isinstance(parsed, list) and len(parsed) > 0:
                return {"data": parsed, "recordsTotal": len(parsed)}

        raise ChartinkAPIError(
            "All fetch endpoints returned 0 records or errors."
        )

    # ==================================================================
    # METHOD 3: APIRequestContext (LAST RESORT)
    # ==================================================================
    # Uses Playwright's page.request.post() which shares the browser
    # context's cookies. Less reliable than UI automation because
    # it may miss browser-specific headers.

    def _run_scan_via_api_request(self, payload: dict) -> dict:
        """Last resort: page.request.post() with explicit headers."""
        self._ensure_browser()

        xsrf = self._get_xsrf_token()
        if not xsrf:
            self._refresh_session()
            xsrf = self._get_xsrf_token()

        resp = self._page.request.post(
            CHARTINK_API,
            data=json.dumps(payload),
            headers={
                "Content-Type": "application/json",
                "X-XSRF-TOKEN": xsrf,
                "X-Requested-With": "XMLHttpRequest",
                "Accept": "application/json, text/plain, */*",
                "Origin": CHARTINK_BASE,
                "Referer": f"{CHARTINK_BASE}/screener",
            },
        )

        if resp.status == 419:
            raise ChartinkAPIError(
                "CSRF mismatch (419) via API request. "
                "Re-run: python -m chartink_pipeline.auth"
            )
        if resp.status == 401:
            raise ChartinkAPIError(
                "Authentication failed (401) via API request."
            )
        if resp.status != 200:
            raise ChartinkAPIError(
                f"API request error (HTTP {resp.status}): {resp.text()[:300]}"
            )

        try:
            return resp.json()
        except Exception:
            raise ChartinkAPIError(
                f"Invalid JSON from API request: {resp.text()[:200]}"
            )

    # ==================================================================
    # METHOD 4: DOM Table Scraping (FINAL FALLBACK)
    # ==================================================================
    # If all API methods fail but the UI shows results, scrape the
    # table directly from the DOM.

    def _scrape_table_from_dom(self) -> pd.DataFrame:
        """Scrape the results table from the page DOM."""
        data = self._page.evaluate(
            """() => {
                // Try multiple table selectors
                const selectors = [
                    'table.dataTable',
                    '.dataTables_wrapper table',
                    'table#scan_results',
                    'table.table',
                    'table.table-striped',
                    'table'
                ];
                let table = null;
                for (const sel of selectors) {
                    table = document.querySelector(sel);
                    if (table) break;
                }
                if (!table) return null;

                let headers = [];
                const headerRow = table.querySelector('thead tr');
                if (headerRow) {
                    headers = Array.from(headerRow.querySelectorAll('th'))
                        .map(th => th.textContent.trim())
                        .filter(h => h.length > 0);
                }

                const rows = [];
                const bodyRows = table.querySelectorAll('tbody tr');
                for (const tr of bodyRows) {
                    const cells = Array.from(tr.querySelectorAll('td'))
                        .map(td => td.textContent.trim());
                    if (cells.length > 2) {  // Skip footer/summary rows
                        rows.push(cells);
                    }
                }

                return { headers, rows };
            }"""
        )

        if not data or not data.get("rows"):
            return pd.DataFrame()

        headers = data["headers"]
        rows = data["rows"]

        if len(headers) == 0:
            # No headers found, generate column names
            headers = [f"col_{i}" for i in range(len(rows[0]) if rows else 0)]

        # Pad short rows
        max_cols = len(headers)
        padded_rows = []
        for row in rows:
            if len(row) < max_cols:
                row.extend([""] * (max_cols - len(row)))
            padded_rows.append(row[:max_cols])

        return pd.DataFrame(padded_rows, columns=headers)

    # -- Main Scan Method --------------------------------------------------

    def run_scan(
        self,
        scan_condition: str,
        process: str = "daily",
        exchange: str = "nse",
        sort_col: str = "",
        sort_order: str = "desc",
        max_rows: int = 500,
    ) -> pd.DataFrame:
        """Run a Chartink screener scan and return results as a DataFrame.

        Tries three methods in order:
          1. Browser UI automation (most reliable)
          2. In-page fetch (includes browser headers)
          3. APIRequestContext (Playwright's API)

        Parameters
        ----------
        scan_condition : str
            Chartink scan syntax.
        process : str
            Timeframe: daily, weekly, 4hour, 1hour, 30min, 15min,
            2day, 3day, 2week, monthly.
        exchange : str
            Exchange: nse, bse, nfo.
        sort_col : str
            Column name to sort by.
        sort_order : str
            "asc" or "desc".
        max_rows : int
            Max rows (Chartink free tier: 500).

        Returns
        -------
        pd.DataFrame
            Scan results. Empty DataFrame if no matches or on error.
        """
        payload = {
            "scan_condition": scan_condition,
            "canslim": "",
            "exchanges": exchange,
            "process": process,
            "sort_col": sort_col,
            "sort_order": sort_order,
            "per_page": max_rows,
            "page": 1,
            "draw": 1,
        }

        # Define methods to try, in order of preference
        methods = [
            ("UI automation", self._run_scan_via_ui),
            ("in-page fetch", self._run_scan_via_fetch),
            ("API request", self._run_scan_via_api_request),
        ]

        last_error = None

        for method_name, method_fn in methods:
            for attempt in range(1, self._max_retries + 1):
                try:
                    result = method_fn(payload)

                    records = result.get("data", [])
                    total = result.get("recordsTotal", 0)
                    filtered = result.get("recordsFiltered", 0)

                    print(
                        f"  [{process:>6s}] {method_name}: "
                        f"{filtered}/{total} stocks ({len(records)} returned)",
                        file=sys.stderr,
                    )

                    if records:
                        df = pd.DataFrame(records)
                        df["_timeframe"] = process
                        return df

                    # Got 0 rows from this method — try the next method
                    # (don't retry the same method for 0 rows;
                    # the issue is likely method-specific)
                    if method_name != "UI automation":
                        print(
                            f"  [{process:>6s}] {method_name} returned 0 rows, "
                            f"trying next method...",
                            file=sys.stderr,
                        )
                    else:
                        # UI automation returned 0 rows — this is likely
                        # legitimate (market closed, no matches, etc.)
                        # Try DOM scraping as a last resort
                        print(
                            f"  [{process:>6s}] UI returned 0 rows, "
                            f"trying DOM table scrape...",
                            file=sys.stderr,
                        )
                        df = self._scrape_table_from_dom()
                        if not df.empty:
                            df["_timeframe"] = process
                            print(
                                f"  [{process:>6s}] DOM scrape: {len(df)} rows",
                                file=sys.stderr,
                            )
                            return df
                    break  # Move to next method

                except ChartinkAPIError as api_err:
                    # Only re-raise AUTH errors. Other ChartinkAPIError
                    # (timeout, no data, wrong element) should fall through
                    # to the next method.
                    msg = str(api_err).lower()
                    is_auth_error = any(
                        kw in msg
                        for kw in ["419", "401", "csrf", "session expired",
                                   "authentication failed", "redirected to login"]
                    )
                    if is_auth_error:
                        raise
                    # Non-auth error: log and try next method
                    last_error = api_err
                    print(
                        f"  [{process:>6s}] {method_name} "
                        f"non-fatal error: {str(api_err)[:100]}",
                        file=sys.stderr,
                    )
                    break  # Don't retry, move to next method
                except Exception as e:
                    last_error = e
                    err_str = str(e)
                    print(
                        f"  [{process:>6s}] {method_name} "
                        f"attempt {attempt} failed: {err_str[:100]}",
                        file=sys.stderr,
                    )

                    if attempt < self._max_retries:
                        # FULL RESET between retries to avoid asyncio issues
                        self._full_reset()
                        time.sleep(self._retry_delay)

            # If this method failed all retries, try next method
            # But first do a full reset
            self._full_reset()

        print(
            f"  [{process:>6s}] All methods failed.",
            file=sys.stderr,
        )
        if last_error:
            raise last_error
        return pd.DataFrame()

    def test_connection(self) -> bool:
        """Test if the session is still valid by running a trivial scan."""
        try:
            df = self.run_scan(
                scan_condition="( close greater than 0 )",
                process="daily",
                max_rows=3,
            )
            return len(df) > 0
        except Exception:
            return False


# -- Preset Scan Definitions -----------------------------------------------
# These replicate the user's Chartink dashboards.
# RSI conditions use 'greater than 0' to include ALL stocks while
# forcing the API to return RSI columns.

RSI_DASHBOARD_SCANS = {
    "weekly": {
        "scan_condition": (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        ),
        "process": "weekly",
        "sort_col": "% change",
        "description": "NSE CASH RSI Dashboard (Weekly)",
    },
    "daily": {
        "scan_condition": (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        ),
        "process": "daily",
        "sort_col": "% change",
        "description": "NSE CASH RSI Dashboard (Daily)",
    },
    "4hour": {
        "scan_condition": (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        ),
        "process": "4hour",
        "sort_col": "% change",
        "description": "NSE CASH RSI Dashboard (4H)",
    },
    "1hour": {
        "scan_condition": (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        ),
        "process": "1hour",
        "sort_col": "% change",
        "description": "NSE CASH RSI Dashboard (1H)",
    },
    "30min": {
        "scan_condition": (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        ),
        "process": "30min",
        "sort_col": "% change",
        "description": "NSE CASH RSI Dashboard (30M)",
    },
    "15min": {
        "scan_condition": (
            "( ( RSI ( 21 , C ) greater than 0 ) "
            "and ( RSI ( 36 , C ) greater than 0 ) "
            "and ( RSI ( 56 , C ) greater than 0 ) )"
        ),
        "process": "15min",
        "sort_col": "% change",
        "description": "NSE CASH RSI Dashboard (15M)",
    },
}

NIFTY500_GAINERS_SCANS = {
    "daily": {
        "scan_condition": (
            "( ( NIFTY 500 index constituent is true ) "
            "and ( [MACD line ( 12 , 26 , 9 ) , 1 day ago] greater than 0 ) )"
        ),
        "process": "daily",
        "sort_col": "% change",
        "description": "NIFTY 500 Gainers (Daily)",
    },
    "2day": {
        "scan_condition": "( NIFTY 500 index constituent is true )",
        "process": "2day",
        "sort_col": "2 day % change",
        "description": "NIFTY 500 Gainers (2-Day)",
    },
    "3day": {
        "scan_condition": "( NIFTY 500 index constituent is true )",
        "process": "3day",
        "sort_col": "3 day % change",
        "description": "NIFTY 500 Gainers (3-Day)",
    },
    "weekly": {
        "scan_condition": "( NIFTY 500 index constituent is true )",
        "process": "weekly",
        "sort_col": "% change",
        "description": "NIFTY 500 Gainers (1-Week)",
    },
    "2week": {
        "scan_condition": "( NIFTY 500 index constituent is true )",
        "process": "2week",
        "sort_col": "2 week % change",
        "description": "NIFTY 500 Gainers (2-Week)",
    },
    "monthly": {
        "scan_condition": "( NIFTY 500 index constituent is true )",
        "process": "monthly",
        "sort_col": "% change",
        "description": "NIFTY 500 Gainers (Monthly)",
    },
}


def fetch_rsi_dashboard(client: ChartinkClient) -> dict[str, pd.DataFrame]:
    """Fetch all 6 RSI dashboard panels. Returns {timeframe: DataFrame}."""
    results = {}
    for tf, scan_def in RSI_DASHBOARD_SCANS.items():
        print(f"\nFetching RSI Dashboard -- {scan_def['description']}...")
        df = client.run_scan(
            scan_condition=scan_def["scan_condition"],
            process=scan_def["process"],
            sort_col=scan_def["sort_col"],
            sort_order="desc",
        )
        results[tf] = df
    return results


def fetch_nifty500_gainers(client: ChartinkClient) -> dict[str, pd.DataFrame]:
    """Fetch all 6 NIFTY 500 Gainers panels. Returns {timeframe: DataFrame}."""
    results = {}
    for tf, scan_def in NIFTY500_GAINERS_SCANS.items():
        print(f"\nFetching NIFTY 500 Gainers -- {scan_def['description']}...")
        df = client.run_scan(
            scan_condition=scan_def["scan_condition"],
            process=scan_def["process"],
            sort_col=scan_def["sort_col"],
            sort_order="desc",
        )
        results[tf] = df
    return results


def main(argv: list[str] | None = None) -> int:
    """Test connection to Chartink."""
    print("Chartink Fetcher v5 — Testing connection...")
    client = None
    try:
        client = ChartinkClient()
        ok = client.test_connection()
        if ok:
            print("Connection OK! Session is valid.")
            return 0
        else:
            print("Connection failed -- 0 results. Session may need refresh.")
            print("Run: python -m chartink_pipeline.auth")
            return 1
    except FileNotFoundError as e:
        print(f"Setup needed: {e}")
        return 1
    except ChartinkAPIError as e:
        print(f"Auth error: {e}")
        return 1
    finally:
        if client:
            client.close()


if __name__ == "__main__":
    sys.exit(main())
