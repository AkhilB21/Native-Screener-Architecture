"""Apollo Data Cleanup — Remove parquet files for non-universe symbols (v4.9)

Scans apollo_data/ for all .parquet files and deletes any whose symbol
is NOT in apollo_universe.json.  The exclusion list (universe_excludes.json)
is already applied by build_universe.py, so this only needs to check the universe.

Usage::

    python cleanup_data.py              # dry-run: show what would be deleted
    python cleanup_data.py --delete     # actually delete the files
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description="Clean up parquet files not in apollo_universe.json")
    parser.add_argument("--delete", action="store_true", help="Actually delete files (default: dry-run)")
    parser.add_argument("--data-dir", default=str(_PROJECT_ROOT / "apollo_data"))
    parser.add_argument("--universe", default=str(_PROJECT_ROOT / "apollo_universe.json"))
    args = parser.parse_args()

    data_dir = Path(args.data_dir)
    universe_path = Path(args.universe)

    # Load allowed symbols
    allowed: set[str] = set()
    if universe_path.exists():
        with open(universe_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            allowed = {entry["sym"].upper() for entry in data if isinstance(entry, dict) and entry.get("sym")}
    else:
        print(f"WARNING: {universe_path} not found — nothing will be deleted.")
        return

    if not data_dir.is_dir():
        print(f"WARNING: {data_dir} not found — nothing to clean.")
        return

    # Scan for parquet files
    to_delete = []
    for pq in sorted(data_dir.glob("*.parquet")):
        sym = pq.stem.upper()
        if sym not in allowed:
            to_delete.append(pq)

    if not to_delete:
        print(f"All {len(list(data_dir.glob('*.parquet')))} parquet files are in the universe. Nothing to delete.")
        return

    print(f"Found {len(to_delete)} parquet file(s) NOT in apollo_universe.json:")
    for f in to_delete:
        size_mb = f.stat().st_size / (1024 * 1024)
        print(f"  {f.name}  ({size_mb:.2f} MB)")

    if args.delete:
        for f in to_delete:
            f.unlink()
            print(f"  DELETED: {f.name}")
        print(f"\nDeleted {len(to_delete)} file(s).")
    else:
        print(f"\nDry-run mode. Use --delete to actually remove these files.")


if __name__ == "__main__":
    main()
