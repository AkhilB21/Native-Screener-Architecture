"""Apollo Central Data Repository (v4.10)

Parquet-based canonical OHLCV storage with multi-source sync.
All build versions point to a single shared data directory
(configured in apollo_core/config.py → APOLLO_DATA_ROOT).
No more per-build apollo_data/ duplication.

Usage
-----
    from data_repo import list_symbols, load_daily

    # List all available symbols
    syms = list_symbols(r"D:\\Apollo_Data")

    # Load daily OHLCV for one stock (with columns pruning)
    df = load_daily(r"D:\\Apollo_Data", "CYIENTDLM", columns=["close"])

    # Sync from eod2 CSVs into the central Parquet repo
    python -m data_repo.sync --source-dir <eod2_path> --repo-dir D:\\Apollo_Data --update

Public API
----------
    list_symbols(repo_dir)  — return sorted list of available symbols
    load_daily(repo_dir, symbol, columns=None) — return daily OHLCV DataFrame
    get_manifest(repo_dir)  — return manifest dict
    scan_parquet_repo(repo_dir) — return scan metadata list
"""

from data_repo.repo import (
    list_symbols,
    load_daily,
    save_daily,
    get_manifest,
    scan_parquet_repo,
)

__all__ = [
    "list_symbols",
    "load_daily",
    "save_daily",
    "get_manifest",
    "scan_parquet_repo",
]
