"""Apollo Live Engine — CLI entry point.

Run the live signal monitor on a single stock from the command line.

Usage
-----
    python -m live_engine --symbol CYIENTDLM --data-dir data \\
        --start 2024-01-01 --end 2024-06-30

    # With a specific exit mode
    python -m live_engine --symbol CYIENTDLM --exit-mode FIXED_SL --sl-percent 5

    # Fresh start (don't resume from saved state)
    python -m live_engine --symbol CYIENTDLM --no-resume

    # Quiet mode (only print alerts, no per-bar HOLD/WAIT spam)
    python -m live_engine --symbol CYIENTDLM --quiet

    # Human-confirm mode (Step 3) — EXIT alerts become PENDING,
    # position is NOT auto-reset. Use the dashboard to confirm.
    python -m live_engine --symbol CYIENTDLM --no-auto-confirm

    # Headless mode (v1.4) — routes to run_headless.py with AlertManager
    # (file log + optional Telegram). Best for VPS / cloud deployment.
    python -m live_engine --headless --watchlist my_watchlist.json

Options
-------
    --symbol            NSE stock symbol (e.g., CYIENTDLM). Required.
    --data-dir          Directory containing {symbol}.csv. Default: data
    --start             Replay start date (YYYY-MM-DD). Default: 2024-01-01
    --end               Replay end date (YYYY-MM-DD). Default: today
    --db                SQLite state DB path. Default: live_state.db
    --exit-mode         NONE | FIXED_SL | TRAILING_SL | DUAL_SL | DI_CROSSOVER
                        Default: NONE
    --sl-percent        Hard SL % (FIXED_SL / DUAL_SL). Default: 5.0
    --trailing-sl       Trailing SL % (TRAILING_SL / DUAL_SL). Default: 3.0
    --entry-thresh      Score threshold for entry. Default: 70
    --exit-thresh       Score threshold for exit. Default: 50
    --no-resume         Don't resume from saved state; start fresh.
    --no-auto-confirm   Don't auto-confirm exits. EXIT alerts become PENDING.
                        Use the dashboard's Confirm Exit button to close.
                        (Phase 2 Step 3 — human-in-the-loop mode.)
    --quiet             Only print ENTRY/EXIT/COOLDOWN alerts (skip HOLD/WAIT).
    --list-alerts       Just list saved alerts for this symbol and exit.
    --headless          (v1.4) Use the headless runner with AlertManager
                        (file log + Telegram). For VPS / cloud deployment.
    --watchlist         (v1.3) Path to watchlist JSON for multi-stock mode.
    --pace-seconds      (v1.3) Seconds per bar in multi-stock mode. Default: 2.0.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from datetime import datetime

import pandas as pd

from live_engine.data_replay import BarReplay
from live_engine.state_store import StateStore
from live_engine.signal_monitor import (
    SignalMonitor,
    ALERT_ENTRY, ALERT_EXIT, ALERT_COOLDOWN, ALERT_HOLD, ALERT_WAIT,
)


DEFAULT_DATA_DIR = "data"
DEFAULT_DB_PATH = "live_state.db"
DEFAULT_START_DATE = "2024-01-01"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="apollo-live",
        description="Apollo Live Engine — signal monitor for NSE stocks",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # --symbol is no longer required when --watchlist is given (v1.3).
    p.add_argument("--symbol", default=None,
                   help="NSE stock symbol (e.g., CYIENTDLM). Required if --watchlist is not given.")
    p.add_argument("--watchlist", default=None,
                   help="Path to watchlist JSON file (e.g., my_watchlist.json). "
                        "When given, runs multi-stock mode: monitors all watchlist "
                        "stocks whose CSV is in --data-dir. (v1.3)")
    p.add_argument("--pace-seconds", type=float, default=2.0,
                   help="Seconds to sleep between bars in multi-stock mode. "
                        "0 = no pacing (instant). Default: 2.0. (v1.3)")
    p.add_argument("--data-dir", default=DEFAULT_DATA_DIR,
                   help=f"Directory containing {{symbol}}.csv (default: {DEFAULT_DATA_DIR})")
    p.add_argument("--start", default=DEFAULT_START_DATE,
                   help=f"Replay start date YYYY-MM-DD (default: {DEFAULT_START_DATE})")
    p.add_argument("--end", default=None,
                   help="Replay end date YYYY-MM-DD (default: today)")
    p.add_argument("--db", default=DEFAULT_DB_PATH,
                   help=f"SQLite state DB path (default: {DEFAULT_DB_PATH})")
    p.add_argument("--exit-mode", default="NONE",
                   choices=["NONE", "FIXED_SL", "TRAILING_SL", "DUAL_SL", "DI_CROSSOVER"],
                   help="Exit mode (default: NONE)")
    p.add_argument("--sl-percent", type=float, default=5.0,
                   help="Hard SL %% (default: 5.0)")
    p.add_argument("--trailing-sl", type=float, default=3.0,
                   help="Trailing SL %% (default: 3.0)")
    p.add_argument("--entry-thresh", type=float, default=70.0,
                   help="Entry score threshold (default: 70)")
    p.add_argument("--exit-thresh", type=float, default=50.0,
                   help="Exit score threshold (default: 50)")
    p.add_argument("--no-resume", action="store_true",
                   help="Don't resume from saved state; start fresh")
    p.add_argument("--no-auto-confirm", action="store_true",
                   help="Don't auto-confirm exits (Step 3). EXIT alerts "
                        "become PENDING; use the dashboard to confirm.")
    p.add_argument("--quiet", action="store_true",
                   help="Only print ENTRY/EXIT/COOLDOWN alerts")
    p.add_argument("--list-alerts", action="store_true",
                   help="List saved alerts for this symbol and exit")
    p.add_argument("--headless", action="store_true",
                   help="(v1.4) Use the headless runner with AlertManager "
                        "(file log + Telegram). For VPS / cloud deployment. "
                        "Delegates to run_headless.main().")
    p.add_argument("--no-telegram", action="store_true",
                   help="(v1.4, --headless only) Disable Telegram push. "
                        "File log still active.")
    p.add_argument("--reports-dir", default="reports",
                   help="(v1.4, --headless only) Directory for alerts.log. "
                        "Default: reports")
    return p


def _alert_callback_factory(quiet: bool, multi: bool = False):
    """Build a callback that prints alerts to stdout.

    If ``multi=True`` (v1.3 multi-stock mode), the callback signature is
    ``(alert, symbol)`` instead of ``(alert)``.
    """
    loud_types = {ALERT_ENTRY, ALERT_EXIT, ALERT_COOLDOWN}

    if multi:
        def callback(alert: dict, symbol: str) -> None:
            if quiet and alert["alert_type"] not in loud_types:
                return
            ts = alert["timestamp"]
            if hasattr(ts, "strftime"):
                ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")
            else:
                ts_str = str(ts)
            print(f"[{ts_str}] [{symbol:12s}] [{alert['alert_type']:8s}] {alert['message']}")
        return callback

    def callback(alert: dict) -> None:
        if quiet and alert["alert_type"] not in loud_types:
            return
        ts = alert["timestamp"]
        if hasattr(ts, "strftime"):
            ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")
        else:
            ts_str = str(ts)
        print(f"[{ts_str}] [{alert['alert_type']:8s}] {alert['message']}")
    return callback


def cmd_list_alerts(args: argparse.Namespace) -> int:
    """List saved alerts for the symbol and exit."""
    db_path = Path(args.db)
    if not db_path.exists():
        print(f"No state DB found at {db_path}")
        return 1

    with StateStore(db_path) as store:
        alerts = store.list_alerts(symbol=args.symbol)
        if not alerts:
            print(f"No alerts found for {args.symbol} in {db_path}")
            return 0

        print(f"=== Alerts for {args.symbol} ({len(alerts)} total) ===")
        for a in alerts:
            print(f"[{a['timestamp']}] [{a['alert_type']:8s}] {a['message']}")
            if a.get("payload_json"):
                print(f"    payload: {a['payload_json'][:200]}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.list_alerts:
        return cmd_list_alerts(args)

    # ----- Headless mode (v1.4) — delegate to run_headless.main() -----
    if args.headless:
        from live_engine.run_headless import main as headless_main
        # Forward all relevant args. run_headless has its own argparse; we
        # rebuild the argv from the parsed args + any extra flags.
        forward_argv: list[str] = []
        if args.symbol:
            forward_argv.extend(["--symbol", args.symbol])
        if args.watchlist:
            forward_argv.extend(["--watchlist", args.watchlist])
        forward_argv.extend(["--data-dir", args.data_dir])
        forward_argv.extend(["--start", args.start])
        if args.end:
            forward_argv.extend(["--end", args.end])
        forward_argv.extend(["--db", args.db])
        forward_argv.extend(["--exit-mode", args.exit_mode])
        forward_argv.extend(["--sl-percent", str(args.sl_percent)])
        forward_argv.extend(["--trailing-sl", str(args.trailing_sl)])
        forward_argv.extend(["--entry-thresh", str(args.entry_thresh)])
        forward_argv.extend(["--exit-thresh", str(args.exit_thresh)])
        if args.no_resume:
            forward_argv.append("--no-resume")
        if args.no_auto_confirm:
            # In headless, default is PENDING (no auto-confirm); --no-auto-confirm
            # here is a no-op (matches headless default). We just don't add --auto-confirm.
            pass
        else:
            # User did NOT pass --no-auto-confirm to cli.py, meaning they want
            # auto-confirm ON. Forward --auto-confirm to headless.
            forward_argv.append("--auto-confirm")
        if args.quiet:
            forward_argv.append("--quiet")
        if args.no_telegram:
            forward_argv.append("--no-telegram")
        forward_argv.extend(["--reports-dir", args.reports_dir])
        if args.pace_seconds is not None:
            forward_argv.extend(["--pace-seconds", str(args.pace_seconds)])
        return headless_main(forward_argv)

    end_date = args.end or datetime.utcnow().strftime("%Y-%m-%d")

    # ----- Multi-stock mode (v1.3) -----
    if args.watchlist is not None:
        from live_engine.watchlist import list_available_symbols as load_available_symbols
        from live_engine.multi_monitor import MultiStockMonitor

        symbols = load_available_symbols(
            watchlist_path=args.watchlist,
            data_dir=args.data_dir,
        )
        if not symbols:
            print(f"ERROR: No watchlist stocks have CSVs in {args.data_dir}")
            print(f"Watchlist file: {args.watchlist}")
            print(f"Either drop CSVs in the data dir, or remove --watchlist to run single-stock mode.")
            return 2

        print(f"Apollo Live Engine v1.3 — Multi-Stock Monitor")
        print(f"  Watchlist:  {args.watchlist}")
        print(f"  Data dir:   {args.data_dir}")
        print(f"  Symbols:    {len(symbols)} ({', '.join(symbols[:5])}"
              f"{'...' if len(symbols) > 5 else ''})")
        print(f"  Date range: {args.start} → {end_date}")
        print(f"  Exit mode:  {args.exit_mode}")
        print(f"  Pace:       {args.pace_seconds}s per bar")
        print(f"  State DB:   {args.db}")
        print(f"  Resume:     {not args.no_resume}")
        print()

        callback = _alert_callback_factory(quiet=args.quiet, multi=True)
        monitor = MultiStockMonitor(
            symbols=symbols,
            data_dir=args.data_dir,
            start_date=args.start,
            end_date=end_date,
            db_path=args.db,
            pace_seconds=args.pace_seconds,
            exit_mode=args.exit_mode,
            sl_percent=args.sl_percent,
            trailing_sl_percent=args.trailing_sl,
            entry_threshold=args.entry_thresh,
            exit_threshold=args.exit_thresh,
            auto_confirm_exit=not args.no_auto_confirm,
            alert_callback=callback,
            resume=not args.no_resume,
            verbose=not args.quiet,
        )
        summary = monitor.run()

        print()
        print(f"Done. {summary['n_symbols']} symbols, {summary['n_ticks']} ticks, "
              f"{summary['total_entries']} entries, {summary['total_exits']} exits.")
        print(f"State saved to {args.db}.")
        return 0

    # ----- Single-stock mode (v1.0+ compatible) -----
    if args.symbol is None:
        parser.error("--symbol is required when --watchlist is not given")

    print(f"Apollo Live Engine v1.3 — Signal Monitor (single-stock)")
    print(f"  Symbol:    {args.symbol}")
    print(f"  Data dir:  {args.data_dir}")
    print(f"  Date range:{args.start} → {end_date}")
    print(f"  Exit mode: {args.exit_mode}")
    print(f"  State DB:  {args.db}")
    print(f"  Resume:    {not args.no_resume}")
    print()

    # Build replay
    replay = BarReplay(
        data_dir=args.data_dir,
        symbol=args.symbol,
        start_date=args.start,
        end_date=end_date,
        entry_threshold=args.entry_thresh,
        exit_threshold=args.exit_thresh,
    )

    # Verify CSV exists
    csv_path = Path(args.data_dir) / f"{args.symbol}.csv"
    if not csv_path.exists():
        print(f"ERROR: CSV not found at {csv_path}")
        return 2

    # Open state store
    with StateStore(args.db) as store:
        callback = _alert_callback_factory(quiet=args.quiet)
        monitor = SignalMonitor(
            replay=replay,
            state_store=store,
            alert_callback=callback,
            exit_mode=args.exit_mode,
            sl_percent=args.sl_percent,
            trailing_sl_percent=args.trailing_sl,
            entry_threshold=args.entry_thresh,
            exit_threshold=args.exit_thresh,
            auto_confirm_exit=not args.no_auto_confirm,
        )
        summary = monitor.run(resume=not args.no_resume, verbose=not args.quiet)

    print()
    print(f"Done. {summary['n_alerts']} alerts emitted, "
          f"{summary['n_entries']} entries, {summary['n_exits']} exits.")
    print(f"State saved to {args.db}. Run with --list-alerts to view all alerts.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
