@echo off
REM ============================================================
REM  Apollo v4.10 — Sync eod2 CSVs into CENTRAL Parquet Repository
REM ============================================================
REM
REM  Central Data Repository: all build versions share ONE data
REM  directory. No more per-build duplication (saves 150-200MB per
REM  version). APOLLO_DATA_ROOT must match apollo_core/config.py.
REM
REM  Edit EOD2_PATH to point to YOUR eod2 daily data folder.
REM  Edit REPO_DIR to match APOLLO_DATA_ROOT in apollo_core/config.py.
REM

set EOD2_PATH=C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\eod2-main\eod2-main\src\eod2_data\daily
REM === MUST match APOLLO_DATA_ROOT in apollo_core/config.py ===
set REPO_DIR=D:\Apollo_Data

echo.
echo ============================================================
echo   APOLLO v4.10 — DATA SYNC (eod2 CSVs -^> Central Parquet Repo)
echo ============================================================
echo   Source: %EOD2_PATH%
echo   Repo:   %REPO_DIR%
echo   Note:   All build versions read from this central location.
echo.

python -m data_repo.sync --source-dir "%EOD2_PATH%" --repo-dir %REPO_DIR% --update

echo.
echo Sync complete. All build versions will use %REPO_DIR%.
echo Now run:
echo   streamlit run backtest_engine\app.py
echo   OR
echo   python -m live_engine
echo.
pause
