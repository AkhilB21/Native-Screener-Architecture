"""Apollo Engine Constants — Signal definitions, pool metadata, thresholds. (v4.8)"""

ENTRY_THRESHOLD = 70
EXIT_THRESHOLD = 50
DIVERGENCE_RSI_DROP = 3.0
DIVERGENCE_COOLDOWN = 5

# Renko Hard Gate (Option B): minimum bullish R-points required for BUY entry.
# R-points < RENKO_HARD_GATE blocks entry regardless of score.
# Set to 0 to disable (pure score-based entry).
RENKO_HARD_GATE = 0  # v4.8: disabled — Renko points are additive, never gate

SIGNAL_DEFS = [
    # Pool A — RSI Recovery (48 pts)  [was 42 — v4.1: added A7]
    ("A1", "Trough Detected (D)", "A", 10),
    ("A2", "Trough Detected (4H)", "A", 8),
    ("A3", "Recovery Momentum (D)", "A", 8),
    ("A4", "Recovery Momentum (4H)", "A", 6),
    ("A5", "RSI21 > 50 (4H)", "A", 6),
    ("A6", "Multi-Speed Alignment (D)", "A", 4),
    ("A7", "Extended Recovery (D)", "A", 6),
    # Pool B — Price Structure (30 pts)  [v4.1: B3 zone widened]
    ("B1", "Close > TP28 (4H)", "B", 7),
    ("B2", "Close > WC50 (4H)", "B", 6),
    ("B3", "Approaching D-TP28 (D)", "B", 5),
    ("B4", "Higher Low Forming (D)", "B", 4),
    ("B5", "Price > Trough+10% (D)", "B", 3),
    ("B6", "WC21 Proximity (4H)", "B", 5),
    # Pool C — Multi-TF Confirmation (18 pts)
    ("C1", "Cross-TF Trough Agree", "C", 6),
    ("C2", "4H RSI36 > 45", "C", 4),
    ("C3", "W-RSI56 > 50 (prev W)", "C", 4),
    ("C4", "D-RSI21 > 45", "C", 4),
    # Bonus A — Volume/Support (14 pts)  [was 8 — v4.1: BA1 re-enabled, BA4 added]
    ("BA1", "Selling Exhaustion", "BA", 3),
    ("BA2", "Price > Trough+10%", "BA", 3),
    ("BA3", "4H Volume Expansion", "BA", 2),
    ("BA4", "Volume Contraction (Base)", "BA", 3),
    # Bonus B — Uptrend Context (10 pts)
    ("BB1", "52W High > Curr*1.5", "BB", 3),
    ("BB2", "Multi-Touch Support", "BB", 4),
    ("BB3", "Weekly RSI Reversal", "BB", 3),
    # Bonus C — Trend Momentum (5 pts)
    ("BC1", "ADX > -DI (D)", "BC", 2.5),
    ("BC2", "MACD > 0 (D)", "BC", 2.5),
    # Bonus D — Breakout Detection (13 pts)  [NEW in v4.1]
    ("BD1", "Breakout Confirmation", "BD", 8),
    ("BD2", "Consolidation Squeeze", "BD", 5),
    # Pool R — Renko Confirmation (27 pts)  [v4.3: 20pts, v4.4: +7pts]
    ("R1", "Renko RSI Oversold Recovery", "R", 5),
    ("R2", "Renko RSI Above 50", "R", 4),
    ("R3", "Renko Brick Pattern Bullish", "R", 3),
    ("R4", "Renko Trend Alignment", "R", 3),
    ("R5", "Renko 4H Lead Signal", "R", 3),
    ("R6", "Renko No Bearish Divergence", "R", 2),
    # Pool R — Renko Divergence  [NEW in v4.4]
    ("R7", "Renko Bullish Divergence", "R", 4),
    ("R8", "Renko Hidden Bullish Divergence", "R", 3),
    # Bonus D — Divergence (candlestick)  [NEW in v4.4]
    ("D1", "Hidden Bullish Divergence (D)", "BD", 5),
    # Pool E — Environment / Equity Analytics (21 pts)  [NEW in v4.7]
    ("E1", "Near 52W Low (D)", "E", 5),
    ("E2", "Stochastic Oversold Turn (D)", "E", 5),
    ("E3", "Relative Volume Surge (D)", "E", 4),
    ("E4", "VPT Accumulation (D)", "E", 4),
    ("E5", "50-SMA Recovery Zone (D)", "E", 3),
]

# ─────────────────────────────────────────────────────────────────────
# IPO Scoring Signals (for stocks with insufficient trading history)
# ─────────────────────────────────────────────────────────────────────
# These signals evaluate recently listed IPOs on observable post-listing
# characteristics instead of the trough-recovery narrative.  The total
# max is 69 points, normalized to 0-100 for comparison with mature stocks.

IPO_SIGNAL_DEFS = [
    # Pool IM — Momentum (27 pts)
    ("I1",  "RSI Healthy Zone (D)",     "IM", 8),
    ("I2",  "RSI Healthy Zone (4H)",    "IM", 6),
    ("I3",  "Price Above Listing Close","IM", 5),
    ("I4",  "4H RSI Stability",          "IM", 8),
    # Pool IS — Structure (21 pts)
    ("I5",  "Higher Highs Since List",  "IS", 7),
    ("I6",  "Higher Lows Since List",   "IS", 5),
    ("I7",  "Listing Low Intact",       "IS", 4),
    ("I8",  "Narrowing Volatility",     "IS", 5),
    # Pool IV — Volume & Trend (21 pts)
    ("I9",  "Volume Trend Positive",    "IV", 5),
    ("I10", "20-DMA Slope Up",          "IV", 6),
    ("I11", "Price Above 20-DMA",       "IV", 5),
    ("I12", "Multi-TF Trend Align",     "IV", 5),
]

IPO_POOL_ORDER = ["IM", "IS", "IV"]
IPO_POOL_MAX = {"IM": 27, "IS": 21, "IV": 21}
IPO_POOL_NAMES = {
    "IM": "Momentum",
    "IS": "Structure",
    "IV": "Volume & Trend",
}

# Minimum trading days in daily data for a stock to be considered "mature"
# (enough history for 200-DMA and trough detection).  Below this → IPO path.
DEFAULT_MIN_TRADING_DAYS = 60

# ─────────────────────────────────────────────────────────────────────
# Gate Display Thresholds (v4.8) — INFORMATIONAL ONLY, never block entry.
# These values are used for colour-coding and dashboard display columns.
# The scoring engine computes them per bar but does NOT enforce them.
#   G1: PE Sanity      — colour flag if trailing PE is <= 0 or > PE_MAX.
#   G2: Liquidity Floor — colour flag if 20-day avg traded value is low.
#   G3: 52W-Low Proximity — colour flag if stock is far above 52W low.
#   G4: 52W-High Distance — colour flag if stock is near 52W high.
# ─────────────────────────────────────────────────────────────────────
PE_MAX = 100.0
MIN_AVG_TRADED_VALUE = 200_000_000.0     # ₹20 Cr/day (volume*close, 20-day avg)
MAX_52W_LOW_DIST = 0.75                  # close <= 1.75x trailing 52W low
MIN_52W_HIGH_DIST_MULT = 1.10            # trailing 52W high >= 1.10x close

POOL_MAX = {"A": 48, "B": 30, "C": 18, "BA": 14, "BB": 10, "BC": 5, "BD": 18, "R": 27, "E": 21}
POOL_ORDER = ["A", "B", "C", "BA", "BB", "BC", "BD", "R", "E"]
POOL_NAMES = {
    "A": "Pool A (RSI Recovery)",
    "B": "Pool B (Price Structure)",
    "C": "Pool C (Multi-TF Confirm)",
    "BA": "Bonus A (Volume/Support)",
    "BB": "Bonus B (Uptrend Context)",
    "BC": "Bonus C (Trend Momentum)",
    "BD": "Bonus D (Breakout Detect)",
    "R": "Pool R (Renko Confirm)",
    "E": "Pool E (Equity Analytics)",
}
POOL_DESC = {
    "A": "Trough Detection, Recovery Momentum, Extended Recovery, Cross-TF RSI Alignment",
    "B": "TP28 Conv, WC50 Conv, Price Prox TP28, Higher Low, Price vs Trough, WC21 Proximity",
    "C": "Cross-TF Trough Agree, 4H RSI36>45, W-RSI56>50, D-RSI21>45",
    "BA": "Selling Exhaustion, Price>Trough+10%, 4H Volume Expansion, Volume Contraction",
    "BB": "52W High, Multi-Touch Support, Weekly RSI Reversal",
    "BC": "ADX Directional, MACD Bullish",
    "BD": "Breakout Confirmation, Consolidation Squeeze, Hidden Bullish Divergence (D)",
    "R": "Renko RSI Recovery, RSI>50, Brick Pattern, Trend Align, 4H Lead, No Bear Div, Bull Div, Hidden Bull Div",
    "E": "Near 52W Low, Stochastic Oversold Turn, Relative Volume Surge, VPT Accumulation, 50-SMA Recovery Zone",
}

EXIT_MODE_DEFS = {
    "NONE": {
        "label": "None",
        "description": "No stop-loss — exits only via score drop or divergence detection.",
    },
    "FIXED_SL": {
        "label": "Fixed SL",
        "description": "Hard stop-loss at a fixed % below the entry price (gap-down aware).",
    },
    "TRAILING_SL": {
        "label": "Trailing SL",
        "description": "Stop-loss trails from the highest close seen since entry.",
    },
    "DUAL_SL": {
        "label": "Dual SL",
        "description": "Hard SL always on + trailing SL activates after price rises above entry.",
    },
    "DI_CROSSOVER": {
        "label": "DI Crossover",
        "description": "Exit when +DI crosses below -DI on the daily timeframe.",
    },
}