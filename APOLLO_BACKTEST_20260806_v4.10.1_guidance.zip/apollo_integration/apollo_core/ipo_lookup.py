"""IPO Listing Date Lookup for Apollo Backtest Engine.

Provides accurate IPO detection using scraped listing-date data from
chittorgarh.com instead of relying solely on bar-count heuristics.

Architecture
------------
  - Primary method: If the NSE symbol is found in ``ipo_listing_dates.json``
    and has a valid ``listing_date``, compute trading days since listing
    from the daily DataFrame's DatetimeIndex.
  - Fallback method: If the symbol is NOT in the lookup, or has no
    ``listing_date`` (upcoming IPO), fall back to the existing
    ``len(df_d) < min_trading_days`` bar-count heuristic.

The lookup JSON lives at ``<project_root>/ipo_listing_dates.json`` and
contains 2026 mainboard IPO data scraped from chittorgarh.com.

Functions
---------
  load_ipo_lookup          — load the JSON (cached per process)
  get_ipo_info             — query by NSE symbol, returns dict or None
  is_ipo_by_listing_date   — listing-date-aware IPO detection
  refresh_ipo_lookup       — force-reload (e.g., after JSON update)
"""

from __future__ import annotations

import json
from datetime import datetime, date
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Module-level cache
# ---------------------------------------------------------------------------

_lookup_cache: dict[str, Any] | None = None
_lookup_path: Path | None = None


def _find_lookup_file(project_root: str | None = None) -> Path | None:
    """Locate ipo_listing_dates.json relative to the project root.

    Search order:
      1. Explicit ``project_root`` / ipo_listing_dates.json
      2. Two directories up from this file (package dir → project root)
      3. Current working directory
    """
    candidates = []

    if project_root:
        candidates.append(Path(project_root) / "ipo_listing_dates.json")

    # Default: this file is at apollo_engine/ipo_lookup.py → ../ipo_listing_dates.json
    this_dir = Path(__file__).resolve().parent
    candidates.append(this_dir.parent / "ipo_listing_dates.json")

    # Also check CWD
    candidates.append(Path.cwd() / "ipo_listing_dates.json")

    for p in candidates:
        if p.is_file():
            return p

    return None


def load_ipo_lookup(project_root: str | None = None) -> dict[str, Any]:
    """Load and cache the IPO listing dates JSON.

    Returns the full dict (including ``_metadata`` key) or an empty dict
    if the file is not found.  Results are cached for the process lifetime.
    """
    global _lookup_cache, _lookup_path

    if _lookup_cache is not None:
        return _lookup_cache

    path = _find_lookup_file(project_root)
    _lookup_path = path

    if path is None:
        _lookup_cache = {}
        return _lookup_cache

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        _lookup_cache = data
        return data
    except (json.JSONDecodeError, OSError):
        _lookup_cache = {}
        return _lookup_cache


def refresh_ipo_lookup(project_root: str | None = None) -> dict[str, Any]:
    """Force-reload the lookup JSON (e.g., after a manual update)."""
    global _lookup_cache
    _lookup_cache = None
    return load_ipo_lookup(project_root)


def get_ipo_info(
    symbol: str,
    project_root: str | None = None,
) -> dict[str, Any] | None:
    """Look up IPO metadata for an NSE symbol.

    Parameters
    ----------
    symbol : str
        NSE trading symbol (e.g., "SBIFUNDS", "HEXAGON").  Case-insensitive.
    project_root : str, optional
        Path to the Apollo project root directory.

    Returns
    -------
    dict or None
        If found and listed (has a listing_date), returns dict with keys:
            company, listing_date, issue_price, listing_close, isin, bse_code
        If found but upcoming (no listing_date), returns None (treated as
        not-yet-listed, will fall through to bar-count heuristic).
        If not found at all, returns None.
    """
    lookup = load_ipo_lookup(project_root)
    entry = lookup.get(symbol.upper())

    if entry is None or not isinstance(entry, dict):
        return None

    # Skip upcoming (not yet listed)
    if entry.get("listing_date") is None:
        return None

    return entry


def is_ipo_by_listing_date(
    symbol: str,
    df_d: pd.DataFrame,
    min_trading_days: int,
    project_root: str | None = None,
) -> tuple[bool, dict]:
    """Determine if a stock is an IPO using listing-date lookup + bar-count.

    Priority:
      1. If symbol found in lookup with valid listing_date → count actual
         trading days since listing in df_d's DatetimeIndex.  If that count
         < min_trading_days → IPO.
      2. If symbol NOT in lookup → fall back to ``len(df_d) < min_trading_days``.
      3. If symbol in lookup but listing_date is in the future (upcoming) →
         not yet listed, return (False, {...}).

    Parameters
    ----------
    symbol : str
        NSE trading symbol.
    df_d : pd.DataFrame
        Daily OHLCV with DatetimeIndex.
    min_trading_days : int
        Minimum trading days for a stock to be considered mature.
    project_root : str, optional
        Apollo project root path.

    Returns
    -------
    (is_ipo, info_dict)
        is_ipo : bool  — True if the stock should use IPO scoring.
        info_dict : dict — metadata about the detection:
            - "method": "listing_date" | "bar_count"
            - "n_bars": int (bars in df_d)
            - "min_required": int
            - "listing_date": str | None (ISO date if known)
            - "listing_close": float | None
            - "issue_price": float | None
            - "company": str | None
            - "days_since_listing": int | None (trading days, if lookup used)
    """
    n_bars = len(df_d)
    fallback_info = {
        "method": "bar_count",
        "n_bars": n_bars,
        "min_required": min_trading_days,
        "listing_date": None,
        "listing_close": None,
        "issue_price": None,
        "company": None,
        "days_since_listing": None,
    }

    # Check lookup
    ipo_info = get_ipo_info(symbol, project_root)

    if ipo_info is not None:
        listing_date_str = ipo_info.get("listing_date")
        try:
            listing_dt = pd.Timestamp(listing_date_str)
        except Exception:
            # Bad date format in JSON — fall through to bar count
            return n_bars < min_trading_days, fallback_info

        # Count trading days since listing in the DataFrame
        if hasattr(df_d.index, "date") and callable(df_d.index.date):
            # DatetimeIndex
            mask = df_d.index >= listing_dt
            days_since_listing = int(mask.sum())
        else:
            # Try parsing
            try:
                dates = pd.to_datetime(df_d.index)
                mask = dates >= listing_dt
                days_since_listing = int(mask.sum())
            except Exception:
                days_since_listing = n_bars  # can't determine, use total bars

        info = {
            "method": "listing_date",
            "n_bars": n_bars,
            "min_required": min_trading_days,
            "listing_date": listing_date_str,
            "listing_close": ipo_info.get("listing_close"),
            "issue_price": ipo_info.get("issue_price"),
            "company": ipo_info.get("company"),
            "days_since_listing": days_since_listing,
        }

        if days_since_listing < min_trading_days:
            return True, info
        else:
            # Stock has been listed long enough — it's mature now
            return False, info

    # Symbol not in lookup — fall back to bar count
    return n_bars < min_trading_days, fallback_info


def get_listing_close_price(
    symbol: str,
    df_d: pd.DataFrame,
    project_root: str | None = None,
) -> float | None:
    """Get the best available listing close price for an IPO stock.

    Priority:
      1. ``listing_close`` from ipo_listing_dates.json
      2. First bar's close from df_d (existing heuristic)

    Returns None if the symbol is not an IPO.
    """
    ipo_info = get_ipo_info(symbol, project_root)
    if ipo_info is not None:
        lc = ipo_info.get("listing_close")
        if lc is not None and lc > 0:
            return float(lc)

    # Fallback: first bar close
    if len(df_d) > 0 and "close" in df_d.columns:
        val = df_d["close"].iloc[0]
        if not np.isnan(val):
            return float(val)

    return None


def get_lookup_stats(project_root: str | None = None) -> dict:
    """Return summary statistics about the loaded lookup.

    Useful for displaying in the UI sidebar.
    """
    lookup = load_ipo_lookup(project_root)
    metadata = lookup.get("_metadata", {})
    total_entries = sum(1 for k, v in lookup.items() if not k.startswith("_") and isinstance(v, dict))
    listed = sum(1 for k, v in lookup.items()
                 if not k.startswith("_") and isinstance(v, dict)
                 and v.get("listing_date") is not None)
    upcoming = total_entries - listed

    return {
        "source": metadata.get("source", "N/A"),
        "scraped_date": metadata.get("scraped_date", "N/A"),
        "total": total_entries,
        "listed": listed,
        "upcoming": upcoming,
        "file_path": str(_lookup_path) if _lookup_path else "Not found",
    }