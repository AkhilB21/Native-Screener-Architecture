"""Regime Pre-Filter — Pass List Loader (v4.9)

Loads the pass_list.json produced by regime_prefilter_v2.py and provides
a simple interface for the backtest engine and NSE engine to check whether
a symbol is allowed through the pre-filter gate.

The pre-filter is an UPSTREAM UNIVERSE REDUCTION gate.  It runs BEFORE
the scoring engine.  Stocks that fail are excluded from backtesting
entirely — they never reach the scoring path.

Tiers:
  PASS            → allowed (full access)
  RESTRICTED_PASS → allowed (flagged, full access)
  EXCLUDE         → blocked
  WATCH           → allowed (quality label only, never a rejection)

Usage:
  from apollo_core.regime_prefilter import load_pass_list, is_symbol_allowed

  pass_list = load_pass_list("pass_list.json")
  if pass_list and is_symbol_allowed(pass_list, "RELIANCE"):
      run_backtest(...)
"""

from __future__ import annotations

import json
import logging
from collections import Counter
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def load_pass_list(path: str) -> dict[str, Any] | None:
    """Load and validate a pass_list.json file.

    Returns the parsed dict if valid, or None if:
      - file does not exist
      - file is not valid JSON
      - required keys ("totals", "pass_symbols") are missing

    The returned dict has (at minimum):
      totals.total_stocks, totals.pass, totals.exclude, totals.restricted_pass
      pass_symbols: list of allowed symbols
      restricted_pass: list of protected recovery symbols
      excluded: list of excluded symbols with reasons
      watch_symbols: list of watch-labelled symbols
      per_stock: list of per-stock detail dicts
    """
    p = Path(path)
    if not p.exists():
        logger.debug("Pass list not found at %s", path)
        return None

    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as exc:
        logger.warning("Failed to parse pass list %s: %s", path, exc)
        return None

    # Validate minimum structure
    if not isinstance(data, dict) or "totals" not in data:
        logger.warning("Pass list missing 'totals' key: %s", path)
        return None

    totals = data["totals"]
    if not isinstance(totals, dict) or "total_stocks" not in totals:
        logger.warning("Pass list 'totals' missing 'total_stocks': %s", path)
        return None

    logger.info(
        "Loaded pass list: %d stocks (PASS=%d, RESTRICTED=%d, EXCLUDE=%d, WATCH=%d)",
        totals.get("total_stocks", 0),
        totals.get("pass", 0),
        totals.get("restricted_pass", 0),
        totals.get("exclude", 0),
        len(data.get("watch_symbols", [])),
    )
    return data


def is_symbol_allowed(pass_list: dict[str, Any], symbol: str) -> bool:
    """Check if a symbol is allowed through the regime pre-filter.

    Allowed tiers: PASS, RESTRICTED_PASS, and any symbol with WATCH label.
    Only EXCLUDE tier is blocked.

    Parameters
    ----------
    pass_list : dict
        The loaded pass_list.json dict from load_pass_list().
    symbol : str
        Uppercase symbol string (e.g. "RELIANCE").

    Returns
    -------
    bool
        True if the symbol should be processed by the engine.
    """
    if pass_list is None:
        # No pass list → filter not active → allow everything
        return True

    sym_upper = symbol.upper().strip()

    # Check explicit exclusion list
    for exc in pass_list.get("excluded", []):
        if exc.get("symbol", "").upper() == sym_upper:
            return False

    # If symbol is in pass_symbols or restricted_pass or watch_symbols, allow
    allowed_sets = [
        pass_list.get("pass_symbols", []),
        pass_list.get("restricted_pass", []),
        pass_list.get("watch_symbols", []),
    ]
    for allowed_list in allowed_sets:
        if isinstance(allowed_list, list):
            for item in allowed_list:
                # Items may be strings (pass_symbols) or dicts (restricted_pass)
                if isinstance(item, str) and item.upper() == sym_upper:
                    return True
                elif isinstance(item, dict) and item.get("symbol", "").upper() == sym_upper:
                    return True

    # Symbol not found in any list — allow by default (unknown symbols pass)
    return True


def get_symbol_tier(pass_list: dict[str, Any], symbol: str) -> str:
    """Return the tier string for a symbol (PASS/RESTRICTED_PASS/EXCLUDE/UNKNOWN)."""
    if pass_list is None:
        return "UNKNOWN"

    sym_upper = symbol.upper().strip()

    # Check excluded
    for exc in pass_list.get("excluded", []):
        if exc.get("symbol", "").upper() == sym_upper:
            return "EXCLUDE"

    # Check restricted_pass
    for item in pass_list.get("restricted_pass", []):
        s = item if isinstance(item, str) else item.get("symbol", "")
        if s.upper() == sym_upper:
            return "RESTRICTED_PASS"

    # Check pass_symbols
    if sym_upper in [s.upper() for s in pass_list.get("pass_symbols", [])]:
        return "PASS"

    return "UNKNOWN"


def filter_symbols(
    pass_list: dict[str, Any] | None,
    symbols: list[str],
) -> tuple[list[str], dict[str, str]]:
    """Filter a list of symbols through the regime pre-filter.

    Parameters
    ----------
    pass_list : dict or None
        Loaded pass list (None = filter disabled, all pass).
    symbols : list[str]
        Candidate symbols to filter.

    Returns
    -------
    (allowed, tier_map) : tuple
        allowed  — list of symbols that passed the filter
        tier_map — dict mapping every input symbol to its tier string
    """
    if pass_list is None:
        tier_map = {s: "NO_FILTER" for s in symbols}
        return list(symbols), tier_map

    allowed = []
    tier_map = {}
    for sym in symbols:
        tier = get_symbol_tier(pass_list, sym)
        tier_map[sym] = tier
        if tier != "EXCLUDE":
            allowed.append(sym)

    return allowed, tier_map


# ═══════════════════════════════════════════════════════════════════════
# Bucket Classification Layer (from cached pass_list.json)
# ═══════════════════════════════════════════════════════════════════════

# Canonical bucket order for UI display
BUCKET_NAMES = [
    "Trending Up",
    "Recovery — Strengthening",
    "Recovery — Early",
    "Weak / Beaten Down",
    "Range-Bound",
    "Structural Decline",
    "Unclassified",
]


def get_bucket_map(pass_list: dict[str, Any]) -> tuple[dict[str, str], Counter]:
    """Extract symbol-to-bucket mapping from pass_list's per_stock data.

    The regime pre-filter (regime_prefilter_v2.py) already classifies every
    stock into a bucket (Trending Up, Recovery — Early, Structural Decline,
    etc.) and stores it in the ``per_stock`` array. This function extracts
    that cached classification so the UI can offer bucket-based filtering
    WITHOUT re-running the time-consuming classification.

    Parameters
    ----------
    pass_list : dict
        The loaded pass_list.json dict from load_pass_list().

    Returns
    -------
    (bucket_map, bucket_counts) : tuple
        bucket_map    — dict mapping symbol (str) → bucket name (str).
                        Only symbols present in per_stock are included.
        bucket_counts — Counter of bucket names across all stocks.
    """
    bucket_map: dict[str, str] = {}
    bucket_counts: Counter = Counter()

    per_stock = pass_list.get("per_stock", [])
    if not isinstance(per_stock, list):
        return bucket_map, bucket_counts

    for entry in per_stock:
        if not isinstance(entry, dict):
            continue
        sym = entry.get("symbol", "").upper().strip()
        bucket = entry.get("bucket", "Unclassified")
        if sym:
            bucket_map[sym] = bucket
            bucket_counts[bucket] += 1

    return bucket_map, bucket_counts


def filter_by_buckets(
    bucket_map: dict[str, str],
    symbols: list[str],
    selected_buckets: list[str] | None,
) -> list[str]:
    """Filter a symbol list to only those in selected buckets.

    Parameters
    ----------
    bucket_map : dict
        Symbol → bucket name mapping from get_bucket_map().
    symbols : list[str]
        Candidate symbols to filter.
    selected_buckets : list[str] or None
        Bucket names to include. If None or empty, all symbols pass
        through (no bucket filtering).

    Returns
    -------
    list[str]
        Symbols whose bucket is in selected_buckets. Symbols not
        found in bucket_map are INCLUDED (unknown = allow by default).
    """
    if not selected_buckets:
        return list(symbols)

    selected_set = set(selected_buckets)
    return [
        sym for sym in symbols
        if bucket_map.get(sym.upper(), "Unclassified") in selected_set
    ]