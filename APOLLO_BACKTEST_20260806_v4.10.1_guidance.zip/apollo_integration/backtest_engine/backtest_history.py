"""Apollo Backtest Studio — SQLite History Manager. (v4.10)

Provides persistent storage for backtest runs using SQLite.
Each backtest run is saved with its parameters and complete results,
enabling historical comparison, parameter analytics, and retrieval workflows.

v4.10 Changes:
  - DB moved to APOLLO_DATA_REPOSITORY/history/backtest_history.db
  - Added trailing_sl_percent and trailing_activate_pct columns
  - Added find_matching_runs() — search history by parameter combination
  - Added get_symbol_history() — historical results for one stock across runs
  - Auto-migration from older schema (adds new columns if missing)
  - get_history() now accepts optional db_path override
"""

from __future__ import annotations

import json
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Any


# =====================================================================
# Configuration
# =====================================================================

# Legacy path — kept for reference. If a DB exists here, it will be
# auto-migrated on first use (see _migrate_v1_to_v2).
_LEGACY_DB_PATH = Path(__file__).parent / "data" / "backtest_history.db"

# Default: APOLLO_DATA_REPOSITORY/history/backtest_history.db
# The actual path is resolved at runtime by get_history() using the
# data_dir from session_state (see DATA_GOVERNANCE in PROJECT_INSTRUCTIONS.md).
# If no data_dir is provided, falls back to legacy path for backward compat.
DEFAULT_DB_PATH = _LEGACY_DB_PATH

# Maximum number of trade events to store per stock per run
# (Set to 0 or None to store ALL events — may be large!)
MAX_TRADE_EVENTS_PER_STOCK = 500

# Central repository path — updated by app.py on startup
_CENTRAL_REPO_DIR: str | None = None


def set_central_repo(repo_dir: str) -> None:
    """Set the central data repository path for all future DB connections.

    Call this once at app startup with the APOLLO_DATA_REPOSITORY path.
    All subsequent get_history() calls will use ``<repo_dir>/history/backtest_history.db``.
    """
    global _CENTRAL_REPO_DIR
    _CENTRAL_REPO_DIR = repo_dir


def get_central_db_path(repo_dir: str | None = None) -> Path:
    """Return the canonical DB path inside the central repository."""
    base = repo_dir or _CENTRAL_REPO_DIR
    if base:
        return Path(base) / "history" / "backtest_history.db"
    return DEFAULT_DB_PATH


# =====================================================================
# Database Connection Manager
# =====================================================================

class BacktestHistory:
    """Manages SQLite persistence for backtest results."""

    def __init__(self, db_path: str | Path = DEFAULT_DB_PATH):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._init_db()
        self._migrate_if_needed()

    @property
    def conn(self) -> sqlite3.Connection:
        """Lazy connection initialization."""
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path))
            self._conn.row_factory = sqlite3.Row
            # Enable foreign keys
            self._conn.execute("PRAGMA foreign_keys = ON")
        return self._conn

    def close(self):
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    # -----------------------------------------------------------------
    # Schema Initialization
    # -----------------------------------------------------------------

    def _init_db(self):
        """Create tables if they don't exist."""
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.executescript("""
                -- Runs table
                CREATE TABLE IF NOT EXISTS runs (
                    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_name TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    start_date TEXT NOT NULL,
                    end_date TEXT NOT NULL,
                    entry_threshold INTEGER NOT NULL,
                    exit_threshold INTEGER NOT NULL,
                    exit_mode TEXT NOT NULL,
                    sl_percent REAL NOT NULL,
                    trailing_sl_percent REAL NOT NULL DEFAULT 3.0,
                    trailing_activate_pct REAL NOT NULL DEFAULT 5.0,
                    divergence_rsi_drop REAL NOT NULL,
                    divergence_cooldown INTEGER NOT NULL,
                    total_stocks INTEGER DEFAULT 0,
                    total_trades INTEGER DEFAULT 0,
                    total_entries INTEGER DEFAULT 0,
                    winning_trades INTEGER DEFAULT 0,
                    losing_trades INTEGER DEFAULT 0,
                    win_rate REAL DEFAULT 0.0,
                    avg_pnl_per_trade REAL DEFAULT 0.0,
                    total_cumulative_pnl REAL DEFAULT 0.0,
                    avg_max_drawdown REAL DEFAULT 0.0,
                    worst_max_drawdown REAL DEFAULT 0.0,
                    duration_seconds REAL DEFAULT 0.0,
                    failed_count INTEGER DEFAULT 0,
                    notes TEXT DEFAULT '',
                    is_bookmarked INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'completed'
                );

                -- Stock results table
                CREATE TABLE IF NOT EXISTS stock_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    symbol TEXT NOT NULL,
                    bucket TEXT DEFAULT '',
                    sector TEXT DEFAULT '',
                    n_trades INTEGER DEFAULT 0,
                    n_entries INTEGER DEFAULT 0,
                    n_completed INTEGER DEFAULT 0,
                    win_rate REAL DEFAULT 0.0,
                    cum_pnl REAL DEFAULT 0.0,
                    avg_pnl_per_trade REAL DEFAULT 0.0,
                    max_drawdown REAL DEFAULT 0.0,
                    avg_score REAL DEFAULT 0.0,
                    peak_score REAL DEFAULT 0.0,
                    n_days INTEGER DEFAULT 0,
                    sl_exits INTEGER DEFAULT 0,
                    div_exits INTEGER DEFAULT 0,
                    score_exits INTEGER DEFAULT 0,
                    period_end_exits INTEGER DEFAULT 0,
                    FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );

                -- Trade events table
                CREATE TABLE IF NOT EXISTS trade_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    symbol TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    date TEXT NOT NULL,
                    close_price REAL,
                    score REAL,
                    classification TEXT,
                    pool_a REAL,
                    pool_b REAL,
                    pool_c REAL,
                    bonus REAL,
                    entry_price REAL,
                    pnl_percentage REAL,
                    exit_reason TEXT,
                    bars_from_trough INTEGER,
                    FOREIGN KEY (run_id) REFERENCES runs(run_id) ON DELETE CASCADE
                );

                -- Indexes
                CREATE INDEX IF NOT EXISTS idx_stock_results_run_id
                    ON stock_results(run_id);
                CREATE INDEX IF NOT EXISTS idx_stock_results_symbol
                    ON stock_results(symbol);
                CREATE INDEX IF NOT EXISTS idx_stock_results_bucket
                    ON stock_results(bucket);
                CREATE INDEX IF NOT EXISTS idx_trade_events_run_id
                    ON trade_events(run_id);
                CREATE INDEX IF NOT EXISTS idx_trade_events_symbol
                    ON trade_events(symbol);
                CREATE INDEX IF NOT EXISTS idx_trade_events_type
                    ON trade_events(event_type);
                CREATE INDEX IF NOT EXISTS idx_runs_params
                    ON runs(exit_mode, sl_percent, entry_threshold, exit_threshold);
                CREATE INDEX IF NOT EXISTS idx_runs_created
                    ON runs(created_at);
            """)

    def _migrate_if_needed(self):
        """Add columns that may be missing from older DB versions.

        Safe to run repeatedly — uses ``IF NOT EXISTS`` logic via
        pragma table_info checks.
        """
        with sqlite3.connect(str(self.db_path)) as conn:
            existing = {
                row[1]
                for row in conn.execute("PRAGMA table_info(runs)").fetchall()
            }

            migrations = [
                ("trailing_sl_percent", "REAL NOT NULL DEFAULT 3.0"),
                ("trailing_activate_pct", "REAL NOT NULL DEFAULT 5.0"),
            ]
            for col_name, col_def in migrations:
                if col_name not in existing:
                    conn.execute(
                        f"ALTER TABLE runs ADD COLUMN {col_name} {col_def}"
                    )

            # Also add bucket to stock_results if missing
            sr_existing = {
                row[1]
                for row in conn.execute(
                    "PRAGMA table_info(stock_results)"
                ).fetchall()
            }
            if "bucket" not in sr_existing:
                conn.execute(
                    "ALTER TABLE stock_results ADD COLUMN bucket TEXT DEFAULT ''"
                )

    # -----------------------------------------------------------------
    # SAVE OPERATIONS
    # -----------------------------------------------------------------

    def save_backtest_run(
        self,
        results: list[dict],
        params: dict,
        duration_seconds: float = 0.0,
        failed_stocks: list[dict] | None = None,
        status: str = "completed",
    ) -> int:
        """Save a complete backtest run to the database.

        Parameters
        ----------
        results : list[dict]
            List of per-stock result dicts from run_stock_backtest()
        params : dict
            Strategy parameters used for this run
        duration_seconds : float
            How long the backtest took to run
        failed_stocks : list[dict]
            Stocks that failed during processing
        status : str
            'completed', 'stopped', or 'error'

        Returns
        -------
        int — The run_id of the newly created run
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_name = f"BT_{timestamp}"

        aggregates = self._compute_aggregates(results, failed_stocks)

        cursor = self.conn.execute(
            """
            INSERT INTO runs (
                run_name, created_at,
                start_date, end_date,
                entry_threshold, exit_threshold,
                exit_mode, sl_percent,
                trailing_sl_percent, trailing_activate_pct,
                divergence_rsi_drop, divergence_cooldown,
                total_stocks, total_trades, total_entries,
                winning_trades, losing_trades,
                win_rate, avg_pnl_per_trade,
                total_cumulative_pnl, avg_max_drawdown,
                worst_max_drawdown, duration_seconds,
                failed_count, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_name,
                datetime.now().isoformat(),
                params.get("start_date", ""),
                params.get("end_date", ""),
                params.get("entry_threshold", 70),
                params.get("exit_threshold", 50),
                params.get("exit_mode", "NONE"),
                params.get("sl_percent", 0.0),
                params.get("trailing_sl_percent", 3.0),
                params.get("trailing_activate_pct", 5.0),
                params.get("divergence_rsi_drop", 3.0),
                params.get("divergence_cooldown", 5),
                aggregates["total_stocks"],
                aggregates["total_trades"],
                aggregates["total_entries"],
                aggregates["winning_trades"],
                aggregates["losing_trades"],
                aggregates["win_rate"],
                aggregates["avg_pnl_per_trade"],
                aggregates["total_cumulative_pnl"],
                aggregates["avg_max_drawdown"],
                aggregates["worst_max_drawdown"],
                duration_seconds,
                aggregates["failed_count"],
                status,
            ),
        )
        run_id = cursor.lastrowid

        for r in results:
            self._save_stock_result(run_id, r)

            trades = r.get("trades", [])
            if MAX_TRADE_EVENTS_PER_STOCK and len(trades) > MAX_TRADE_EVENTS_PER_STOCK:
                critical = [t for t in trades if t.get("type") in ("ENTRY", "EXIT")]
                holds = [t for t in trades if t.get("type") not in ("ENTRY", "EXIT")]
                step = max(1, len(holds) // (MAX_TRADE_EVENTS_PER_STOCK - len(critical)))
                sampled_holds = holds[::step][:MAX_TRADE_EVENTS_PER_STOCK - len(critical)]
                trades = critical + sampled_holds

            for trade in trades:
                self._save_trade_event(run_id, r.get("symbol", ""), trade)

        self.conn.commit()
        return run_id

    def _save_stock_result(self, run_id: int, result: dict):
        """Save a single stock's result."""
        trades = result.get("trades", [])
        scores = [e.get("score", 0) for e in trades if e.get("score") is not None]
        avg_sc = round(sum(scores) / len(scores), 2) if scores else 0.0
        peak_sc = round(max(scores), 2) if scores else 0.0

        self.conn.execute(
            """
            INSERT INTO stock_results (
                run_id, symbol, bucket, sector,
                n_trades, n_entries, n_completed,
                win_rate, cum_pnl, avg_pnl_per_trade,
                max_drawdown, avg_score, peak_score, n_days,
                sl_exits, div_exits, score_exits, period_end_exits
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                result.get("symbol", ""),
                result.get("bucket", ""),
                result.get("sector", ""),
                result.get("n_trades", 0),
                len(result.get("entries", [])),
                len(result.get("completed", [])),
                result.get("win_rate", 0.0),
                result.get("cum_pnl", 0.0),
                result.get("avg_pnl_per_trade", 0.0),
                result.get("max_drawdown", 0.0),
                avg_sc,
                peak_sc,
                result.get("n_days", 0),
                len(result.get("sl_exits", [])),
                len(result.get("div_exits", [])),
                len(result.get("score_exits", [])),
                len(result.get("period_end_exits", [])),
            ),
        )

    def _save_trade_event(self, run_id: int, symbol: str, event: dict):
        """Save a single trade event."""
        self.conn.execute(
            """
            INSERT INTO trade_events (
                run_id, symbol, event_type, date,
                close_price, score, classification,
                pool_a, pool_b, pool_c, bonus,
                entry_price, pnl_percentage, exit_reason,
                bars_from_trough
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run_id,
                symbol,
                event.get("type", ""),
                str(event.get("date", "")),
                event.get("close"),
                event.get("score"),
                event.get("classification"),
                event.get("pool_a"),
                event.get("pool_b"),
                event.get("pool_c"),
                event.get("bonus"),
                event.get("entry_price"),
                event.get("pnl"),
                event.get("exit_reason"),
                event.get("bars_from_trough"),
            ),
        )

    def _compute_aggregates(self, results: list[dict], failed: list[dict] | None) -> dict:
        """Compute portfolio-level aggregate metrics."""
        all_completed = []
        for r in results:
            all_completed.extend(r.get("completed", []))

        winning = [e for e in all_completed if e.get("pnl", 0) > 0]
        losing = [e for e in all_completed if e.get("pnl", 0) <= 0]

        total_trades = sum(r.get("n_trades", 0) for r in results)
        total_entries = sum(len(r.get("entries", [])) for r in results)

        win_rate = (len(winning) / len(all_completed) * 100) if all_completed else 0.0

        stocks_with_trades = [r for r in results if r.get("n_trades", 0) > 0]
        avg_pnl = (
            sum(r.get("avg_pnl_per_trade", 0) for r in stocks_with_trades)
            / max(1, len(stocks_with_trades))
        )

        max_dd_vals = [
            r.get("max_drawdown", 0) for r in results
            if r.get("max_drawdown", 0) != 0.0
        ]
        avg_dd = sum(max_dd_vals) / len(max_dd_vals) if max_dd_vals else 0.0
        worst_dd = min(max_dd_vals) if max_dd_vals else 0.0

        return {
            "total_stocks": len(results),
            "total_trades": total_trades,
            "total_entries": total_entries,
            "winning_trades": len(winning),
            "losing_trades": len(losing),
            "win_rate": round(win_rate, 2),
            "avg_pnl_per_trade": round(avg_pnl, 2),
            "total_cumulative_pnl": round(sum(r.get("cum_pnl", 0) for r in results), 2),
            "avg_max_drawdown": round(avg_dd, 2),
            "worst_max_drawdown": round(worst_dd, 2),
            "failed_count": len(failed) if failed else 0,
        }

    # -----------------------------------------------------------------
    # RETRIEVE OPERATIONS
    # -----------------------------------------------------------------

    def get_all_runs(
        self,
        limit: int = 50,
        offset: int = 0,
        order_by: str = "created_at",
        descending: bool = True,
    ) -> list[dict]:
        """Get list of all backtest runs (metadata only)."""
        direction = "DESC" if descending else "ASC"

        valid_columns = {
            "created_at", "run_name", "total_cumulative_pnl",
            "win_rate", "total_trades", "duration_seconds",
            "sl_percent", "trailing_sl_percent",
        }
        col = order_by if order_by in valid_columns else "created_at"

        rows = self.conn.execute(
            f"""
            SELECT * FROM runs
            ORDER BY {col} {direction}
            LIMIT ? OFFSET ?
            """,
            (limit, offset),
        ).fetchall()

        return [dict(row) for row in rows]

    def get_run(self, run_id: int) -> dict | None:
        """Get a single run's metadata by ID."""
        row = self.conn.execute(
            "SELECT * FROM runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        return dict(row) if row else None

    def get_stock_results(self, run_id: int) -> list[dict]:
        """Get all stock results for a specific run."""
        rows = self.conn.execute(
            "SELECT * FROM stock_results WHERE run_id = ? ORDER BY cum_pnl DESC",
            (run_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def get_trade_events(
        self,
        run_id: int,
        symbol: str | None = None,
        event_types: list[str] | None = None,
    ) -> list[dict]:
        """Get trade events for a run, optionally filtered by stock or type."""
        query = "SELECT * FROM trade_events WHERE run_id = ?"
        params: list[Any] = [run_id]

        if symbol:
            query += " AND UPPER(symbol) = UPPER(?)"
            params.append(symbol)

        if event_types:
            placeholders = ",".join("?" * len(event_types))
            query += f" AND event_type IN ({placeholders})"
            params.extend(event_types)

        query += " ORDER BY symbol, date"

        rows = self.conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def get_run_comparison(self, run_ids: list[int]) -> list[dict]:
        """Get comparison data for multiple runs (aggregate metrics only)."""
        placeholders = ",".join("?" * len(run_ids))
        rows = self.conn.execute(
            f"""
            SELECT run_id, run_name, created_at,
                   entry_threshold, exit_threshold, exit_mode,
                   sl_percent, trailing_sl_percent, trailing_activate_pct,
                   total_stocks, total_trades, win_rate,
                   total_cumulative_pnl, avg_pnl_per_trade,
                   avg_max_drawdown, worst_max_drawdown,
                   duration_seconds
            FROM runs
            WHERE run_id IN ({placeholders})
            ORDER BY created_at
            """,
            run_ids,
        ).fetchall()
        return [dict(row) for row in rows]

    # -----------------------------------------------------------------
    # ANALYTICS: Parameter-Based Search (v4.10)
    # -----------------------------------------------------------------

    def find_matching_runs(
        self,
        params: dict | None = None,
        symbols: list[str] | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Find historical runs matching given parameter filters.

        Use this to answer questions like:
          - "What happened when I used SL=5% vs SL=7.5%?"
          - "Show me all FIXED_SL runs with entry_threshold=70"
          - "Which runs overlap with my current date range?"

        Parameters
        ----------
        params : dict or None
            Filter keys: exit_mode, sl_percent, trailing_sl_percent,
            trailing_activate_pct, entry_threshold, exit_threshold.
            Only exact matches. Omit a key to ignore it.
        symbols : list[str] or None
            If provided, only return runs that contain ALL these symbols.
        date_from : str or None
            Only runs whose start_date >= date_from (YYYY-MM-DD).
        date_to : str or None
            Only runs whose end_date <= date_to (YYYY-MM-DD).
        limit : int
            Max results.

        Returns
        -------
        list[dict] — Matching run metadata rows, newest first.
        """
        query = "SELECT * FROM runs WHERE 1=1"
        sql_params: list[Any] = []

        if params:
            param_columns = {
                "exit_mode": "exit_mode",
                "sl_percent": "sl_percent",
                "trailing_sl_percent": "trailing_sl_percent",
                "trailing_activate_pct": "trailing_activate_pct",
                "entry_threshold": "entry_threshold",
                "exit_threshold": "exit_threshold",
                "divergence_rsi_drop": "divergence_rsi_drop",
                "divergence_cooldown": "divergence_cooldown",
            }
            for key, col in param_columns.items():
                if key in params and params[key] is not None:
                    query += f" AND {col} = ?"
                    sql_params.append(params[key])

        if date_from:
            query += " AND start_date >= ?"
            sql_params.append(date_from)
        if date_to:
            query += " AND end_date <= ?"
            sql_params.append(date_to)

        query += " ORDER BY created_at DESC LIMIT ?"
        sql_params.append(limit)

        rows = self.conn.execute(query, sql_params).fetchall()
        results = [dict(row) for row in rows]

        # Filter by symbols if provided
        if symbols and results:
            symbols_upper = [s.upper() for s in symbols]
            filtered = []
            for run in results:
                run_symbols = {
                    r["symbol"].upper()
                    for r in self.get_stock_results(run["run_id"])
                }
                if all(s in run_symbols for s in symbols_upper):
                    filtered.append(run)
            results = filtered

        return results

    def get_symbol_history(
        self,
        symbol: str,
        params: dict | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """Get historical results for one stock across all matching runs.

        Use this to answer:
          - "How did RELIANCE perform across all my backtests?"
          - "What was TCS's win rate when I used FIXED_SL with 5% SL?"

        Parameters
        ----------
        symbol : str
            Stock symbol (case-insensitive).
        params : dict or None
            Optional parameter filters (same keys as find_matching_runs).
            If provided, only returns results from runs with those params.
        limit : int
            Max results.

        Returns
        -------
        list[dict] — Each dict has run metadata + stock-specific KPIs.
            Keys include both run-level fields (run_id, created_at, sl_percent, ...)
            and stock-level fields (win_rate, cum_pnl, n_trades, ...).
        """
        # Build param filter for the runs table
        run_filter = ""
        sql_params: list[Any] = []

        if params:
            param_columns = {
                "exit_mode": "r.exit_mode",
                "sl_percent": "r.sl_percent",
                "trailing_sl_percent": "r.trailing_sl_percent",
                "trailing_activate_pct": "r.trailing_activate_pct",
                "entry_threshold": "r.entry_threshold",
                "exit_threshold": "r.exit_threshold",
            }
            for key, col in param_columns.items():
                if key in params and params[key] is not None:
                    run_filter += f" AND {col} = ?"
                    sql_params.append(params[key])

        sql_params.append(symbol.upper())
        sql_params.append(limit)

        query = f"""
            SELECT
                r.run_id, r.run_name, r.created_at,
                r.start_date, r.end_date,
                r.entry_threshold, r.exit_threshold,
                r.exit_mode, r.sl_percent,
                r.trailing_sl_percent, r.trailing_activate_pct,
                r.total_stocks, r.total_trades, r.win_rate as run_win_rate,
                r.total_cumulative_pnl as run_total_pnl,
                sr.n_trades, sr.n_entries, sr.n_completed,
                sr.win_rate, sr.cum_pnl, sr.avg_pnl_per_trade,
                sr.max_drawdown, sr.avg_score, sr.peak_score,
                sr.n_days, sr.bucket,
                sr.sl_exits, sr.div_exits, sr.score_exits, sr.period_end_exits
            FROM stock_results sr
            JOIN runs r ON r.run_id = sr.run_id
            WHERE UPPER(sr.symbol) = UPPER(?)
            {run_filter}
            ORDER BY r.created_at DESC
            LIMIT ?
        """

        rows = self.conn.execute(query, sql_params).fetchall()
        return [dict(row) for row in rows]

    def get_param_comparison(
        self,
        param_name: str,
        param_values: list[float | int | str] | None = None,
        base_params: dict | None = None,
    ) -> list[dict]:
        """Compare runs grouped by a single parameter's values.

        Use this to answer:
          - "What's the impact of SL%: 3% vs 5% vs 7.5%?"
          - "FIXED_SL vs TRAILING_SL vs DUAL_SL — which wins?"

        Parameters
        ----------
        param_name : str
            Column name in runs table (e.g. 'sl_percent', 'exit_mode',
            'entry_threshold').
        param_values : list or None
            Specific values to compare. If None, uses all distinct values.
        base_params : dict or None
            Other params to hold constant (e.g. {"exit_mode": "FIXED_SL"}
            to compare SL% only within fixed-SL runs).

        Returns
        -------
        list[dict] — One row per param value with aggregate stats.
        """
        valid_params = {
            "sl_percent", "trailing_sl_percent", "trailing_activate_pct",
            "entry_threshold", "exit_threshold", "exit_mode",
            "divergence_rsi_drop", "divergence_cooldown",
        }
        if param_name not in valid_params:
            return []

        query = f"""
            SELECT
                {param_name} as param_value,
                COUNT(*) as n_runs,
                ROUND(AVG(total_stocks), 0) as avg_stocks,
                ROUND(AVG(total_trades), 0) as avg_trades,
                ROUND(AVG(win_rate), 2) as avg_win_rate,
                ROUND(AVG(total_cumulative_pnl), 2) as avg_total_pnl,
                ROUND(AVG(avg_pnl_per_trade), 2) as avg_pnl_per_trade,
                ROUND(AVG(worst_max_drawdown), 2) as avg_worst_dd,
                ROUND(AVG(duration_seconds), 1) as avg_duration
            FROM runs WHERE status = 'completed'
        """
        sql_params: list[Any] = []

        if base_params:
            for key, val in base_params.items():
                if key in valid_params and key != param_name:
                    query += f" AND {key} = ?"
                    sql_params.append(val)

        if param_values:
            placeholders = ",".join("?" * len(param_values))
            query += f" AND {param_name} IN ({placeholders})"
            sql_params.extend(param_values)

        query += f" GROUP BY {param_name} ORDER BY {param_name}"

        rows = self.conn.execute(query, sql_params).fetchall()
        return [dict(row) for row in rows]

    # -----------------------------------------------------------------
    # UPDATE/DELETE OPERATIONS
    # -----------------------------------------------------------------

    def update_notes(self, run_id: int, notes: str):
        """Add/edit user notes for a run."""
        self.conn.execute(
            "UPDATE runs SET notes = ? WHERE run_id = ?",
            (notes, run_id),
        )
        self.conn.commit()

    def toggle_bookmark(self, run_id: int) -> bool:
        """Toggle bookmark status. Returns new bookmark state."""
        run = self.get_run(run_id)
        if not run:
            return False
        new_state = 0 if run["is_bookmarked"] else 1
        self.conn.execute(
            "UPDATE runs SET is_bookmarked = ? WHERE run_id = ?",
            (new_state, run_id),
        )
        self.conn.commit()
        return bool(new_state)

    def delete_run(self, run_id: int) -> bool:
        """Delete a run and all its associated data (CASCADE)."""
        result = self.conn.execute("DELETE FROM runs WHERE run_id = ?", (run_id,))
        self.conn.commit()
        return result.rowcount > 0

    def delete_multiple_runs(self, run_ids: list[int]) -> int:
        """Delete multiple runs at once. Returns count deleted."""
        placeholders = ",".join("?" * len(run_ids))
        result = self.conn.execute(
            f"DELETE FROM runs WHERE run_id IN ({placeholders})",
            run_ids,
        )
        self.conn.commit()
        return result.rowcount

    def delete_old_runs(self, keep_latest: int = 20) -> int:
        """Delete old runs, keeping only the N most recent."""
        keep_rows = self.conn.execute(
            "SELECT run_id FROM runs ORDER BY created_at DESC LIMIT ?",
            (keep_latest,),
        ).fetchall()
        keep_ids = {row["run_id"] for row in keep_rows}

        all_rows = self.conn.execute("SELECT run_id FROM runs").fetchall()
        delete_ids = [row["run_id"] for row in all_rows if row["run_id"] not in keep_ids]

        if delete_ids:
            return self.delete_multiple_runs(delete_ids)
        return 0

    # -----------------------------------------------------------------
    # UTILITY METHODS
    # -----------------------------------------------------------------

    def get_stats(self) -> dict:
        """Get database statistics."""
        total_runs = self.conn.execute("SELECT COUNT(*) as c FROM runs").fetchone()["c"]
        total_stocks = self.conn.execute("SELECT COUNT(*) as c FROM stock_results").fetchone()["c"]
        total_events = self.conn.execute("SELECT COUNT(*) as c FROM trade_events").fetchone()["c"]

        db_size_mb = self.db_path.stat().st_size / (1024 * 1024)

        latest_run = self.conn.execute(
            "SELECT created_at FROM runs ORDER BY created_at DESC LIMIT 1"
        ).fetchone()

        return {
            "total_runs": total_runs,
            "total_stocks": total_stocks,
            "total_events": total_events,
            "db_size_mb": round(db_size_mb, 2),
            "latest_run": latest_run["created_at"] if latest_run else "Never",
        }

    def export_run_to_dict(self, run_id: int) -> dict:
        """Export a complete run's data as a dictionary (for JSON export)."""
        run = self.get_run(run_id)
        if not run:
            return {}

        stocks = self.get_stock_results(run_id)
        trades = self.get_trade_events(run_id)

        return {
            "metadata": run,
            "stock_results": stocks,
            "trade_events": trades,
        }

    def migrate_from_legacy(self, legacy_path: str | Path) -> int:
        """Copy all data from a legacy DB into this one.

        Useful for one-time migration from the old
        ``backtest_engine/data/backtest_history.db`` to the central
        APOLLO_DATA_REPOSITORY location.

        Returns the number of runs migrated.
        """
        legacy = Path(legacy_path)
        if not legacy.exists():
            return 0

        src = sqlite3.connect(str(legacy))
        src_runs = src.execute("SELECT * FROM runs").fetchall()
        count = 0

        for run_row in src_runs:
            run_dict = dict(run_row)
            # Check if already migrated (by run_name + created_at)
            exists = self.conn.execute(
                "SELECT 1 FROM runs WHERE run_name = ? AND created_at = ?",
                (run_dict["run_name"], run_dict["created_at"]),
            ).fetchone()
            if exists:
                continue

            # Insert with available columns
            cols = [k for k in run_dict.keys()]
            placeholders = ",".join("?" * len(cols))
            col_list = ",".join(cols)
            values = [run_dict[c] for c in cols]

            # Handle missing trailing columns in old data
            for i, c in enumerate(cols):
                if c in ("trailing_sl_percent", "trailing_activate_pct") and values[i] is None:
                    values[i] = 3.0 if "sl" in c else 5.0

            cursor = self.conn.execute(
                f"INSERT INTO runs ({col_list}) VALUES ({placeholders})",
                values,
            )
            new_run_id = cursor.lastrowid

            # Migrate stock_results
            old_run_id = run_dict["run_id"]
            src_stocks = src.execute(
                "SELECT * FROM stock_results WHERE run_id = ?",
                (old_run_id,),
            ).fetchall()
            for sr in src_stocks:
                sr_dict = dict(sr)
                sr_cols = [k for k in sr_dict.keys()]
                sr_vals = [sr_dict[c] for c in sr_cols]
                # Remap run_id and handle missing bucket column
                for i, c in enumerate(sr_cols):
                    if c == "run_id":
                        sr_vals[i] = new_run_id
                    if c == "bucket" and sr_vals[i] is None:
                        sr_vals[i] = ""
                sr_ph = ",".join("?" * len(sr_cols))
                sr_cl = ",".join(sr_cols)
                self.conn.execute(
                    f"INSERT INTO stock_results ({sr_cl}) VALUES ({sr_ph})",
                    sr_vals,
                )

            # Migrate trade_events
            src_trades = src.execute(
                "SELECT * FROM trade_events WHERE run_id = ?",
                (old_run_id,),
            ).fetchall()
            for te in src_trades:
                te_dict = dict(te)
                te_cols = [k for k in te_dict.keys()]
                te_vals = [te_dict[c] for c in te_cols]
                for i, c in enumerate(te_cols):
                    if c == "run_id":
                        te_vals[i] = new_run_id
                te_ph = ",".join("?" * len(te_cols))
                te_cl = ",".join(te_cols)
                self.conn.execute(
                    f"INSERT INTO trade_events ({te_cl}) VALUES ({te_ph})",
                    te_vals,
                )

            count += 1

        self.conn.commit()
        src.close()
        return count


# =====================================================================
# Convenience Functions
# =====================================================================

def get_history(db_path: str | None = None) -> BacktestHistory:
    """Get a history instance, defaulting to the central repository.

    Parameters
    ----------
    db_path : str or None
        Explicit DB path. If None, uses the central repository path
        set by set_central_repo(). Falls back to legacy path if unset.
    """
    if db_path:
        return BacktestHistory(db_path)
    central = get_central_db_path()
    return BacktestHistory(central)


def save_current_backtest(
    results: list[dict],
    session_state: object,
    duration: float = 0.0,
    failed: list[dict] | None = None,
    db_path: str | None = None,
) -> int:
    """Convenience function to save current Streamlit session's backtest.

    Parameters
    ----------
    results : list[dict]
        st.session_state.backtest_results
    session_state : object
        st.session_state (for extracting params)
    duration : float
        st.session_state.backtest_duration
    failed : list[dict]
        st.session_state.failed_stocks
    db_path : str or None
        Override DB path. If None, uses central repository.

    Returns
    -------
    int — The saved run_id
    """
    params = {
        "start_date": str(getattr(session_state, "start_date", "")),
        "end_date": str(getattr(session_state, "end_date", "")),
        "entry_threshold": getattr(session_state, "entry_threshold", 70),
        "exit_threshold": getattr(session_state, "exit_threshold", 50),
        "exit_mode": getattr(session_state, "exit_mode", "NONE"),
        "sl_percent": getattr(session_state, "sl_percent", 0.0),
        "trailing_sl_percent": getattr(session_state, "trailing_sl_percent", 3.0),
        "trailing_activate_pct": getattr(session_state, "trailing_activate_pct", 5.0),
        "divergence_rsi_drop": getattr(session_state, "divergence_rsi_drop", 3.0),
        "divergence_cooldown": getattr(session_state, "divergence_cooldown", 5),
    }

    with get_history(db_path) as hist:
        return hist.save_backtest_run(results, params, duration, failed)
