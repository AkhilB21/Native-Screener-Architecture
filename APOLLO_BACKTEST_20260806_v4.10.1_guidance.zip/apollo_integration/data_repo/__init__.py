"""Apollo Central Data Repository (v4.8)

Parquet-based canonical OHLCV storage with multi-source sync.
Replaces per-engine CSV directories with a single `apollo_data/` folder
that all engines (backtest, live, NSE) read from.

Usage
-----
    from data_repo import list_symbols, load_daily

    # List all available symbols
    syms = list_symbols("apollo_data/")

    # Load daily OHLCV for one stock
    df = load_daily("apollo_data/", "CYIENTDLM")

    # Sync from eod2 CSVs into Parquet
    python -m data_repo.sync --source-dir <eod2_path> --repo-dir apollo_data/ --update

Public API
----------
    list_symbols(repo_dir)  — return sorted list of available symbols
    load_daily(repo_dir, symbol) — return daily OHLCV DataFrame
    get_manifest(repo_dir)  — return manifest dict
"""

from data_repo.repo import (
    list_symbols,
    load_daily,
    save_daily,
    get_manifest,
    scan_parquet_repo,
)

__all__ = [
    "list_symbols",
    "load_daily",
    "save_daily",
    "get_manifest",
    "scan_parquet_repo",
]
