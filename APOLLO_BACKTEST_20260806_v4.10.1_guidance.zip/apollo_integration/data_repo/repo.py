"""Apollo Central Data Repository — Parquet store & manifest.

Canonical OHLCV storage. Each symbol gets one Parquet file:
    apollo_data/<SYMBOL>.parquet

Schema (columns):
    date   — datetime64[ns] (index)
    open   — float64
    high   — float64
    low    — float64
    close  — float64
    volume — float64

A manifest.json at the repo root tracks metadata for every symbol.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd


# Columns stored in every Parquet file
OHLCV_COLS = ["open", "high", "low", "close", "volume"]


def _manifest_path(repo_dir: str | Path) -> Path:
    return Path(repo_dir) / "manifest.json"


def scan_parquet_repo(repo_dir: str | Path) -> list[dict]:
    """Scan the Parquet repo and return metadata for each symbol.

    Returns a list of dicts:
        [{"symbol": "CYIENTDLM", "rows": 1200,
          "date_start": "2020-01-01", "date_end": "2026-07-31"}, ...]
    """
    repo = Path(repo_dir)
    if not repo.is_dir():
        return []
    results = []
    for pq_file in sorted(repo.glob("*.parquet")):
        try:
            df = pd.read_parquet(pq_file)
            if df.empty:
                continue
            symbol = pq_file.stem.upper()
            date_col = df.index if isinstance(df.index, pd.DatetimeIndex) else df.get("date")
            if date_col is None:
                continue
            results.append({
                "symbol": symbol,
                "rows": len(df),
                "date_start": str(pd.Timestamp(date_col.min()).date()),
                "date_end": str(pd.Timestamp(date_col.max()).date()),
            })
        except Exception:
            continue
    return results


def get_manifest(repo_dir: str | Path) -> dict:
    """Read the manifest.json. Returns empty dict if not found."""
    mp = _manifest_path(repo_dir)
    if not mp.exists():
        return {}
    with open(mp, "r", encoding="utf-8") as f:
        return json.load(f)


def save_manifest(repo_dir: str | Path, manifest: dict) -> None:
    """Write manifest.json to the repo directory."""
    repo = Path(repo_dir)
    repo.mkdir(parents=True, exist_ok=True)
    mp = _manifest_path(repo_dir)
    with open(mp, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, default=str)


def update_manifest_entry(
    repo_dir: str | Path,
    symbol: str,
    source: str = "unknown",
) -> None:
    """Update (or create) one symbol's entry in the manifest."""
    manifest = get_manifest(repo_dir)
    pq_path = Path(repo_dir) / f"{symbol.upper()}.parquet"
    if pq_path.exists():
        df = pd.read_parquet(pq_path)
        rows = len(df)
        date_col = df.index if isinstance(df.index, pd.DatetimeIndex) else df.get("date")
        if date_col is not None and len(date_col) > 0:
            d_start = str(pd.Timestamp(date_col.min()).date())
            d_end = str(pd.Timestamp(date_col.max()).date())
        else:
            d_start = d_end = ""
    else:
        rows = 0
        d_start = d_end = ""

    manifest[symbol.upper()] = {
        "rows": rows,
        "date_start": d_start,
        "date_end": d_end,
        "source": source,
        "last_updated": datetime.now().isoformat(),
    }
    save_manifest(repo_dir, manifest)


def list_symbols(repo_dir: str | Path) -> list[str]:
    """Return sorted list of symbols available in the Parquet repo."""
    repo = Path(repo_dir)
    if not repo.is_dir():
        return []
    return sorted(
        f.stem.upper() for f in repo.glob("*.parquet")
    )


def load_daily(repo_dir: str | Path, symbol: str) -> pd.DataFrame:
    """Load daily OHLCV data for one symbol from the Parquet repo.

    Parameters
    ----------
    repo_dir : str or Path
        Path to the Parquet repository (e.g., ``apollo_data/``).
    symbol : str
        NSE symbol (case-insensitive). File is ``<SYMBOL>.parquet``.

    Returns
    -------
    pd.DataFrame with DatetimeIndex and columns: open, high, low, close, volume.

    Raises
    ------
    FileNotFoundError if the symbol's Parquet file doesn't exist.
    """
    pq_path = Path(repo_dir) / f"{symbol.upper()}.parquet"
    if not pq_path.exists():
        raise FileNotFoundError(
            f"Parquet not found: {pq_path}. "
            f"Run: python -m data_repo.sync --source-dir <eod2_csv_dir> "
            f"--repo-dir {repo_dir}"
        )
    df = pd.read_parquet(pq_path)

    # Ensure DatetimeIndex
    if "date" in df.columns and not isinstance(df.index, pd.DatetimeIndex):
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date")
    df = df.sort_index()

    # Ensure all OHLCV columns exist as float64
    for col in OHLCV_COLS:
        if col not in df.columns:
            df[col] = 0.0
        else:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


def save_daily(
    repo_dir: str | Path,
    symbol: str,
    df: pd.DataFrame,
    source: str = "unknown",
) -> None:
    """Save daily OHLCV data for one symbol to the Parquet repo.

    If the file already exists and ``--update`` logic is used, this function
    writes the full DataFrame (the caller handles deduplication/merging).

    Parameters
    ----------
    repo_dir : str or Path
        Path to the Parquet repository.
    symbol : str
        NSE symbol (case-insensitive).
    df : pd.DataFrame
        Daily OHLCV data. Must have DatetimeIndex or a 'date' column,
        plus open, high, low, close, volume columns.
    source : str
        Data source identifier (e.g., 'eod2', 'yfinance', 'google_sheets').
    """
    repo = Path(repo_dir)
    repo.mkdir(parents=True, exist_ok=True)

    # Work on a copy to avoid mutating caller's DataFrame
    df = df.copy()

    # Normalize: ensure DatetimeIndex
    if "date" in df.columns and not isinstance(df.index, pd.DatetimeIndex):
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date")
    df = df.sort_index()

    # Subset to OHLCV only
    available_cols = [c for c in OHLCV_COLS if c in df.columns]
    df = df[available_cols].copy()
    for col in OHLCV_COLS:
        if col not in df.columns:
            df[col] = 0.0
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Remove duplicate dates (keep last)
    df = df[~df.index.duplicated(keep="last")]

    # Drop rows with no close price
    df = df.dropna(subset=["close"])

    # Write
    pq_path = repo / f"{symbol.upper()}.parquet"
    df.to_parquet(pq_path, engine="pyarrow", index=True)

    # Update manifest
    update_manifest_entry(repo_dir, symbol, source=source)


def merge_bars(
    existing_df: pd.DataFrame,
    new_df: pd.DataFrame,
) -> pd.DataFrame:
    """Merge new bars into existing data.

    Deduplicates by date (keeps the new value for overlapping dates).
    Returns the combined, sorted DataFrame.
    """
    if existing_df.empty:
        return new_df
    if new_df.empty:
        return existing_df

    combined = pd.concat([existing_df, new_df])
    combined = combined[~combined.index.duplicated(keep="last")]
    return combined.sort_index()
