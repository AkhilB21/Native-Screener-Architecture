"""Guidance Engine — Post-Trade Analysis Layer for Apollo (v1.0)

A non-invasive analysis layer that reads backtest output and produces:
  1. Append-only trade records (trades.parquet)
  2. Per-stock behavioral profiles (profiles/{SYMBOL}.parquet + .md)
  3. MAE/MFE diagnostics
  4. Soft flags for screener annotation
  5. Universe-level aggregation for systemic issues

Quick Start::
    from guidance_engine import run_guidance_pipeline

    # After a full backtest run completes:
    run_guidance_pipeline(
        trades_parquet_path="output/trades.parquet",
        profiles_dir="output/profiles",
        repo_dir=r"C:\\...\\APOLLO_DATA_REPOSITORY",
        config_hash=None,  # auto-computed from constants.py
        data_cutoff="2026-08-05",
    )

This will:
  1. Build profiles for all stocks in trades.parquet
  2. Run MAE/MFE diagnostics
  3. Aggregate flags across the universe
  4. Write all outputs to the specified directories

Individual modules can also be used standalone::
    from guidance_engine.recorder import record_trades
    from guidance_engine.analyzer import build_all_profiles
    from guidance_engine.mae_mfe import compute_mae_mfe_report
    from guidance_engine.flag_generator import annotate_screener
    from guidance_engine.aggregator import run_aggregation
"""

from guidance_engine.schemas import (
    TradeRecord,
    StockProfile,
    RegimeSnapshot,
    ENGINE_VERSION,
    config_hash_from_constants,
    FLAG_CATALOG,
)
from guidance_engine.regime import RegimeProvider
from guidance_engine.recorder import record_trades
from guidance_engine.mae_mfe import compute_mae_mfe_report, compute_mae_mfe_all_symbols
from guidance_engine.analyzer import build_all_profiles, build_single_profile, load_profile
from guidance_engine.flag_generator import annotate_screener, flag_summary_dataframe
from guidance_engine.aggregator import run_aggregation

import logging
import os

logger = logging.getLogger(__name__)


def run_guidance_pipeline(
    trades_parquet_path: str,
    profiles_dir: str,
    output_dir: str,
    repo_dir: str,
    config_hash: str | None = None,
    data_cutoff: str = "",
    engine_version: str = ENGINE_VERSION,
) -> dict:
    """Run the full guidance pipeline after a backtest completes.

    This is the single entry point to call from app.py after all
    stocks have been backtested and trades recorded.

    Parameters
    ----------
    trades_parquet_path : str
        Path to the trades.parquet (must already exist, populated by recorder).
    profiles_dir : str
        Directory for per-stock profile outputs.
    output_dir : str
        Directory for aggregation outputs.
    repo_dir : str
        Path to the central data repository (for regime data).
    config_hash : str or None
        If None, auto-computed from constants.py.
    data_cutoff : str
        The data cutoff date of this backtest run.
    engine_version : str
        Current engine version.

    Returns
    -------
    dict with keys: profiles, mae_mfe_all, aggregation
    """
    if config_hash is None:
        config_hash = config_hash_from_constants()

    os.makedirs(profiles_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    # Step 1: Build all profiles
    logger.info("Building per-stock profiles...")
    profiles = build_all_profiles(
        trades_parquet_path=trades_parquet_path,
        profiles_dir=profiles_dir,
        current_config_hash=config_hash,
        current_data_cutoff=data_cutoff,
        current_engine_version=engine_version,
    )
    logger.info(f"Built {len(profiles)} stock profiles")

    # Step 2: MAE/MFE diagnostics across all symbols
    logger.info("Computing MAE/MFE diagnostics...")
    mae_mfe_all = None
    if os.path.isfile(trades_parquet_path):
        import pandas as pd
        trades_df = pd.read_parquet(trades_parquet_path)
        mae_mfe_all = compute_mae_mfe_all_symbols(trades_df)
    if mae_mfe_all is not None and not mae_mfe_all.empty:
        mae_mfe_all.to_parquet(
            os.path.join(output_dir, "mae_mfe_summary.parquet"),
            index=False,
        )
        logger.info(f"MAE/MFE summary: {len(mae_mfe_all)} symbols")

    # Step 3: Aggregation
    logger.info("Running universe-level aggregation...")
    aggregation = run_aggregation(profiles_dir, output_dir)
    n_systemic = len(aggregation.get("systemic_suggestions", []))
    logger.info(f"Aggregation complete: {n_systemic} systemic suggestions")

    return {
        "profiles": profiles,
        "mae_mfe_all": mae_mfe_all,
        "aggregation": aggregation,
        "config_hash": config_hash,
        "data_cutoff": data_cutoff,
    }
