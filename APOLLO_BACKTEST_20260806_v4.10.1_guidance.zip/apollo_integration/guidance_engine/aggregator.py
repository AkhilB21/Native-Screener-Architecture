"""Guidance Engine — Universe-Level Aggregator (v1.0)

Collapses per-stock flags into global strategy suggestions.
If a flag fires on 55%+ of stocks in a bucket, it's a systemic
parameter problem, not an individual stock problem.

Outputs:
  - Flag frequency table (per bucket, per universe)
  - Systemic suggestion list (flags that cross the 55% threshold)
  - Written as: output_dir/aggregation_summary.parquet + .md

Usage::
    from guidance_engine.aggregator import run_aggregation

    summary = run_aggregation(profiles_dir, output_dir)
"""

from __future__ import annotations

import logging
import os
from collections import defaultdict

import pandas as pd

from guidance_engine.analyzer import load_profile
from guidance_engine.schemas import FLAG_CATALOG

logger = logging.getLogger(__name__)

# Threshold: if a flag fires on this % of stocks in a bucket, it's systemic
SYSTEMIC_THRESHOLD_PCT = 55.0

# Minimum stocks in a bucket before surfacing systemic flags
MIN_BUCKET_SIZE = 10


def run_aggregation(
    profiles_dir: str,
    output_dir: str,
) -> dict:
    """Run the full aggregation pipeline.

    Parameters
    ----------
    profiles_dir : str
        Directory containing per-stock profile parquets.
    output_dir : str
        Where to write aggregation_summary.parquet and .md.

    Returns
    -------
    dict with keys:
        flag_frequency: pd.DataFrame  — per-symbol, per-flag
        bucket_frequency: dict       — bucket -> {flag -> count/total}
        systemic_suggestions: list   — flags that cross systemic threshold
    """
    os.makedirs(output_dir, exist_ok=True)

    # Load all profiles
    profiles = _load_all_profiles(profiles_dir)
    if not profiles:
        logger.warning("No profiles found for aggregation")
        return {"flag_frequency": pd.DataFrame(), "bucket_frequency": {},
                "systemic_suggestions": []}

    # 1. Flag frequency table (per symbol)
    flag_rows = []
    bucket_flag_counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))
    bucket_totals: dict[str, int] = defaultdict(int)

    for symbol, profile in profiles.items():
        bucket = profile.bucket or "UNKNOWN"
        bucket_totals[bucket] += 1
        for flag in profile.flags:
            flag_rows.append({
                "symbol": symbol,
                "bucket": bucket,
                "flag": flag,
                "severity": FLAG_CATALOG.get(flag, {}).get("severity", "LOW"),
                "n_trades": profile.n_trades,
                "win_rate": profile.win_rate,
            })
            bucket_flag_counts[bucket][flag] += 1

    flag_freq_df = pd.DataFrame(flag_rows) if flag_rows else pd.DataFrame()

    # 2. Bucket-level flag frequency percentages
    bucket_freq: dict[str, dict[str, dict]] = {}
    for bucket, flag_counts in bucket_flag_counts.items():
        total = bucket_totals[bucket]
        bucket_freq[bucket] = {}
        for flag, count in flag_counts.items():
            bucket_freq[bucket][flag] = {
                "count": count,
                "total": total,
                "pct": round(count / total * 100, 1),
            }

    # 3. Systemic suggestions (flags crossing threshold)
    systemic = []
    for bucket, flags in bucket_freq.items():
        if bucket_totals[bucket] < MIN_BUCKET_SIZE:
            continue
        for flag, stats in flags.items():
            if stats["pct"] >= SYSTEMIC_THRESHOLD_PCT:
                catalog = FLAG_CATALOG.get(flag, {})
                systemic.append({
                    "flag": flag,
                    "bucket": bucket,
                    "frequency_pct": stats["pct"],
                    "n_stocks": stats["count"],
                    "n_total_in_bucket": stats["total"],
                    "severity": catalog.get("severity", "LOW"),
                    "description": catalog.get("description", ""),
                    "suggestion": catalog.get("suggestion", ""),
                })

    # Sort by frequency descending
    systemic.sort(key=lambda x: -x["frequency_pct"])

    # 4. Write outputs
    if not flag_freq_df.empty:
        flag_freq_df.to_parquet(
            os.path.join(output_dir, "aggregation_flag_frequency.parquet"),
            index=False,
        )

    _write_aggregation_markdown(
        bucket_freq, bucket_totals, systemic, output_dir
    )

    return {
        "flag_frequency": flag_freq_df,
        "bucket_frequency": bucket_freq,
        "bucket_totals": dict(bucket_totals),
        "systemic_suggestions": systemic,
    }


def _load_all_profiles(profiles_dir: str) -> dict:
    """Load all profile parquets from a directory."""
    profiles = {}
    if not os.path.isdir(profiles_dir):
        return profiles
    for fname in os.listdir(profiles_dir):
        if not fname.endswith(".parquet"):
            continue
        symbol = fname.replace(".parquet", "")
        profile = load_profile(profiles_dir, symbol)
        if profile is not None:
            profiles[symbol] = profile
    return profiles


def _write_aggregation_markdown(
    bucket_freq: dict,
    bucket_totals: dict,
    systemic: list[dict],
    output_dir: str,
) -> None:
    """Write human-readable aggregation summary."""
    path = os.path.join(output_dir, "aggregation_summary.md")

    lines = ["# Guidance Engine — Aggregation Summary\n"]
    lines.append(f"**Total stocks profiled:** {sum(bucket_totals.values())}\n")
    lines.append(f"**Systemic flags detected:** {len(systemic)}\n")

    # Per-bucket summary
    lines.append("## Flag Frequency by Bucket\n")
    lines.append("| Bucket | Flag | Count | Total | % |")
    lines.append("|--------|------|-------|-------|---|")
    for bucket in sorted(bucket_freq.keys()):
        for flag, stats in sorted(bucket_freq[bucket].items(), key=lambda x: -x[1]["pct"]):
            marker = " **SYSTEMIC**" if stats["pct"] >= SYSTEMIC_THRESHOLD_PCT else ""
            lines.append(
                f"| {bucket} | {flag} | {stats['count']} | {stats['total']} | {stats['pct']}%{marker} |"
            )

    # Systemic suggestions
    lines.append("\n## Systemic Suggestions\n")
    if not systemic:
        lines.append("No systemic flags detected. Individual stock behavior dominates.")
    else:
        for s in systemic:
            lines.append(f"### {s['flag']} in {s['bucket']} ({s['frequency_pct']}%)\n")
            lines.append(f"- **Stocks affected:** {s['n_stocks']} of {s['n_total_in_bucket']}")
            lines.append(f"- **Severity:** {s['severity']}")
            lines.append(f"- **Description:** {s['description']}")
            lines.append(f"- **Suggestion:** {s['suggestion']}")
            lines.append("")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
