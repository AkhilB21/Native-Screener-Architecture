"""Guidance Engine — MAE/MFE Diagnostics (v1.0)

Highest signal-to-noise diagnostic in the guidance engine.
No statistical inference required — purely quantitative per-trade measurement.

Outputs per stock, per exit reason:
  - avg_mae          — average maximum adverse excursion
  - avg_mfe          — average maximum favorable excursion
  - mae_mfe_ratio    — > 1.0 = entries consistently early
  - avg_slippage     — gap-fill severity on SL exits
  - mae_vs_sl_pct    — how close MAE gets to the SL level

Decision Rules (from the architecture doc):
  1. avg_mfe(DIVERGENCE) > 3 * avg_mae(HARD_SL)
       -> target too tight / divergence exit too early
  2. avg_mae(HARD_SL) / avg_mfe(overall) > 0.8
       -> entries consistently early (getting stopped before the move)
  3. avg_mae(HARD_SL) > 0.8 * sl_pct
       -> SL barely survives, consider widening
  4. avg_slippage > 1.0 on HARD_SL exits
       -> gap-down severity is material, factor into SL sizing

Usage:
    from guidance_engine.mae_mfe import compute_mae_mfe_report

    report = compute_mae_mfe_report(trades_df, symbol="RELIANCE")
    print(report)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, asdict
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)


@dataclass
class MAEMFEReport:
    """MAE/MFE diagnostic output for one stock."""
    symbol: str
    n_trades: int = 0

    # Overall
    avg_mae: float = 0.0
    avg_mfe: float = 0.0
    mae_mfe_ratio: float = 0.0
    median_mae: float = 0.0
    median_mfe: float = 0.0

    # Per exit reason
    per_exit: dict = None  # {"HARD_SL": {...}, "DIVERGENCE": {...}, ...}

    # Decision flags
    flag_divergence_mfe_leakage: bool = False   # MFE(DIV) > 3 * MAE(SL)
    flag_entries_early: bool = False             # MAE(SL) / MFE > 0.8
    flag_mae_near_sl: bool = False               # MAE(SL) > 0.8 * sl_pct
    flag_gap_slippage: bool = False              # avg slippage > 1%

    # Raw numbers for decision flags
    divergence_avg_mfe: float = 0.0
    hard_sl_avg_mae: float = 0.0
    hard_sl_avg_slippage: float = 0.0
    sl_pct_used: float = 0.0

    def __post_init__(self):
        if self.per_exit is None:
            self.per_exit = {}

    def to_dict(self) -> dict:
        d = asdict(self)
        if isinstance(d.get("per_exit"), dict):
            import json
            d["per_exit"] = json.dumps(d["per_exit"])
        return d

    def to_text(self) -> str:
        """Human-readable summary."""
        lines = [
            f"MAE/MFE Diagnostics: {self.symbol}",
            f"Trades: {self.n_trades}",
            f"",
            f"Overall:  Avg MAE = {self.avg_mae:.2f}%  |  Avg MFE = {self.avg_mfe:.2f}%  |  Ratio = {self.mae_mfe_ratio:.2f}",
            f"Median:  MAE = {self.median_mae:.2f}%  |  MFE = {self.median_mfe:.2f}%",
        ]
        for reason, stats in self.per_exit.items():
            lines.append(
                f"  {reason:20s}: MAE={stats['avg_mae']:.2f}%  MFE={stats['avg_mfe']:.2f}%  "
                f"n={stats['n']}  slippage={stats.get('avg_slippage', 0):.2f}%"
            )
        lines.append("")
        if self.flag_entries_early:
            lines.append(f"  [FLAG] Entries are consistently early (MAE/MFE ratio = {self.mae_mfe_ratio:.2f})")
        if self.flag_mae_near_sl and self.sl_pct_used > 0:
            lines.append(f"  [FLAG] MAE ({self.hard_sl_avg_mae:.2f}%) is near SL ({self.sl_pct_used:.1f}%)")
        if self.flag_divergence_mfe_leakage:
            lines.append(f"  [FLAG] Divergence exits leave money on table (MFE={self.divergence_avg_mfe:.2f}%)")
        if self.flag_gap_slippage:
            lines.append(f"  [FLAG] Gap-down slippage on SL exits (avg {self.hard_sl_avg_slippage:.2f}%)")
        if not any([self.flag_entries_early, self.flag_mae_near_sl,
                    self.flag_divergence_mfe_leakage, self.flag_gap_slippage]):
            lines.append("  No flags raised.")
        return "\n".join(lines)


def compute_mae_mfe_report(
    trades_df: pd.DataFrame,
    symbol: Optional[str] = None,
) -> MAEMFEReport:
    """Compute MAE/MFE diagnostics from a trades DataFrame.

    Parameters
    ----------
    trades_df : pd.DataFrame
        The full trades.parquet or a filtered subset.
        Required columns: mae_daily, mfe_daily, exit_reason, pnl_pct,
        exit_slippage_est, sl_pct.
    symbol : str or None
        If provided, filters to this symbol.

    Returns
    -------
    MAEMFEReport
    """
    df = trades_df.copy()
    if symbol:
        df = df[df["symbol"] == symbol]

    report = MAEMFEReport(symbol=symbol or "ALL")
    if df.empty:
        return report

    report.n_trades = len(df)
    report.avg_mae = round(float(df["mae_daily"].mean()), 2)
    report.avg_mfe = round(float(df["mfe_daily"].mean()), 2)
    report.median_mae = round(float(df["mae_daily"].median()), 2)
    report.median_mfe = round(float(df["mfe_daily"].median()), 2)
    report.mae_mfe_ratio = round(report.avg_mae / report.avg_mfe, 2) if report.avg_mfe > 0 else 0.0

    # Get SL pct used (should be uniform across trades from same run)
    report.sl_pct_used = float(df["sl_pct"].iloc[0]) if "sl_pct" in df.columns else 0.0

    # Per exit reason
    for reason, group in df.groupby("exit_reason"):
        stats = {
            "n": len(group),
            "avg_mae": round(float(group["mae_daily"].mean()), 2),
            "avg_mfe": round(float(group["mfe_daily"].mean()), 2),
            "median_mae": round(float(group["mae_daily"].median()), 2),
            "median_mfe": round(float(group["mfe_daily"].median()), 2),
            "avg_pnl": round(float(group["pnl_pct"].mean()), 2),
            "avg_slippage": 0.0,
        }
        if "exit_slippage_est" in group.columns:
            sl_group = group[group["exit_slippage_est"] > 0]
            if not sl_group.empty:
                stats["avg_slippage"] = round(float(sl_group["exit_slippage_est"].mean()), 2)
        report.per_exit[reason] = stats

    # --- Decision Flags ---
    hard_sl = report.per_exit.get("HARD_SL", {})
    div_exit = report.per_exit.get("DIVERGENCE", {})

    report.hard_sl_avg_mae = hard_sl.get("avg_mae", 0.0)
    report.divergence_avg_mfe = div_exit.get("avg_mfe", 0.0)
    report.hard_sl_avg_slippage = hard_sl.get("avg_slippage", 0.0)

    # Flag 1: Divergence MFE leakage
    if report.hard_sl_avg_mae > 0 and report.divergence_avg_mfe > 3 * report.hard_sl_avg_mae:
        report.flag_divergence_mfe_leakage = True

    # Flag 2: Entries consistently early
    if report.avg_mfe > 0 and report.hard_sl_avg_mae / report.avg_mfe > 0.8:
        report.flag_entries_early = True

    # Flag 3: MAE near SL
    if report.sl_pct_used > 0 and report.hard_sl_avg_mae > 0.8 * report.sl_pct_used:
        report.flag_mae_near_sl = True

    # Flag 4: Gap-down slippage
    if report.hard_sl_avg_slippage > 1.0:
        report.flag_gap_slippage = True

    return report


def compute_mae_mfe_all_symbols(
    trades_df: pd.DataFrame,
) -> pd.DataFrame:
    """Compute MAE/MFE summary across all symbols.

    Returns a DataFrame with one row per symbol.
    Useful for identifying the worst-timed entries across the universe.
    """
    rows = []
    for symbol, group in trades_df.groupby("symbol"):
        report = compute_mae_mfe_report(trades_df, symbol=symbol)
        rows.append(report.to_dict())
    return pd.DataFrame(rows) if rows else pd.DataFrame()
