"""Guidance Engine — Trade Recorder (v1.0)

Post-backtest recorder that converts the engine's trade events + daily_results
into structured TradeRecord rows and appends them to trades.parquet.

This module does NOT modify the backtest engine.  It reads the OUTPUT
of ``run_stock_backtest()`` and ``extract_trades()`` after they complete.

Integration Point
-----------------
Call ``record_trades()`` in ``backtest_engine/backtest.py`` or
``backtest_engine/app.py`` after each stock's backtest completes::

    from guidance_engine.recorder import record_trades

    result = run_stock_backtest(data_dir, symbol, ...)
    record_trades(result, df_d, output_dir, regime_provider)

This is a single function call — zero changes to the scoring loop.

Design Decisions:
    - Pairs ENTRY/EXIT events by chronological order.
    - Looks up daily_results by date to snapshot entry state.
    - Looks up df_d (daily OHLCV) for 52w high/low, ATR, ADX.
    - Looks up regime from RegimeProvider (falls back to NEUTRAL).
    - Computes MAE/MFE from daily OHLC within the trade window.
    - Tracks consecutive loss streaks across trades.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

import numpy as np
import pandas as pd

from guidance_engine.schemas import (
    TradeRecord,
    config_hash_from_constants,
    ENGINE_VERSION,
)

logger = logging.getLogger(__name__)

# Minimum trades before any profile flag can be considered reliable
MIN_TRADES_FOR_PROFILE = 8


def record_trades(
    backtest_result: dict,
    df_d: pd.DataFrame,
    output_dir: str,
    regime_provider=None,
    sl_pct: float = 0.0,
    exit_mode: str = "NONE",
    config_hash: str = "",
) -> list[TradeRecord]:
    """Record completed trades from a backtest run.

    Parameters
    ----------
    backtest_result : dict
        The dict returned by ``run_stock_backtest()``.  Must contain
        ``completed``, ``entries``, ``daily_results``, ``symbol``, ``bucket``.
    df_d : pd.DataFrame
        The daily OHLCV DataFrame (with indicators) used in the backtest.
        Index is DatetimeIndex.  Must have columns: open, high, low, close,
        volume, rsi21, adx, atr (or atr_percent).
    output_dir : str
        Directory where ``trades.parquet`` is stored/appendeD.
    regime_provider : RegimeProvider or None
        If provided, stamps regime state on each trade record.
        If None, defaults to NEUTRAL for all trades.
    sl_pct : float
        The stop-loss percentage used in this backtest run.
    exit_mode : str
        The exit mode used (NONE, FIXED_SL, DUAL_SL, etc.).
    config_hash : str
        Pre-computed config hash.  If empty, computed from constants.py.

    Returns
    -------
    list[TradeRecord] — the records that were written.
    """
    if not config_hash:
        config_hash = config_hash_from_constants()

    symbol = backtest_result.get("symbol", "UNKNOWN")
    entries = backtest_result.get("entries", [])
    completed = backtest_result.get("completed", [])
    daily_results = backtest_result.get("daily_results", [])
    bucket = backtest_result.get("bucket", "")

    if not completed:
        return []

    # Build date-indexed lookup for daily_results
    dr_index = _build_daily_results_index(daily_results)

    # Pre-compute 52-week high/low and volume z-score from full df_d
    high_52w, low_52w = _compute_52w_bounds(df_d)
    vol_zscore_map = _compute_volume_zscore(df_d)

    # Data cutoff = last date in daily_results
    data_cutoff = ""
    if daily_results:
        last_date = daily_results[-1]["date"]
        data_cutoff = pd.Timestamp(last_date).strftime("%Y-%m-%d")

    # Pair entries with completed exits
    records = _pair_and_build(
        symbol=symbol,
        entries=entries,
        completed=completed,
        daily_results_index=dr_index,
        df_d=df_d,
        regime_provider=regime_provider,
        bucket=bucket,
        engine_version=ENGINE_VERSION,
        sl_pct=sl_pct,
        exit_mode=exit_mode,
        config_hash=config_hash,
        data_cutoff=data_cutoff,
        high_52w=high_52w,
        low_52w=low_52w,
        vol_zscore_map=vol_zscore_map,
    )

    # Append to parquet
    _append_to_parquet(records, output_dir)
    logger.info(f"{symbol}: recorded {len(records)} trades")
    return records


# =====================================================================
# Internal Helpers
# =====================================================================

def _build_daily_results_index(daily_results: list[dict]) -> dict:
    """Build a date -> daily_result dict for O(1) lookup."""
    idx = {}
    for r in daily_results:
        dt = pd.Timestamp(r["date"])
        idx[dt] = r
    return idx


def _compute_52w_bounds(df_d: pd.DataFrame) -> tuple[float, float]:
    """Compute 52-week high and low from the full daily DataFrame."""
    high_52w = float(df_d["high"].max()) if "high" in df_d.columns else 0.0
    low_52w = float(df_d["low"].min()) if "low" in df_d.columns else 0.0
    return high_52w, low_52w


def _compute_volume_zscore(df_d: pd.DataFrame) -> dict:
    """Compute 20-day rolling volume z-score for each date.

    Returns a date -> z_score dict.
    """
    if "volume" not in df_d.columns:
        return {}
    vol = df_d["volume"]
    rolling_mean = vol.rolling(20).mean()
    rolling_std = vol.rolling(20).std()
    zscore = (vol - rolling_mean) / rolling_std.replace(0, np.nan)
    zscore = zscore.fillna(0.0)
    return {dt: float(zscore.iloc[i]) for i, dt in enumerate(df_d.index)}


def _pair_and_build(
    symbol: str,
    entries: list[dict],
    completed: list[dict],
    daily_results_index: dict,
    df_d: pd.DataFrame,
    regime_provider,
    bucket: str,
    engine_version: str,
    sl_pct: float,
    exit_mode: str,
    config_hash: str,
    data_cutoff: str,
    high_52w: float,
    low_52w: float,
    vol_zscore_map: dict,
) -> list[TradeRecord]:
    """Pair ENTRY events with EXIT events and build TradeRecords."""
    records = []
    consecutive_losses = 0

    # Track prior exit for re-entry context
    prior_exit_date = None
    prior_exit_reason = ""
    prior_exit_price = None

    entry_idx = 0
    for exit_event in completed:
        # Find the matching entry (entries[entry_idx] pairs with completed[n])
        if entry_idx >= len(entries):
            break

        entry_event = entries[entry_idx]
        entry_idx += 1

        entry_date = pd.Timestamp(entry_event["date"])
        exit_date = pd.Timestamp(exit_event["date"])
        entry_price = float(entry_event["close"])
        exit_price = float(exit_event["close"])

        # --- Re-entry context ---
        bars_since_prior = -1
        entry_above_prior = False
        if prior_exit_date is not None:
            # Count trading days between prior exit and this entry
            dates_between = [
                d for d in daily_results_index.keys()
                if prior_exit_date < d < entry_date
            ]
            bars_since_prior = len(dates_between)
            if prior_exit_price is not None:
                entry_above_prior = entry_price > prior_exit_price

        # --- Look up entry state from daily_results ---
        entry_dr = daily_results_index.get(entry_date, {})

        # Extract signals fired at entry
        sigs = entry_dr.get("signals", {})
        signals_fired = [sid for sid, (val, fired) in sigs.items() if fired and val > 0]

        # --- Look up additional indicators from df_d ---
        adx_val = _safe_lookup(df_d, entry_date, "adx")
        atr_val = _safe_lookup(df_d, entry_date, "atr")
        atr_pct = (atr_val / entry_price * 100) if atr_val and entry_price > 0 else 0.0

        # Weekly RSI at entry — look back in df_d for the closest weekly value
        rsi21_weekly = 0.0
        if "rsi21_weekly" in df_d.columns:
            rsi21_weekly = _safe_lookup(df_d, entry_date, "rsi21_weekly") or 0.0

        # --- 52-week distance ---
        dist_52w_high = ((high_52w - entry_price) / high_52w * 100) if high_52w > 0 else 0.0
        dist_52w_low = ((entry_price - low_52w) / low_52w * 100) if low_52w > 0 else 0.0

        # Volume z-score at entry
        vol_z = vol_zscore_map.get(entry_date, 0.0)

        # --- Regime at entry ---
        if regime_provider is not None:
            snap = regime_provider.get_regime(entry_date)
            nifty_50 = snap.nifty_above_50dma
            nifty_200 = snap.nifty_above_200dma
            vix_regime = snap.vix_regime
            regime_label = snap.regime_label
        else:
            nifty_50 = False
            nifty_200 = False
            vix_regime = "MEDIUM"
            regime_label = "NEUTRAL"

        # --- Extract exit reason (primary class) ---
        exit_reason_full = exit_event.get("exit_reason", "")
        exit_class = exit_event.get("classification", "EXIT")
        # Normalize to short form
        if "HARD_SL" in exit_reason_full or "SL EXIT" in exit_class:
            exit_reason = "HARD_SL"
        elif "TRAILING_SL" in exit_reason_full or "TRAILING" in exit_class:
            exit_reason = "TRAILING_SL"
        elif "DIVERGENCE" in exit_reason_full:
            exit_reason = "DIVERGENCE"
        elif "DI_CROSSOVER" in exit_reason_full or "DI CROSSOVER" in exit_class:
            exit_reason = "DI_CROSSOVER"
        elif "SCORE" in exit_reason_full:
            exit_reason = "SCORE_THRESHOLD"
        elif "PERIOD_END" in exit_reason_full:
            exit_reason = "PERIOD_END"
        else:
            exit_reason = exit_class

        # --- MAE / MFE computation ---
        mae, mfe = _compute_mae_mfe(df_d, entry_date, exit_date, entry_price)

        # --- Intraday MAE estimate (gap-fill proxy) ---
        mae_intraday = 0.0
        if sl_pct > 0:
            mae_intraday = sl_pct  # entry * (1 - sl/100) means max theoretical loss = sl%

        # --- Exit slippage estimate (HARD_SL exits only) ---
        exit_slippage = 0.0
        if exit_reason in ("HARD_SL", "TRAILING_SL") and sl_pct > 0:
            theoretical_sl = entry_price * (1.0 - sl_pct / 100.0)
            # Actual fill is exit_price; slippage = how much worse
            exit_slippage = (theoretical_sl - exit_price) / entry_price * 100
            exit_slippage = round(max(exit_slippage, 0.0), 2)  # positive = worse fill

        # --- PnL ---
        pnl_pct = float(exit_event.get("pnl", 0.0))

        # --- Bars held ---
        bars_held_dates = [
            d for d in daily_results_index.keys()
            if entry_date <= d <= exit_date
        ]
        bars_held = len(bars_held_dates)

        # --- Consecutive loss tracking ---
        if pnl_pct <= 0:
            consecutive_losses += 1
        else:
            consecutive_losses = 0

        # --- Build record ---
        rec = TradeRecord(
            symbol=symbol,
            entry_date=entry_date.strftime("%Y-%m-%d"),
            exit_date=exit_date.strftime("%Y-%m-%d"),
            engine_version=engine_version,
            sl_pct=sl_pct,
            exit_mode=exit_mode,
            data_cutoff=data_cutoff,
            config_hash=config_hash,
            entry_price=entry_price,
            entry_score=float(entry_event.get("score", 0)),
            entry_total=float(entry_dr.get("total", 0)),
            pool_a=float(entry_dr.get("pool_a", 0)),
            pool_b=float(entry_dr.get("pool_b", 0)),
            pool_c=float(entry_dr.get("pool_c", 0)),
            pool_r=float(entry_dr.get("pool_r", 0)),
            bonus_total=float(
                entry_dr.get("bonus_a", 0) + entry_dr.get("bonus_b", 0)
                + entry_dr.get("bonus_c", 0) + entry_dr.get("bonus_d", 0)
                + entry_dr.get("bonus_e", 0)
            ),
            rsi21_entry=float(entry_dr.get("rsi21", 0)),
            rsi21_weekly_entry=rsi21_weekly,
            adx_entry=adx_val or 0.0,
            atr_pct_entry=round(atr_pct, 2),
            bars_from_trough=entry_dr.get("bars_from_trough"),
            bucket=bucket,
            dist_from_52w_high_pct=round(dist_52w_high, 2),
            dist_from_52w_low_pct=round(dist_52w_low, 2),
            volume_zscore_entry=round(vol_z, 2),
            signals_fired=signals_fired,
            n_signals_fired=len(signals_fired),
            bars_since_prior_exit=bars_since_prior,
            prior_exit_reason=prior_exit_reason,
            entry_above_prior_exit_price=entry_above_prior,
            nifty_above_50dma=nifty_50,
            nifty_above_200dma=nifty_200,
            india_vix_regime=vix_regime,
            regime_label=regime_label,
            exit_price=exit_price,
            exit_reason=exit_reason,
            exit_reason_full=exit_reason_full,
            pnl_pct=round(pnl_pct, 2),
            bars_held=bars_held,
            mae_daily=round(mae, 2),
            mae_intraday_est=round(mae_intraday, 2),
            mfe_daily=round(mfe, 2),
            exit_slippage_est=exit_slippage,
            consecutive_loss_count=consecutive_losses,
        )
        records.append(rec)

        # Update prior exit context for next trade
        prior_exit_date = exit_date
        prior_exit_reason = exit_reason
        prior_exit_price = exit_price

    return records


def _safe_lookup(df: pd.DataFrame, dt: pd.Timestamp, col: str) -> float | None:
    """Safely look up a value from df at a given date."""
    try:
        val = df[col].iloc[df.index.get_loc(dt)]
        if pd.notna(val):
            return float(val)
    except (KeyError, ValueError, IndexError):
        pass
    return None


def _compute_mae_mfe(
    df_d: pd.DataFrame,
    entry_date: pd.Timestamp,
    exit_date: pd.Timestamp,
    entry_price: float,
) -> tuple[float, float]:
    """Compute MAE and MFE from daily bars (lower bound).

    MAE = max((entry_price - low) / entry_price * 100) over all bars in trade
    MFE = max((high - entry_price) / entry_price * 100) over all bars in trade

    Both are measured from ENTRY price, as percentages.
    These are lower bounds — intraday extremes are not captured.
    """
    try:
        mask = (df_d.index >= entry_date) & (df_d.index <= exit_date)
        trade_slice = df_d.loc[mask]
        if trade_slice.empty:
            return 0.0, 0.0

        mae = float(((entry_price - trade_slice["low"]) / entry_price * 100).max())
        mfe = float(((trade_slice["high"] - entry_price) / entry_price * 100).max())
        return max(mae, 0.0), max(mfe, 0.0)
    except Exception:
        return 0.0, 0.0


def _append_to_parquet(records: list[TradeRecord], output_dir: str) -> None:
    """Append trade records to trades.parquet (create if not exists)."""
    if not records:
        return

    os.makedirs(output_dir, exist_ok=True)
    parquet_path = os.path.join(output_dir, "trades.parquet")

    new_df = pd.DataFrame([r.to_dict() for r in records])

    if os.path.isfile(parquet_path):
        existing = pd.read_parquet(parquet_path)
        # Detect and drop duplicates (same symbol + entry_date + config_hash)
        if not existing.empty:
            dup_mask = (
                existing["symbol"].isin(new_df["symbol"])
                & existing["entry_date"].isin(new_df["entry_date"])
                & existing["config_hash"] == records[0].config_hash
            )
            if dup_mask.any():
                existing = existing[~dup_mask]
            new_df = pd.concat([existing, new_df], ignore_index=True)
    else:
        new_df = new_df

    new_df.to_parquet(parquet_path, index=False)
    logger.debug(f"Trades parquet: {parquet_path} ({len(new_df)} total rows)")
