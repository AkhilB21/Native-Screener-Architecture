"""Guidance Engine — Market Regime Module (v1.0)

Fetches NIFTY 50 index history and India VIX data, computes
50-DMA / 200-DMA, and classifies each trading day into a regime.

This module must be initialized BEFORE the first trade recording run
because regime state is stamped on every TradeRecord at write time.

Usage:
    from guidance_engine.regime import RegimeProvider

    rp = RegimeProvider(repo_dir="path/to/APOLLO_DATA_REPOSITORY")
    rp.ensure_data()          # fetch + cache NIFTY + VIX parquet
    snapshot = rp.get_regime(pd.Timestamp("2025-09-19"))
    # snapshot.nifty_above_200dma, snapshot.vix_regime, etc.

Data Sources:
    - NIFTY 50: fetched via yfinance (ticker: ^NSEI)
    - India VIX: fetched via yfinance (ticker: ^INDIAVIX)
    - Cached as: repo_dir/regime/nifty.parquet, repo_dir/regime/vix.parquet
      repo_dir/regime/regime_daily.parquet (joined output)

Fallback:
    If yfinance is unavailable or fetch fails, returns NEUTRAL regime
    for all dates. The trade recorder still works — regime columns are
    just default values.
"""

from __future__ import annotations

import logging
import os
from datetime import date, datetime

import numpy as np
import pandas as pd

from guidance_engine.schemas import RegimeSnapshot, classify_vix

logger = logging.getLogger(__name__)


# --- VIX regime thresholds (India VIX is typically 10-25 range) ---
VIX_LOW = 12.0
VIX_HIGH = 20.0

# Minimum history required (trading days) for reliable regime classification
MIN_REGIME_HISTORY = 200


class RegimeProvider:
    """Fetches, caches, and serves market regime snapshots.

    Parameters
    ----------
    repo_dir : str
        Path to the central data repository.  Regime data is stored
        under ``<repo_dir>/regime/`` as parquet files.
    vix_low : float
        VIX threshold for LOW regime.
    vix_high : float
        VIX threshold for HIGH regime.
    """

    def __init__(self, repo_dir: str, vix_low: float = VIX_LOW, vix_high: float = VIX_HIGH):
        self.repo_dir = repo_dir
        self.vix_low = vix_low
        self.vix_high = vix_high
        self.regime_dir = os.path.join(repo_dir, "regime")
        self._regime_df: pd.DataFrame | None = None
        self._fetched = False

    # -----------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------

    def ensure_data(self, force_refetch: bool = False) -> bool:
        """Fetch and cache regime data. Returns True if successful.

        Attempts to use yfinance.  If unavailable, creates a minimal
        empty regime file so the recorder can proceed with defaults.
        """
        os.makedirs(self.regime_dir, exist_ok=True)
        regime_path = os.path.join(self.regime_dir, "regime_daily.parquet")

        if os.path.isfile(regime_path) and not force_refetch:
            self._regime_df = pd.read_parquet(regime_path)
            self._fetched = True
            logger.info(f"Regime data loaded from {regime_path} ({len(self._regime_df)} rows)")
            return True

        success = self._fetch_and_build()
        if success:
            self._regime_df.to_parquet(regime_path, index=False)
            logger.info(f"Regime data saved to {regime_path} ({len(self._regime_df)} rows)")
            self._fetched = True
        else:
            # Create empty file so loader doesn't fail
            self._regime_df = pd.DataFrame(columns=[
                "date", "nifty_close", "nifty_50dma", "nifty_200dma",
                "nifty_above_50dma", "nifty_above_200dma",
                "india_vix", "vix_regime",
            ])
            self._regime_df.to_parquet(regime_path, index=False)
            logger.warning("Regime fetch failed — all dates will default to NEUTRAL")
        return success

    def get_regime(self, dt: pd.Timestamp | datetime | date | str) -> RegimeSnapshot:
        """Get regime state for a single date.

        Falls back to NEUTRAL if date not found or data unavailable.
        """
        dt = pd.Timestamp(dt)
        # Try exact match first, then nearest prior date
        if self._regime_df is not None and not self._regime_df.empty:
            regime_dates = pd.to_datetime(self._regime_df["date"])
            # Exact match
            mask = regime_dates == dt
            if mask.any():
                row = self._regime_df.loc[mask].iloc[0]
                return self._row_to_snapshot(row)
            # Nearest prior (look back up to 5 trading days)
            prior_mask = regime_dates <= dt
            if prior_mask.any():
                row = self._regime_df.loc[prior_mask].iloc[-1]
                return self._row_to_snapshot(row)

        return RegimeSnapshot(date=dt.date() if hasattr(dt, 'date') else dt)

    def get_regime_dataframe(self) -> pd.DataFrame:
        """Return the full regime DataFrame (for join operations)."""
        if self._regime_df is None:
            return pd.DataFrame()
        return self._regime_df.copy()

    @property
    def is_available(self) -> bool:
        """True if regime data was successfully fetched."""
        return self._fetched and self._regime_df is not None and not self._regime_df.empty

    # -----------------------------------------------------------------
    # Internal: Fetch + Build
    # -----------------------------------------------------------------

    def _fetch_and_build(self) -> bool:
        """Fetch NIFTY + VIX from yfinance, compute moving averages, join."""
        try:
            import yfinance as yf
        except ImportError:
            logger.warning("yfinance not installed — regime data unavailable")
            return False

        # --- Fetch NIFTY 50 ---
        try:
            nifty = yf.download("^NSEI", start="2020-01-01", end=None,
                               progress=False, auto_adjust=True)
            if isinstance(nifty.columns, pd.MultiIndex):
                nifty.columns = nifty.columns.get_level_values(0)
            nifty = nifty["Close"].dropna()
            nifty.index = pd.to_datetime(nifty.index).tz_localize(None)
            logger.info(f"Fetched NIFTY 50: {len(nifty)} bars")
        except Exception as e:
            logger.error(f"Failed to fetch NIFTY 50: {e}")
            return False

        # --- Fetch India VIX ---
        try:
            vix = yf.download("^INDIAVIX", start="2020-01-01", end=None,
                              progress=False, auto_adjust=True)
            if isinstance(vix.columns, pd.MultiIndex):
                vix.columns = vix.columns.get_level_values(0)
            vix = vix["Close"].dropna()
            vix.index = pd.to_datetime(vix.index).tz_localize(None)
            logger.info(f"Fetched India VIX: {len(vix)} bars")
        except Exception as e:
            logger.error(f"Failed to fetch India VIX: {e}")
            vix = pd.Series(dtype=float)

        # --- Compute Moving Averages ---
        nifty_50dma = nifty.rolling(50).mean()
        nifty_200dma = nifty.rolling(200).mean()

        # --- Build regime DataFrame ---
        regime = pd.DataFrame({
            "date": nifty.index.date,
            "nifty_close": nifty.values,
            "nifty_50dma": nifty_50dma.values,
            "nifty_200dma": nifty_200dma.values,
        })
        regime["nifty_above_50dma"] = (nifty >= nifty_50dma).values
        regime["nifty_above_200dma"] = (nifty >= nifty_200dma).values

        # --- Join VIX ---
        if not vix.empty:
            vix_daily = vix.reindex(nifty.index).ffill(limit=5)
            regime["india_vix"] = vix_daily.values
        else:
            regime["india_vix"] = np.nan

        # --- Classify VIX regime ---
        regime["vix_regime"] = regime["india_vix"].apply(
            lambda v: classify_vix(v, self.vix_low, self.vix_high)
            if pd.notna(v) else "MEDIUM"
        )

        # Drop rows where 200-DMA is NaN (first 200 days)
        # but keep rows with 50-DMA NaN (first 50 days) since we have fallback
        regime = regime.dropna(subset=["nifty_200dma"])
        regime = regime.reset_index(drop=True)

        return len(regime) > 0

    def _row_to_snapshot(self, row: pd.Series) -> RegimeSnapshot:
        """Convert a DataFrame row to a RegimeSnapshot."""
        vix = float(row.get("india_vix", 0)) if pd.notna(row.get("india_vix")) else 0.0
        snap = RegimeSnapshot(
            date=pd.Timestamp(row["date"]).date(),
            nifty_close=float(row.get("nifty_close", 0)),
            nifty_50dma=float(row.get("nifty_50dma", 0)) if pd.notna(row.get("nifty_50dma")) else 0.0,
            nifty_200dma=float(row.get("nifty_200dma", 0)) if pd.notna(row.get("nifty_200dma")) else 0.0,
            nifty_above_50dma=bool(row.get("nifty_above_50dma", False)),
            nifty_above_200dma=bool(row.get("nifty_above_200dma", False)),
            india_vix=vix,
            vix_regime=row.get("vix_regime", "MEDIUM"),
        )
        return snap
