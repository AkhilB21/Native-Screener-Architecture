"""Apollo Live Engine — Daily Report Generator (v1.4).

Generates a per-day report with:

1. **All alerts fired on that date** — pulled from the SQLite ``alerts``
   table. Includes ENTRY, EXIT, HOLD, COOLDOWN, STARTUP, etc. (filterable).

2. **Top-N watchlist ranking by current score** — re-runs ``BarReplay``
   for each watchlist stock (fast, no alerts emitted) to compute the
   current composite score. Sorted descending. Top N (default 10) shown.

Output formats (per PROJECT_INSTRUCTIONS.md: "if ask for table, xlsx
preferred; if report, pdf/doc preferred" — but for a daily ops report
that needs to be grepped/diffed/emailed, MD + CSV is the right choice;
the user confirmed this in the v1.4 scope question):

* ``reports/YYYY-MM-DD.md`` — human-readable markdown
* ``reports/YYYY-MM-DD_alerts.csv`` — flat alerts table
* ``reports/YYYY-MM-DD_rankings.csv`` — flat rankings table

If Telegram is configured (env vars ``TELEGRAM_BOT_TOKEN`` +
``TELEGRAM_CHAT_ID``), the markdown summary is also pushed to the chat.

Usage
-----
::

    # Generate today's report
    python -m live_engine.daily_report --db live_state.db --watchlist my_watchlist.json

    # Generate a specific date
    python -m live_engine.daily_report --db live_state.db --date 2026-07-25

    # Custom top-N + data dir
    python -m live_engine.daily_report --top-n 20 --data-dir data

    # Skip Telegram push (file-only)
    python -m live_engine.daily_report --no-telegram
"""

from __future__ import annotations

import argparse
import csv
import io
import os
import sys
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from typing import Optional

import pandas as pd

# Ensure project root is on sys.path
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from live_engine.state_store import StateStore
from live_engine.data_replay import BarReplay
from live_engine.watchlist import load_available, DEFAULT_WATCHLIST_PATH


_CENTRAL_REPO = r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\APOLLO_DATA_REPOSITORY"
DEFAULT_DB_PATH = str(Path(_CENTRAL_REPO) / "live_state" / "live_state.db")
DEFAULT_REPORTS_DIR = str(Path(_CENTRAL_REPO) / "live_state" / "reports")
DEFAULT_TOP_N = 10
DEFAULT_START_DATE = "2024-01-01"  # for BarReplay (need enough history for indicators)

# Alert types excluded from the daily report's alert table (too noisy).
# They're still in the CSV (full record) but skipped from the MD summary.
NOISY_ALERT_TYPES = {"STARTUP"}


# ---------------------------------------------------------------------------
# Core logic
# ---------------------------------------------------------------------------


def fetch_alerts_for_date(store: StateStore, target_date: date) -> list[dict]:
    """Fetch all alerts whose timestamp falls on ``target_date`` (UTC calendar day)."""
    # The alerts table stores timestamps as ISO strings. For date-only
    # timestamps (e.g., "2026-07-24"), comparison is straightforward.
    # For full ISO timestamps (e.g., "2026-07-24T10:15:00+00:00"), we want any
    # timestamp whose date component matches target_date.
    #
    # Compare in UTC. Some alerts (STARTUP) carry tz-aware timestamps; others
    # (bar-date alerts like ENTRY/EXIT) are tz-naive (date-only). We localize
    # both sides to UTC for safe comparison.
    start_ts = pd.Timestamp(target_date, tz="UTC")
    end_ts = pd.Timestamp(target_date, tz="UTC") + pd.Timedelta(days=1)

    all_alerts = store.list_alerts_all_symbols(limit=100000)
    filtered = []
    for a in all_alerts:
        ts_str = a.get("timestamp", "")
        if not ts_str:
            continue
        try:
            ts = pd.Timestamp(ts_str)
        except (ValueError, TypeError):
            continue
        # Localize tz-naive timestamps to UTC for comparison
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        if start_ts <= ts < end_ts:
            filtered.append(a)
    # Oldest first for readability
    filtered.sort(key=lambda a: a.get("timestamp", ""))
    return filtered


def compute_current_scores(
    watchlist_path: str,
    data_dir: str,
    end_date: str,
    start_date: str = DEFAULT_START_DATE,
    entry_threshold: float = 70.0,
    exit_threshold: float = 50.0,
    verbose: bool = False,
) -> list[dict]:
    """Compute the current composite score for every watchlist stock with a CSV.

    Returns a list of dicts sorted by score descending:
        [{symbol, name, sector, score, last_date, bucket, is_ipo}, ...]
    """
    available = load_available(watchlist_path=watchlist_path, data_dir=data_dir)
    if not available:
        if verbose:
            print(f"[daily_report] No watchlist stocks have CSVs in {data_dir}",
                  file=sys.stderr)
        return []

    rows = []
    for entry in available:
        sym = entry["sym"]
        csv_path = Path(data_dir) / f"{sym}.csv"
        if not csv_path.exists():
            continue

        try:
            replay = BarReplay(
                data_dir=data_dir,
                symbol=sym,
                start_date=start_date,
                end_date=end_date,
                entry_threshold=entry_threshold,
                exit_threshold=exit_threshold,
            )
            # Drain the iterator to get the last bar's score
            last_bar = None
            n_bars = 0
            for bar in replay.replay():
                last_bar = bar
                n_bars += 1

            if last_bar is None:
                if verbose:
                    print(f"[daily_report] {sym}: no bars in range", file=sys.stderr)
                continue

            score = float(last_bar.daily_result.get("total", 0.0))
            last_date = last_bar.date
            bucket = getattr(last_bar, "bucket", "") or ""
            is_ipo = getattr(last_bar, "is_ipo", False)

            rows.append({
                "symbol": sym,
                "name": entry.get("name", sym),
                "sector": entry.get("sector", ""),
                "score": round(score, 2),
                "last_date": last_date.strftime("%Y-%m-%d") if hasattr(last_date, "strftime") else str(last_date),
                "bucket": bucket,
                "is_ipo": is_ipo,
                "n_bars": n_bars,
            })
            if verbose:
                print(f"[daily_report] {sym}: score={score:.1f}, bars={n_bars}",
                      file=sys.stderr)

        except Exception as e:
            if verbose:
                print(f"[daily_report] {sym}: FAILED ({e})", file=sys.stderr)
            rows.append({
                "symbol": sym,
                "name": entry.get("name", sym),
                "sector": entry.get("sector", ""),
                "score": 0.0,
                "last_date": "ERROR",
                "bucket": "",
                "is_ipo": False,
                "n_bars": 0,
                "error": str(e),
            })

    # Sort by score descending
    rows.sort(key=lambda r: r.get("score", 0.0), reverse=True)
    return rows


def fetch_open_positions(store: StateStore) -> list[dict]:
    """Fetch all symbols currently in-trade (position open)."""
    if store._conn is None:
        return []
    rows = store._conn.execute(
        "SELECT symbol, entry_price, entry_date, peak_close, pending_exit "
        "FROM monitor_state WHERE in_trade = 1 ORDER BY entry_date DESC"
    ).fetchall()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Report writers
# ---------------------------------------------------------------------------


def write_csv_alerts(alerts: list[dict], path: Path) -> None:
    """Write alerts to CSV."""
    fieldnames = ["timestamp", "symbol", "alert_type", "message", "payload_json"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for a in alerts:
            w.writerow(a)


def write_csv_rankings(rankings: list[dict], path: Path) -> None:
    """Write rankings to CSV."""
    fieldnames = ["rank", "symbol", "name", "sector", "score", "last_date", "bucket", "is_ipo", "n_bars"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for i, r in enumerate(rankings, 1):
            r2 = {"rank": i, **r}
            w.writerow(r2)


def render_markdown(
    target_date: date,
    alerts: list[dict],
    rankings: list[dict],
    open_positions: list[dict],
    top_n: int = DEFAULT_TOP_N,
    generated_at: Optional[datetime] = None,
) -> str:
    """Render the daily report as a markdown string."""
    generated_at = generated_at or datetime.now(timezone.utc)
    buf = io.StringIO()

    buf.write(f"# Apollo Live — Daily Report\n\n")
    buf.write(f"**Date:** {target_date.isoformat()}\n\n")
    buf.write(f"**Generated:** {generated_at.isoformat(timespec='seconds')}Z\n\n")
    buf.write("---\n\n")

    # ----- Alerts section -----
    buf.write(f"## Alerts Fired ({target_date.isoformat()})\n\n")
    visible_alerts = [a for a in alerts if a.get("alert_type") not in NOISY_ALERT_TYPES]

    if not visible_alerts:
        buf.write("_No (non-STARTUP) alerts fired on this date._\n\n")
    else:
        # Summary by type
        type_counts: dict[str, int] = {}
        for a in visible_alerts:
            t = a.get("alert_type", "UNKNOWN")
            type_counts[t] = type_counts.get(t, 0) + 1
        buf.write("**Summary:** ")
        buf.write(", ".join(f"{t} = {n}" for t, n in sorted(type_counts.items())))
        buf.write(f" (total {len(visible_alerts)})\n\n")

        # Table
        buf.write("| Timestamp | Symbol | Type | Message |\n")
        buf.write("|-----------|--------|------|--------|\n")
        for a in visible_alerts:
            ts = a.get("timestamp", "")
            sym = a.get("symbol", "")
            atype = a.get("alert_type", "")
            msg = (a.get("message", "") or "").replace("|", "\\|")
            buf.write(f"| {ts} | {sym} | {atype} | {msg} |\n")
        buf.write("\n")

    buf.write("---\n\n")

    # ----- Open positions section -----
    buf.write("## Open Positions\n\n")
    if not open_positions:
        buf.write("_No open positions._\n\n")
    else:
        buf.write("| Symbol | Entry Date | Entry Price | Peak Close | Pending Exit |\n")
        buf.write("|--------|-----------|-------------|------------|--------------|\n")
        for p in open_positions:
            sym = p.get("symbol", "")
            edate = p.get("entry_date", "")
            eprice = p.get("entry_price", "")
            eprice_str = f"{eprice:.2f}" if isinstance(eprice, (int, float)) else str(eprice)
            peak = p.get("peak_close", "")
            peak_str = f"{peak:.2f}" if isinstance(peak, (int, float)) else str(peak)
            pend = "YES" if p.get("pending_exit") else "no"
            buf.write(f"| {sym} | {edate} | {eprice_str} | {peak_str} | {pend} |\n")
        buf.write("\n")

    buf.write("---\n\n")

    # ----- Top-N watchlist ranking -----
    buf.write(f"## Top {top_n} Watchlist (by current score)\n\n")
    if not rankings:
        buf.write("_No watchlist stocks have CSVs on disk. Drop CSVs in `data/` to populate this section._\n\n")
    else:
        buf.write("| Rank | Symbol | Score | Last Date | Bucket | IPO |\n")
        buf.write("|------|--------|-------|-----------|--------|-----|\n")
        for i, r in enumerate(rankings[:top_n], 1):
            buf.write(
                f"| {i} | {r['symbol']} | {r['score']:.1f} | "
                f"{r.get('last_date', '')} | {r.get('bucket', '')} | "
                f"{'YES' if r.get('is_ipo') else 'no'} |\n"
            )
        buf.write("\n")

    buf.write("---\n\n")
    buf.write("_Apollo Live Engine — daily_report.py_\n")

    return buf.getvalue()


# ---------------------------------------------------------------------------
# Telegram push (optional)
# ---------------------------------------------------------------------------


def push_to_telegram(markdown: str, verbose: bool = False) -> bool:
    """Push the markdown summary to Telegram (if env vars are set)."""
    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not bot_token or not chat_id:
        if verbose:
            print("[daily_report] Telegram env vars not set — skipping push",
                  file=sys.stderr)
        return False

    # Telegram messages have a 4096-char limit. Truncate to first ~3900 chars
    # and add a continuation marker.
    msg = markdown if len(markdown) <= 3900 else markdown[:3900] + "\n\n…(truncated)"

    import urllib.parse
    import urllib.request
    import urllib.error

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = urllib.parse.urlencode({
        "chat_id": chat_id,
        "text": msg,
        "parse_mode": "Markdown",
    }).encode("utf-8")

    try:
        req = urllib.request.Request(url, data=data, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            ok = resp.status == 200
            if not ok and verbose:
                body = resp.read().decode("utf-8", errors="replace")[:200]
                print(f"[daily_report] Telegram HTTP {resp.status}: {body}",
                      file=sys.stderr)
            return ok
    except Exception as e:
        if verbose:
            print(f"[daily_report] Telegram push failed: {e}", file=sys.stderr)
        return False


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def generate_report(
    db_path: str,
    watchlist_path: str,
    data_dir: str,
    target_date: Optional[date] = None,
    reports_dir: str = DEFAULT_REPORTS_DIR,
    top_n: int = DEFAULT_TOP_N,
    push_telegram: bool = True,
    start_date: str = DEFAULT_START_DATE,
    end_date: Optional[str] = None,
    verbose: bool = False,
) -> dict:
    """Generate the daily report. Returns a dict with output paths + stats.

    Parameters
    ----------
    db_path : str
        SQLite DB path (read by StateStore).
    watchlist_path : str
        Path to my_watchlist.json (used for ranking).
    data_dir : str
        Directory with CSVs (used for ranking).
    target_date : date | None
        Date for the report. Default: today (UTC).
    reports_dir : str
        Where to write the report files. Default: reports/.
    top_n : int
        How many top-ranked stocks to include in the MD summary. Default: 10.
    push_telegram : bool
        If True (default), push MD summary to Telegram (if env vars set).
    start_date, end_date : str
        Date range for the BarReplay score computation. Default: 2024-01-01 → today.
    """
    target_date = target_date or datetime.now(timezone.utc).date()
    end_date = end_date or target_date.isoformat()
    reports_path = Path(reports_dir)
    reports_path.mkdir(parents=True, exist_ok=True)

    date_str = target_date.isoformat()
    md_path = reports_path / f"{date_str}.md"
    csv_alerts_path = reports_path / f"{date_str}_alerts.csv"
    csv_rankings_path = reports_path / f"{date_str}_rankings.csv"

    if verbose:
        print(f"[daily_report] Generating report for {date_str}", file=sys.stderr)
        print(f"[daily_report]   db:         {db_path}", file=sys.stderr)
        print(f"[daily_report]   watchlist:  {watchlist_path}", file=sys.stderr)
        print(f"[daily_report]   data_dir:   {data_dir}", file=sys.stderr)
        print(f"[daily_report]   reports_dir:{reports_path}", file=sys.stderr)

    # 1. Fetch alerts from SQLite
    alerts: list[dict] = []
    if Path(db_path).exists():
        with StateStore(db_path) as store:
            alerts = fetch_alerts_for_date(store, target_date)
            open_positions = fetch_open_positions(store)
    else:
        if verbose:
            print(f"[daily_report] DB not found at {db_path} — alerts list will be empty",
                  file=sys.stderr)
        open_positions = []

    if verbose:
        print(f"[daily_report] {len(alerts)} alerts fetched for {date_str}",
              file=sys.stderr)
        print(f"[daily_report] {len(open_positions)} open positions",
              file=sys.stderr)

    # 2. Compute current scores for watchlist ranking
    rankings = compute_current_scores(
        watchlist_path=watchlist_path,
        data_dir=data_dir,
        end_date=end_date,
        start_date=start_date,
        verbose=verbose,
    )
    if verbose:
        print(f"[daily_report] {len(rankings)} symbols ranked", file=sys.stderr)

    # 3. Write CSVs
    write_csv_alerts(alerts, csv_alerts_path)
    write_csv_rankings(rankings, csv_rankings_path)

    # 4. Render markdown
    md = render_markdown(
        target_date=target_date,
        alerts=alerts,
        rankings=rankings,
        open_positions=open_positions,
        top_n=top_n,
    )
    md_path.write_text(md, encoding="utf-8")

    # 5. Push to Telegram (optional)
    telegram_pushed = False
    if push_telegram:
        telegram_pushed = push_to_telegram(md, verbose=verbose)

    return {
        "date": date_str,
        "md_path": str(md_path),
        "csv_alerts_path": str(csv_alerts_path),
        "csv_rankings_path": str(csv_rankings_path),
        "n_alerts": len(alerts),
        "n_rankings": len(rankings),
        "n_open_positions": len(open_positions),
        "telegram_pushed": telegram_pushed,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="apollo-daily-report",
        description="Apollo Live Engine — Daily Report Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--db", default=DEFAULT_DB_PATH,
                   help=f"SQLite state DB path (default: {DEFAULT_DB_PATH})")
    p.add_argument("--watchlist", default=DEFAULT_WATCHLIST_PATH,
                   help=f"Watchlist JSON path (default: {DEFAULT_WATCHLIST_PATH})")
    p.add_argument("--data-dir", default="data",
                   help="Directory with CSV files (default: data)")
    p.add_argument("--date", default=None,
                   help="Report date YYYY-MM-DD (default: today UTC)")
    p.add_argument("--reports-dir", default=DEFAULT_REPORTS_DIR,
                   help=f"Output directory (default: {DEFAULT_REPORTS_DIR})")
    p.add_argument("--top-n", type=int, default=DEFAULT_TOP_N,
                   help=f"Top N stocks in MD ranking (default: {DEFAULT_TOP_N})")
    p.add_argument("--start", default=DEFAULT_START_DATE,
                   help=f"BarReplay start date (default: {DEFAULT_START_DATE})")
    p.add_argument("--end", default=None,
                   help="BarReplay end date YYYY-MM-DD (default: --date)")
    p.add_argument("--no-telegram", action="store_true",
                   help="Skip Telegram push (file-only)")
    p.add_argument("--verbose", "-v", action="store_true",
                   help="Print progress to stderr")
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    target_date = None
    if args.date:
        try:
            target_date = datetime.strptime(args.date, "%Y-%m-%d").date()
        except ValueError as e:
            print(f"ERROR: invalid --date {args.date!r}: {e}", file=sys.stderr)
            return 2

    result = generate_report(
        db_path=args.db,
        watchlist_path=args.watchlist,
        data_dir=args.data_dir,
        target_date=target_date,
        reports_dir=args.reports_dir,
        top_n=args.top_n,
        push_telegram=not args.no_telegram,
        start_date=args.start,
        end_date=args.end,
        verbose=args.verbose,
    )

    print(f"Daily report for {result['date']}:")
    print(f"  Alerts:        {result['n_alerts']}")
    print(f"  Rankings:      {result['n_rankings']}")
    print(f"  Open positions:{result['n_open_positions']}")
    print(f"  Telegram push: {'YES' if result['telegram_pushed'] else 'no'}")
    print(f"  MD:            {result['md_path']}")
    print(f"  CSV alerts:    {result['csv_alerts_path']}")
    print(f"  CSV rankings:  {result['csv_rankings_path']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
