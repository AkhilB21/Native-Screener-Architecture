"""Apollo Live Engine — Live Feed Abstraction (v1.4).

Defines the abstract ``LiveFeed`` interface that the engine consumes
bars from. Today there's one concrete implementation:

* ``BarReplayFeed`` — wraps the existing ``BarReplay`` CSV iterator. This
  is what the engine uses for historical replay + testing. Production-safe.

And one stub for the future:

* ``KiteLiveFeed`` — placeholder for Zerodha Kite Connect integration.
  Raises ``NotImplementedError`` on every method. This is intentional —
  v1.4's job is to define the *interface*, not ship a live broker
  integration. When the user is ready to go live (Step 5+), this class
  gets filled in with real websocket + REST calls.

Why an abstraction?
-------------------
The current ``MultiStockMonitor`` calls ``monitor.replay.replay()`` directly.
That couples the monitor to CSV-backed replay forever. By introducing a
``LiveFeed`` protocol, we make the monitor data-source-agnostic:

    ┌──────────────────┐
    │ MultiStockMonitor│  ← consumes bars, doesn't care where they come from
    └────────┬─────────┘
             │ next_bar()
             ▼
    ┌──────────────────┐
    │   LiveFeed       │  ← interface (Protocol)
    └────────┬─────────┘
             │
       ┌─────┴─────┬─────────────┐
       ▼           ▼             ▼
  BarReplayFeed  KiteLiveFeed  (future: UpstoxFeed, FyersFeed, ...)

When the user is ready to plug in Kite, they:

1. Implement ``KiteLiveFeed.next_bar()`` to return a ``ReplayBar``-shaped
   object built from a Kite websocket tick / historical OHLC fetch.
2. Pass ``feed=KiteLiveFeed(...)`` to ``MultiStockMonitor`` instead of
   letting it build a ``BarReplay`` internally.

No monitor code changes required.

Protocol vs ABC
---------------
We use ``typing.Protocol`` (structural subtyping) rather than ``abc.ABC``
(nominal subtyping). This means any class with the right method signatures
is a ``LiveFeed`` — no inheritance required. Useful when wrapping third-party
libraries whose classes we can't subclass.

Bar shape
---------
The feed yields ``ReplayBar`` objects (defined in ``data_replay.py``).
This is the same shape ``SignalMonitor.process_bar()`` expects, so no
adapter is needed between feed and monitor.
"""

from __future__ import annotations

import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Iterator, Optional, Protocol, runtime_checkable

import pandas as pd

# Ensure project root is on sys.path
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from live_engine.data_replay import BarReplay, ReplayBar


# ---------------------------------------------------------------------------
# LiveFeed protocol — what every feed must implement
# ---------------------------------------------------------------------------


@runtime_checkable
class LiveFeed(Protocol):
    """Abstract live-data feed.

    A "feed" is anything that yields ``ReplayBar``-shaped objects one at a
    time, in chronological order, until exhausted (or until the market
    closes / connection drops).

    Implementations:

    * ``BarReplayFeed`` — historical CSV replay (testing, backtesting).
    * ``KiteLiveFeed`` — Zerodha Kite Connect live data (stub, v1.5+).

    Attributes
    ----------
    symbol : str
        The symbol this feed is bound to. One feed per symbol (matches
        the current ``MultiStockMonitor`` architecture — N feeds for N stocks).
    source : str
        Human-readable source label (e.g., "csv-replay", "kite-live").
        Used in logs + alerts to disambiguate data origin.
    """

    symbol: str
    source: str

    def __iter__(self) -> Iterator[ReplayBar]:
        """Yield bars chronologically. End-of-feed signaled by ``StopIteration``."""
        ...

    def next_bar(self) -> Optional[ReplayBar]:
        """Return the next bar, or ``None`` if exhausted.

        This is the pull-style API the monitor uses in its round-robin loop.
        Default impl in concrete classes: ``return next(iter(self), None)``.
        """
        ...

    def close(self) -> None:
        """Release any underlying resources (websocket, file handles, etc.).

        Called by the monitor when stopping. Safe to call multiple times.
        """
        ...


# ---------------------------------------------------------------------------
# BarReplayFeed — concrete impl wrapping the existing CSV replay
# ---------------------------------------------------------------------------


class BarReplayFeed:
    """LiveFeed impl backed by ``BarReplay`` (CSV historical replay).

    This is a thin adapter: it wraps the existing ``BarReplay`` iterator
    so the monitor can treat it the same as a future live broker feed.

    Parameters
    ----------
    data_dir, symbol, start_date, end_date : str
        Same as ``BarReplay``.
    entry_threshold, exit_threshold : float
        Same as ``BarReplay``.
    """

    symbol: str
    source: str = "csv-replay"

    def __init__(
        self,
        data_dir: str,
        symbol: str,
        start_date: str,
        end_date: str,
        entry_threshold: float = 70.0,
        exit_threshold: float = 50.0,
    ):
        self.symbol = symbol
        self._replay = BarReplay(
            data_dir=data_dir,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            entry_threshold=entry_threshold,
            exit_threshold=exit_threshold,
        )
        # Build the iterator lazily so __init__ doesn't trigger a CSV load
        # if the feed is never actually consumed (e.g., test setups).
        self._iter: Optional[Iterator[ReplayBar]] = None

    def __iter__(self) -> Iterator[ReplayBar]:
        if self._iter is None:
            self._iter = self._replay.replay()
        return self._iter

    def next_bar(self) -> Optional[ReplayBar]:
        """Return the next bar, or ``None`` if exhausted."""
        if self._iter is None:
            self._iter = self._replay.replay()
        try:
            return next(self._iter)
        except StopIteration:
            return None

    def close(self) -> None:
        """No resources to release for CSV-backed replay."""
        # Clear the iterator reference so it can be GC'd
        self._iter = None

    # Convenience pass-throughs for code that previously accessed
    # replay attributes directly (e.g., is_ipo, bucket).
    @property
    def is_ipo(self) -> bool:
        return self._replay.is_ipo

    @property
    def bucket(self) -> str:
        return self._replay.bucket

    @property
    def n_bars(self) -> int:
        return self._replay.n_bars


# ---------------------------------------------------------------------------
# KiteLiveFeed — STUB for future Zerodha Kite Connect integration
# ---------------------------------------------------------------------------


class KiteLiveFeed:
    """STUB — Zerodha Kite Connect live feed. Not implemented in v1.4.

    This class exists to:
    1. Document the interface that a future live implementation must satisfy.
    2. Let callers write ``feed = KiteLiveFeed(...)`` today and get a clear
       ``NotImplementedError`` instead of an ``ImportError`` or silent failure.
    3. Provide a checklist (in the form of method signatures) for the
       Step 5+ implementation work.

    When implementing (v1.5+):

    1. ``__init__`` — accept Kite credentials (api_key, access_token),
       instrument token (resolved from symbol via Kite's instrument master).
       Open a KiteTicker websocket connection.
    2. ``__iter__`` / ``next_bar`` — convert incoming ticks to OHLC bars
       at the configured timeframe (e.g., 1-day or 1-minute). Buffer ticks
       until the bar closes, then yield a ``ReplayBar``-shaped object.

       *For daily-bar live mode* (simplest): poll Kite's historical OHLC
       endpoint once per day at market close (3:30 PM IST) and yield one
       bar per day. This matches the current ``BarReplay`` bar shape and
       requires no websocket.

    3. ``close`` — close the websocket cleanly. KiteTicker has a ``close()``
       method; call it here.

    Required Kite Connect API surface (v3):

    * ``kite.connect.kiteConnect`` — REST client for historical OHLC.
    * ``kiteconnect.ticker.KiteTicker`` — websocket for live ticks.
    * ``kite.ltp(instruments)`` — last traded price (for sanity checks).
    * ``kite.historical_data(instrument_token, from_date, to_date, interval)``
      — historical OHLC for warmup (needed to compute RSI etc. on day 1).

    Dependencies to add to ``requirements.txt`` when implementing:

        kiteconnect>=4.2.0

    Environment variables (when implemented):

        KITE_API_KEY       — Kite Connect app API key
        KITE_ACCESS_TOKEN  — daily access token (from login flow)
        KITE_INSTRUMENT_TOKEN_<SYMBOL> — per-symbol instrument token
                                          (or resolve via symbol→token map)

    See LEARN.md (Step 5+) for the full integration plan.
    """

    symbol: str
    source: str = "kite-live"

    def __init__(
        self,
        symbol: str,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        instrument_token: Optional[int] = None,
        timeframe: str = "day",
    ):
        self.symbol = symbol
        self.api_key = api_key or os.environ.get("KITE_API_KEY")
        self.access_token = access_token or os.environ.get("KITE_ACCESS_TOKEN")
        self.instrument_token = instrument_token
        self.timeframe = timeframe

        if not self.api_key or not self.access_token:
            raise NotImplementedError(
                "KiteLiveFeed is not yet implemented (v1.4 stub). "
                "To enable: implement __init__ to open a KiteTicker websocket, "
                "implement next_bar() to yield ReplayBar-shaped objects from "
                "incoming ticks. See live_feed.py docstring for the full plan. "
                "Required env vars: KITE_API_KEY, KITE_ACCESS_TOKEN."
            )

        # If creds are present, still raise — the actual websocket + tick
        # aggregation logic is not yet written. This is the line that gets
        # replaced with real KiteTicker code in v1.5+.
        raise NotImplementedError(
            "KiteLiveFeed credentials detected but implementation is stubbed. "
            "Implement next_bar() + close() per the docstring plan."
        )

    def __iter__(self) -> Iterator[ReplayBar]:
        raise NotImplementedError

    def next_bar(self) -> Optional[ReplayBar]:
        raise NotImplementedError

    def close(self) -> None:
        # No resources were opened (constructor raised), nothing to close.
        pass


# ---------------------------------------------------------------------------
# Factory — pick a feed by name (used by future CLI flags)
# ---------------------------------------------------------------------------


def make_feed(
    source: str,
    symbol: str,
    data_dir: str = "data",
    start_date: str = "2024-01-01",
    end_date: Optional[str] = None,
    entry_threshold: float = 70.0,
    exit_threshold: float = 50.0,
    **kwargs,
) -> LiveFeed:
    """Build a LiveFeed by source name.

    Parameters
    ----------
    source : str
        "csv" → BarReplayFeed (default, fully implemented).
        "kite" → KiteLiveFeed (stub, raises NotImplementedError).
    symbol : str
        NSE stock symbol (e.g., "CYIENTDLM").
    data_dir, start_date, end_date : str
        Used by BarReplayFeed. Ignored by KiteLiveFeed.
    entry_threshold, exit_threshold : float
        Score thresholds. Used by BarReplayFeed.
    **kwargs
        Source-specific options (e.g., api_key for Kite).
    """
    end_date = end_date or datetime.now().strftime("%Y-%m-%d")

    if source == "csv":
        return BarReplayFeed(
            data_dir=data_dir,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            entry_threshold=entry_threshold,
            exit_threshold=exit_threshold,
        )
    elif source == "kite":
        return KiteLiveFeed(symbol=symbol, **kwargs)
    else:
        raise ValueError(
            f"Unknown feed source: {source!r}. Valid: 'csv', 'kite'."
        )
