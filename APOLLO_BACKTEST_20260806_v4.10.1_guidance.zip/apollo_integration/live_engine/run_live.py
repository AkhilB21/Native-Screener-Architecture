"""Apollo Live Engine — Single Launcher.

Phase 2 Step 3 (v1.3) — Convenience launcher that starts the Streamlit
dashboard. The dashboard itself has buttons to start/stop the monitor
subprocess, so this launcher just needs to bring up the UI.

Usage
-----
    python live_engine/run_live.py                 # default port 8501
    python live_engine/run_live.py --port 8888     # custom port
    python live_engine/run_live.py --no-browser    # don't auto-open browser

What it does
------------
1. Verifies the project structure (apollo_core/, live_engine/, data/) exists.
2. Prints a banner with the version + URL.
3. Runs ``streamlit run live_engine/dashboard.py`` with the given args.

The monitor itself is started from the dashboard's "Start Monitor" button —
that way you can pick the symbol and date range interactively. If you want
to run the monitor headless (no UI), use ``python -m live_engine`` directly
(see ``live_engine/cli.py`` for options).
"""

from __future__ import annotations

import os
import sys
import subprocess
import argparse
from pathlib import Path


# Resolve paths
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
DASHBOARD_PATH = os.path.join(_THIS_DIR, "dashboard.py")


def _check_project_structure() -> list[str]:
    """Verify required directories exist. Returns list of missing items."""
    missing = []
    required = [
        ("apollo_core", "apollo_core package"),
        ("apollo_core/types.py", "types module"),
        ("apollo_core/trade_engine.py", "trade_engine module"),
        ("live_engine", "live_engine package"),
        ("live_engine/dashboard.py", "dashboard module"),
        ("live_engine/signal_monitor.py", "signal_monitor module"),
        ("live_engine/state_store.py", "state_store module"),
        ("live_engine/cli.py", "cli module"),
        ("backtest_engine/eod2_loader.py", "eod2_loader (used by data_replay)"),
    ]
    for rel, desc in required:
        full = os.path.join(_PROJECT_ROOT, rel)
        if not os.path.exists(full):
            missing.append(f"{rel} ({desc})")
    return missing


def _print_banner(port: int):
    """Print a startup banner."""
    try:
        from live_engine import __version__
    except ImportError:
        __version__ = "?.?"
    print()
    print("=" * 60)
    print(f"  🛰️  APOLLO LIVE ENGINE  v{__version__}")
    print("=" * 60)
    print()
    print(f"  Project root: {_PROJECT_ROOT}")
    print(f"  Dashboard:    {DASHBOARD_PATH}")
    print(f"  URL:          http://localhost:{port}")
    print()
    print("  Instructions:")
    print("    1. Pick a symbol + date range in the sidebar.")
    print("    2. Click '▶ Start Monitor' to begin processing bars.")
    print("    3. Watch alerts appear in real time. The score chart")
    print("       shows ENTRY (green ▲) and EXIT (red ▼) markers.")
    print("    4. In human-confirm mode (default), click '✓ Confirm Exit'")
    print("       when an EXIT alert fires to close the position.")
    print()
    print("  Press Ctrl+C to stop the dashboard.")
    print("=" * 60)
    print()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="apollo-live-launcher",
        description="Launch the Apollo Live Engine dashboard (Streamlit UI).",
    )
    parser.add_argument("--port", type=int, default=8501,
                        help="Port for the Streamlit server (default: 8501)")
    parser.add_argument("--no-browser", action="store_true",
                        help="Don't auto-open the browser")
    parser.add_argument("--debug", action="store_true",
                        help="Run Streamlit in debug mode (more verbose)")
    args = parser.parse_args(argv)

    # Verify project structure
    missing = _check_project_structure()
    if missing:
        print("ERROR: Required files missing:")
        for m in missing:
            print(f"  - {m}")
        print()
        print(f"Project root: {_PROJECT_ROOT}")
        print("Make sure you're running this from the project root directory.")
        return 1

    # Verify streamlit is installed
    try:
        import streamlit  # noqa: F401
    except ImportError:
        print("ERROR: streamlit is not installed.")
        print("Run: pip install streamlit")
        return 1

    # Print banner
    _print_banner(args.port)

    # Build streamlit command
    cmd = [
        sys.executable, "-m", "streamlit", "run",
        DASHBOARD_PATH,
        "--server.port", str(args.port),
        "--server.headless", "true" if args.no_browser else "false",
        "--browser.gatherUsageStats", "false",
    ]
    if args.debug:
        cmd.extend(["--logger.level", "debug"])

    # Run streamlit (blocks until Ctrl+C)
    try:
        proc = subprocess.run(cmd)
        return proc.returncode
    except KeyboardInterrupt:
        print()
        print("Dashboard stopped by user.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
