"""Apollo Live Engine — Watchlist loader.

Reads a JSON watchlist file (default: ``my_watchlist.json`` at project root)
and filters it to only the symbols whose CSV data is actually present in
``data_dir``. This is what populates the multi-stock dashboard's monitored
universe.

Watchlist format
----------------
The watchlist file is a JSON array of objects with at least these keys::

    [
        {"sym": "360ONE.NS",  "name": "360ONE",         "sector": ""},
        {"sym": "AARTIIND.NS","name": "Aarti Industries","sector": "Chemicals"},
        ...
    ]

* ``sym``    — Yahoo-Finance-style symbol (``<BASE>.NS``). The ``.NS`` suffix
  is stripped before matching against ``<BASE>.csv`` files in ``data_dir``.
* ``name``   — display name (may differ from ``sym`` for human-friendly labels).
* ``sector`` — optional sector tag for grouping/filtering.

Filtering
---------
The dashboard only monitors stocks whose CSV is on disk. So ``load_available``
returns the intersection of (watchlist symbols) ∩ (CSVs in ``data_dir``).
This prevents the v1.1 "FileNotFoundError when switching stock" bug at scale —
if you have 515 stocks in the watchlist but only 1 CSV in ``data/``, the
dashboard monitors exactly 1 stock, not 515.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Optional


_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJECT_ROOT = os.path.dirname(_THIS_DIR)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


DEFAULT_WATCHLIST_PATH = str(Path(_PROJECT_ROOT) / "my_watchlist.json")


# Stocks always shown first in any list derived from the watchlist, in this
# declared order. Matches the locked test list in PROJECT_INSTRUCTIONS.md.
TEST_STOCKS = ["APOLLO", "CYIENTDLM", "SYRMA", "JYOTICNC", "KAYNES"]


def _strip_ns_suffix(sym: str) -> str:
    """Strip a ``.NS`` (Yahoo Finance) suffix from a symbol, if present.

    ``"CYIENTDLM.NS"`` → ``"CYIENTDLM"``
    ``"APOLLO"``       → ``"APOLLO"``
    """
    if sym.endswith(".NS"):
        return sym[:-3]
    return sym


def load_watchlist(path: str = DEFAULT_WATCHLIST_PATH) -> list[dict]:
    """Load the watchlist JSON file.

    Parameters
    ----------
    path : str
        Path to the watchlist JSON file. Default: ``<project_root>/my_watchlist.json``.

    Returns
    -------
    list[dict]
        List of watchlist entries (each with ``sym``, ``name``, ``sector``).
        Returns an empty list if the file doesn't exist or is malformed
        (a warning is printed to stderr in those cases).
    """
    p = Path(path)
    if not p.exists():
        print(f"[watchlist] WARNING: watchlist file not found at {path}", file=sys.stderr)
        return []
    try:
        with p.open() as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        print(f"[watchlist] WARNING: failed to parse {path}: {e}", file=sys.stderr)
        return []

    if not isinstance(data, list):
        print(f"[watchlist] WARNING: expected JSON array, got {type(data).__name__}", file=sys.stderr)
        return []

    # Normalize: ensure each entry has sym/name/sector, strip .NS from sym
    normalized = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        sym = entry.get("sym", "")
        if not sym:
            continue
        normalized.append({
            "sym": _strip_ns_suffix(sym),
            "raw_sym": sym,  # preserve original (e.g., "CYIENTDLM.NS")
            "name": entry.get("name", sym),
            "sector": entry.get("sector", ""),
        })
    return normalized


def list_available_csvs(data_dir: str) -> set[str]:
    """Return the set of base symbols (uppercase) whose CSV exists in ``data_dir``.

    Skips ``*_D.csv``, ``*_4H.csv``, ``*_W.csv`` sidecars (intermediate files
    produced by ``load_eod2_stock``, not primary symbol feeds).
    """
    p = Path(data_dir)
    if not p.is_dir():
        return set()
    found = set()
    for f in p.glob("*.csv"):
        name = f.stem
        if name.endswith("_D") or name.endswith("_4H") or name.endswith("_W"):
            continue
        found.add(name.upper())
    return found


def load_available(
    watchlist_path: str = DEFAULT_WATCHLIST_PATH,
    data_dir: str = str(Path(_PROJECT_ROOT) / "data"),
) -> list[dict]:
    """Load the watchlist and filter to symbols whose CSV is in ``data_dir``.

    Returns
    -------
    list[dict]
        Watchlist entries (with ``sym``, ``raw_sym``, ``name``, ``sector``)
        for stocks that have CSV data on disk. Known test stocks come first
        (in declared order), then any extras alphabetically by symbol.
    """
    wl = load_watchlist(watchlist_path)
    if not wl:
        return []

    csvs = list_available_csvs(data_dir)
    available = [e for e in wl if e["sym"].upper() in csvs]

    # Sort: test stocks first (in declared order), then extras alphabetically
    def sort_key(entry: dict):
        sym = entry["sym"].upper()
        if sym in TEST_STOCKS:
            return (0, TEST_STOCKS.index(sym), sym)
        return (1, 0, sym)

    return sorted(available, key=sort_key)


def list_available_symbols(
    watchlist_path: str = DEFAULT_WATCHLIST_PATH,
    data_dir: str = str(Path(_PROJECT_ROOT) / "data"),
) -> list[str]:
    """Convenience: return just the symbol list from ``load_available``."""
    return [e["sym"] for e in load_available(watchlist_path, data_dir)]
