from nse_engine.run_pipeline import main
import sys

sys.exit(main())
