"""NSE Data Engine Pipeline - Drop-in replacement for chartink_pipeline.

Fetches OHLCV from yfinance, runs 12 scans, scores stocks,
and updates Apollo's my_watchlist.json.

Usage:
    python -m nse_engine                                  # Full pipeline
    python -m nse_engine --dry-run                       # Preview, don't write
    python -m nse_engine --sync-data "C:\\path\\to\\eod2_data\\daily"  # + copy CSVs
    python -m nse_engine --rsi-only                      # RSI dashboard only
    python -m nse_engine --gainers-only                  # Gainers only
    python -m nse_engine --top 50                        # Limit watchlist
    python -m nse_engine --threshold 30 --max 200        # Relaxed filters
    python -m nse_engine --force-refresh                 # Ignore cache
    python -m nse_engine --symbols RELIANCE,TCS,INFY      # Custom stock list

VPS Cron (daily at 3:45 PM IST, after market close):
    45 15 * * 1-5 cd /path/to/apollo_engine && \\
        python -m nse_engine --sync-data /path/to/eod2_data/daily >> logs/nse_engine.log 2>&1
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

import numpy as np


class _NumpyEncoder(json.JSONEncoder):
    """JSON encoder that handles numpy/pandas types."""
    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super().default(obj)


# Patch json module so watchlist_generator's save_outputs works with int64
_orig_json_dump = json.dump


def _safe_json_dump(obj, fp, **kwargs):
    kwargs.setdefault("cls", _NumpyEncoder)
    _orig_json_dump(obj, fp, **kwargs)


json.dump = _safe_json_dump

# Paths relative to THIS file inside apollo_engine/nse_engine/
_THIS_DIR = Path(__file__).resolve().parent
_PROJECT_ROOT = _THIS_DIR.parent  # apollo_engine/
_DEFAULT_WATCHLIST = _PROJECT_ROOT / "my_watchlist.json"
_DEFAULT_DATA_DIR = _PROJECT_ROOT / "data"
_DEFAULT_OUTPUT_DIR = _PROJECT_ROOT / "nse_output"

# Add project root to sys.path so imports work regardless of cwd
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from nse_engine.data_feed import NSEDataFeed, TIMEFRAME_CONFIG
from nse_engine.scanner import NSEScanner, RSI_DASHBOARD_TFS, GAINER_TF_CONFIG
from chartink_pipeline.watchlist_generator import ChartinkApolloBridge


# -- Helpers -----------------------------------------------------------


def save_yfinance_to_data_dir(
    ohlcv_data: dict,
    watchlist: list[dict],
    apollo_data_dir: Path = _DEFAULT_DATA_DIR,
    force_refresh: bool = False,
) -> dict:
    """Save yfinance daily OHLCV as CSVs in Apollo's data/ folder.

    This is the PRIMARY data bridge: NSE Engine downloads yfinance data,
    then saves the top-scoring stocks' daily bars as SYMBOL.csv files
    in Apollo's expected format (Date,Open,High,Low,Close,Volume).

    The eod2_loader.py will then compute all 12 indicators on top of
    this data when the live/backtest engine loads it.

    For existing CSVs, this appends new bars (doesn't overwrite history).
    For new stocks, it creates the CSV from scratch.

    Parameters
    ----------
    ohlcv_data : dict
        {timeframe: {symbol.NS: DataFrame}} from NSEDataFeed.
    watchlist : list[dict]
        Top-scoring stocks from the pipeline.
    apollo_data_dir : Path
        Target directory (apollo_engine/data/).
    force_refresh : bool
        If True, overwrite existing CSVs instead of appending.

    Returns
    -------
    dict with keys: created, updated, skipped, failed
    """
    import pandas as pd

    apollo_data_dir = Path(apollo_data_dir)
    apollo_data_dir.mkdir(parents=True, exist_ok=True)

    # Get daily data from the fetched OHLCV
    daily_data = ohlcv_data.get("daily", {})
    if not daily_data:
        # Fallback: try to use whatever data we have
        for tf in ("daily", "2day", "3day"):
            daily_data = ohlcv_data.get(tf, {})
            if daily_data:
                break

    if not daily_data:
        print("  WARNING: No daily OHLCV data available to save")
        return {"created": 0, "updated": 0, "skipped": 0, "failed": 0}

    stats = {"created": 0, "updated": 0, "skipped": 0, "failed": 0}

    for entry in watchlist:
        raw_sym = entry.get("sym", "")
        sym = raw_sym.replace(".NS", "").upper()
        if not sym:
            continue

        # Find this stock's daily data
        yf_key = f"{sym}.NS"
        df = daily_data.get(yf_key)
        if df is None:
            # Try without .NS
            df = daily_data.get(sym)
        if df is None:
            stats["failed"] += 1
            continue

        if df.empty:
            stats["failed"] += 1
            continue

        try:
            # Prepare DataFrame in Apollo's expected CSV format:
            # Date,Open,High,Low,Close,Volume
            out_df = pd.DataFrame()
            out_df["Date"] = pd.to_datetime(df.index).strftime("%Y-%m-%d")
            out_df["Open"] = df["open"].values if "open" in df.columns else df["Open"].values
            out_df["High"] = df["high"].values if "high" in df.columns else df["High"].values
            out_df["Low"] = df["low"].values if "low" in df.columns else df["Low"].values
            out_df["Close"] = df["close"].values if "close" in df.columns else df["Close"].values
            out_df["Volume"] = df["volume"].values if "volume" in df.columns else df["Volume"].values

            csv_path = apollo_data_dir / f"{sym}.csv"

            if csv_path.exists() and not force_refresh:
                # Append mode: load existing, keep only new bars
                existing = pd.read_csv(csv_path)
                existing["Date"] = pd.to_datetime(existing["Date"]).dt.strftime("%Y-%m-%d")
                existing_dates = set(existing["Date"].values)
                new_rows = out_df[~out_df["Date"].isin(existing_dates)]
                if new_rows.empty:
                    stats["skipped"] += 1
                    continue
                # Combine: old + new, sort by date
                combined = pd.concat([existing, new_rows], ignore_index=True)
                combined["Date"] = pd.to_datetime(combined["Date"])
                combined = combined.sort_values("Date").drop_duplicates(subset=["Date"])
                combined["Date"] = combined["Date"].dt.strftime("%Y-%m-%d")
                combined.to_csv(csv_path, index=False)
                stats["updated"] += 1
            else:
                # Create new or force refresh
                out_df.to_csv(csv_path, index=False)
                stats["created"] += 1

        except Exception as e:
            print(f"  WARNING: Failed to save {sym}.csv: {e}")
            stats["failed"] += 1

    print(f"  Yfinance -> data/ sync complete:")
    print(f"    Created:  {stats['created']} new CSVs")
    print(f"    Updated:  {stats['updated']} existing CSVs (appended new bars)")
    print(f"    Skipped:  {stats['skipped']} (already up-to-date)")
    if stats["failed"]:
        print(f"    Failed:   {stats['failed']}")

    return stats


def save_raw_data(rsi_data, gainer_data, output_dir, timestamp):
    """Save scan results for debugging/audit."""
    raw_dir = output_dir / "raw" / timestamp
    raw_dir.mkdir(parents=True, exist_ok=True)
    for tf_name, df in rsi_data.items():
        if not df.empty:
            df.to_csv(raw_dir / f"rsi_{tf_name}.csv", index=False)
    for tf_name, df in gainer_data.items():
        if not df.empty:
            df.to_csv(raw_dir / f"nifty500_{tf_name}.csv", index=False)
    raw_json = {
        "timestamp": timestamp,
        "source": "nse_engine (yfinance)",
        "rsi_timeframes": {k: len(v) for k, v in rsi_data.items()},
        "gainer_timeframes": {k: len(v) for k, v in gainer_data.items()},
    }
    with open(raw_dir / "fetch_summary.json", "w") as f:
        json.dump(raw_json, f, indent=2)
    print(f"  Raw data saved to: {raw_dir}")


def merge_into_apollo_watchlist(
    watchlist: list[dict],
    watchlist_path: Path = _DEFAULT_WATCHLIST,
    backup_existing: bool = True,
) -> str:
    """Merge curated stocks into Apollo's my_watchlist.json.

    This MERGES (doesn't replace) - existing entries are preserved.
    New stocks are appended. Duplicates are skipped.
    """
    existing = []
    if watchlist_path.exists():
        if backup_existing:
            backup_path = watchlist_path.with_suffix(".json.bak")
            shutil.copy2(watchlist_path, backup_path)
            print(f"  Backed up existing watchlist to: {backup_path}")
        try:
            with open(watchlist_path) as f:
                existing = json.load(f)
        except (json.JSONDecodeError, IOError):
            existing = []

    existing_syms = {
        e.get("sym", "").replace(".NS", "").upper() for e in existing
    }

    apollo_wl = list(existing)
    new_count = 0
    for entry in watchlist:
        sym = entry.get("sym", "").replace(".NS", "").upper()
        if sym not in existing_syms:
            apollo_wl.append({
                "sym": entry["sym"],
                "name": entry.get("name", sym),
                "sector": entry.get("sector", ""),
            })
            existing_syms.add(sym)
            new_count += 1

    with open(watchlist_path, "w") as f:
        json.dump(apollo_wl, f, indent=2)

    print(f"  Apollo watchlist updated: {watchlist_path}")
    print(f"    Existing entries: {len(existing)}")
    print(f"    New from NSE Engine: {new_count}")
    print(f"    Total: {len(apollo_wl)}")
    return str(watchlist_path)


def sync_eod2_data(
    watchlist: list[dict],
    eod2_dir: str,
    apollo_data_dir: Path = _DEFAULT_DATA_DIR,
) -> dict:
    """Copy eod2 CSVs for watchlist stocks into Apollo's data/ folder.

    This bridges the gap: NSE Engine picks the best stocks,
    then copies their historical CSVs so Apollo's full 34-signal
    scoring engine can deep-analyze them.

    Parameters
    ----------
    watchlist : list[dict]
        Curated watchlist from generate_apollo_watchlist().
    eod2_dir : str
        Path to your eod2 daily data directory (3500+ CSVs).
    apollo_data_dir : Path
        Apollo's data/ folder where backtest/live engines read from.

    Returns
    -------
    dict with keys: copied, skipped, not_found
    """
    eod2_path = Path(eod2_dir)
    if not eod2_path.is_dir():
        print(f"  ERROR: eod2 data directory not found: {eod2_path}")
        return {"copied": 0, "skipped": 0, "not_found": 0}

    apollo_data_dir = Path(apollo_data_dir)
    apollo_data_dir.mkdir(parents=True, exist_ok=True)

    # Build set of symbols already in Apollo's data/
    existing_csvs = set()
    for f in apollo_data_dir.glob("*.csv"):
        name = f.stem.upper()
        if not name.endswith(("_D", "_4H", "_W")):
            existing_csvs.add(name)

    copied = 0
    skipped = 0
    not_found = 0

    for entry in watchlist:
        sym = entry.get("sym", "").replace(".NS", "").upper()
        if not sym:
            continue

        # Already in Apollo's data/
        if sym in existing_csvs:
            skipped += 1
            continue

        # Try exact filename
        src = eod2_path / f"{sym}.csv"
        if not src.exists():
            # Try with NSE suffix variants
            for variant in [f"{sym}.NS", f"NSE:{sym}", sym.lower()]:
                src = eod2_path / f"{variant}.csv"
                if src.exists():
                    break
            else:
                not_found += 1
                continue

        dst = apollo_data_dir / f"{sym}.csv"
        shutil.copy2(src, dst)
        existing_csvs.add(sym)
        copied += 1

    print(f"  Data sync from eod2: {eod2_path}")
    print(f"    Copied:   {copied} new CSVs -> data/")
    print(f"    Skipped:  {skipped} (already present)")
    if not_found:
        print(f"    Not found: {not_found} (not in eod2 directory)")

    return {"copied": copied, "skipped": skipped, "not_found": not_found}


# -- Pipeline -------------------------------------------------------------


def run_pipeline(
    apollo_dir: str = "",
    output_dir: str = "",
    dry_run: bool = False,
    rsi_only: bool = False,
    gainers_only: bool = False,
    recovery_threshold: float = 40.0,
    max_watchlist: int = 100,
    force_refresh: bool = False,
    symbols: list[str] | None = None,
    sync_data_dir: str = "",
) -> dict:
    """Execute the full NSE Data Engine pipeline.

    Steps:
      1. Fetch OHLCV data via yfinance
      2. Run 12 scans (RSI Dashboard + NIFTY 500 Gainers)
      3. Process through ChartinkApolloBridge (same scoring logic)
      4. Generate curated watchlist
      5. Update Apollo's my_watchlist.json
      6. (Optional) Sync eod2 CSVs into Apollo's data/

    Returns a result dict with status, counts, and output paths.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d_%H%M")

    project_root = Path(apollo_dir) if apollo_dir else _PROJECT_ROOT
    out_dir = Path(output_dir) if output_dir else _DEFAULT_OUTPUT_DIR
    out_dir.mkdir(parents=True, exist_ok=True)

    result = {"timestamp": timestamp, "status": "started", "errors": []}

    print("=" * 60)
    print(f"  NSE DATA ENGINE v1.1")
    print(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S IST')}")
    print(f"  Source: yfinance (no browser, no cookies)")
    if sync_data_dir:
        print(f"  Data sync: {sync_data_dir}")
    print("=" * 60)

    # Determine which timeframes to fetch
    if rsi_only:
        tfs_to_fetch = list(set(RSI_DASHBOARD_TFS))
    elif gainers_only:
        tfs_to_fetch = list(set(
            [c["base_tf"] for c in GAINER_TF_CONFIG.values()]
        ))
    else:
        tfs_to_fetch = list(set(
            RSI_DASHBOARD_TFS +
            [c["base_tf"] for c in GAINER_TF_CONFIG.values()]
        ))

    # Step 1: Fetch data
    print(f"\n[1/8] Fetching OHLCV data ({len(tfs_to_fetch)} timeframes)...")
    feed = NSEDataFeed(
        symbols=symbols,
        use_cache=not force_refresh,
    )

    try:
        ohlcv_data = feed.fetch_all_timeframes(
            timeframes=tfs_to_fetch,
            force_refresh=force_refresh,
        )

        total_stocks = set()
        for tf, sym_data in ohlcv_data.items():
            total_stocks.update(sym_data.keys())
        print(f"  Data fetched: {len(total_stocks)} stocks across {len(ohlcv_data)} timeframes")

    except Exception as e:
        msg = f"Data fetch failed: {e}"
        print(f"  ERROR: {msg}")
        result["status"] = "fetch_error"
        result["errors"].append(msg)
        return result
    finally:
        feed.close()

    # Step 2: Run scans
    print("\n[2/8] Running scans...")
    scanner = NSEScanner(ohlcv_data)

    rsi_data = {}
    gainer_data = {}

    try:
        if not gainers_only:
            rsi_data = scanner.run_rsi_dashboard()
            rsi_total = sum(len(v) for v in rsi_data.values())
            print(f"\n  RSI Dashboard: {rsi_total} total rows across {len(rsi_data)} timeframes")
            result["rsi_rows"] = {k: len(v) for k, v in rsi_data.items()}
    except Exception as e:
        msg = f"RSI scan failed: {e}"
        print(f"  WARNING: {msg}")
        result["errors"].append(msg)

    try:
        if not rsi_only:
            gainer_data = scanner.run_nifty500_gainers()
            gainer_total = sum(len(v) for v in gainer_data.values())
            print(f"\n  NIFTY 500 Gainers: {gainer_total} total rows across {len(gainer_data)} timeframes")
            result["gainer_rows"] = {k: len(v) for k, v in gainer_data.items()}
    except Exception as e:
        msg = f"Gainer scan failed: {e}"
        print(f"  WARNING: {msg}")
        result["errors"].append(msg)

    save_raw_data(rsi_data, gainer_data, out_dir, timestamp)

    if rsi_only or gainers_only:
        print(f"\n  [{'RSI-ONLY' if rsi_only else 'GAINERS-ONLY'}] Skipping watchlist generation.")
        result["status"] = "partial"
        return result

    # Step 3: Process through Apollo Bridge (same scoring logic)
    print("\n[3/8] Processing RSI Dashboard...")
    apollo_data_dir = project_root / "data"
    bridge = ChartinkApolloBridge(
        apollo_data_dir=str(apollo_data_dir),
        output_dir=str(out_dir),
    )
    rsi_df = bridge.process_rsi_dashboard(rsi_data)
    print(f"  Unique stocks from RSI dashboard: {len(rsi_df)}")

    print("\n[4/8] Processing NIFTY 500 Gainers...")
    gainer_df = bridge.process_nifty500_gainers(gainer_data)
    print(f"  Unique stocks from NIFTY 500 Gainers: {len(gainer_df)}")

    # Step 4: Generate Recovery Watchlist
    print("\n[5/8] Cross-referencing and generating recovery watchlist...")
    ranked_df, watchlist = bridge.generate_apollo_watchlist(
        rsi_df=rsi_df,
        gainer_df=gainer_df,
        recovery_threshold=recovery_threshold,
        max_watchlist=max_watchlist,
    )

    # Step 5: Generate Momentum Table (separate from recovery)
    print("\n[6/8] Generating momentum candidates table...")
    momentum_df = bridge.generate_momentum_table(
        gainer_df=gainer_df,
        rsi_df=rsi_df,
        max_entries=max_watchlist,
    )

    # Enrich momentum table with price range
    if not momentum_df.empty:
        momentum_df = bridge.enrich_with_price_range(momentum_df)

    # If recovery watchlist is empty but momentum has data, still continue
    if not watchlist and momentum_df.empty:
        print("  WARNING: No stocks passed any filters.")
        print(f"  Try lowering --threshold (current: {recovery_threshold})")
        result["status"] = "empty_watchlist"
        result["watchlist_count"] = 0
        return result
    elif not watchlist:
        print("  NOTE: No recovery candidates, but momentum table has data.")

    # Step 6: Save all outputs (recovery + momentum CSVs + summary JSON)
    print("\n  Saving outputs...")
    saved_paths = bridge.save_outputs(
        ranked_df, watchlist, timestamp, momentum_df=momentum_df,
    )
    result["outputs"] = saved_paths
    result["watchlist_count"] = len(watchlist)
    result["with_apollo_data"] = sum(
        1 for w in watchlist if w.get("has_apollo_data")
    )
    result["momentum_count"] = len(momentum_df) if not momentum_df.empty else 0

    if not dry_run and watchlist:
        print("\n  Updating Apollo my_watchlist.json...")
        wl_path = merge_into_apollo_watchlist(watchlist)
        result["apollo_watchlist"] = wl_path
    elif dry_run:
        print("\n  [DRY RUN] Would update Apollo watchlist (skipped)")

    # Step 7: Save yfinance daily CSVs to data/ for ALL candidates
    # Save for both recovery watchlist AND momentum table stocks
    if not dry_run:
        print(f"\n[7/8] Saving yfinance CSVs to data/ for Apollo...")

        # Build combined list: recovery watchlist + momentum candidates
        all_candidates = list(watchlist)  # recovery stocks
        if not momentum_df.empty:
            for _, row in momentum_df.iterrows():
                sym = row["symbol"]
                # Avoid duplicates
                if not any(w.get("sym", "") == f"{sym}.NS" for w in all_candidates):
                    all_candidates.append({
                        "sym": f"{sym}.NS",
                        "name": row.get("name", sym),
                    })

        yf_sync = save_yfinance_to_data_dir(
            ohlcv_data=ohlcv_data,
            watchlist=all_candidates,
            apollo_data_dir=apollo_data_dir,
            force_refresh=force_refresh,
        )
        result["yfinance_sync"] = yf_sync
    else:
        print(f"\n[7/8] [DRY RUN] Would save yfinance CSVs to data/")
        yf_sync = {}

    # Step 8: Sync eod2 data (if --sync-data provided)
    # This is the SECONDARY bridge — uses your local 3500+ CSVs for deeper history
    if sync_data_dir and not dry_run:
        print(f"\n[8/8] Syncing eod2 CSVs for deeper history...")
        sync_result = sync_eod2_data(
            watchlist=watchlist,
            eod2_dir=sync_data_dir,
            apollo_data_dir=apollo_data_dir,
        )
        result["eod2_sync"] = sync_result
        # eod2 CSVs have more history, so they OVERWRITE the yfinance CSVs
        result["with_apollo_data_after_sync"] = (
            result.get("with_apollo_data", 0)
            + yf_sync.get("created", 0)
            + yf_sync.get("updated", 0)
            + sync_result.get("copied", 0)
        )
    elif sync_data_dir and dry_run:
        print(f"\n[8/8] [DRY RUN] Would sync eod2 CSVs from: {sync_data_dir}")
    else:
        print(f"\n[8/8] EOD2 deep history sync: skipped (use --sync-data for 3500+ CSV archive)")
        result["with_apollo_data_after_sync"] = (
            result.get("with_apollo_data", 0)
            + yf_sync.get("created", 0)
            + yf_sync.get("updated", 0)
        )

    # Summary
    print("\n" + "=" * 60)
    print("  TOP 10 CURATED STOCKS")
    print("=" * 60)
    for w in watchlist[:10]:
        has_csv = (Path(apollo_data_dir) / f"{w['sym'].replace('.NS', '')}.csv").exists()
        flag = "[CSV READY]" if has_csv else "[no CSV]"
        print(
            f"  {w['sym']:<14s} score={w.get('chartink_score', '?'):>5.1f}  "
            f"{w.get('momentum_type', ''):<22s} {flag}"
        )
    print("=" * 60)

    result["status"] = "success"
    return result


# -- CLI ------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="nse-engine",
        description=(
            "NSE Data Engine - RSI dashboard + Gainer scanner "
            "(drop-in replacement for Chartink pipeline)"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\nExamples:
  python -m nse_engine                                     # Full pipeline
  python -m nse_engine --dry-run                          # Preview only
  python -m nse_engine --sync-data "C:\\eod2_data\\daily"    # + copy CSVs for Apollo
  python -m nse_engine --rsi-only                         # RSI dashboard only
  python -m nse_engine --gainers-only                     # Gainers only
  python -m nse_engine --threshold 30 --max 200           # Relaxed filters
  python -m nse_engine --symbols RELIANCE,TCS,INFY        # Custom stock list
  python -m nse_engine --force-refresh                    # Ignore cache

VPS Cron (daily at 3:45 PM IST):
  45 15 * * 1-5 cd /path/to/apollo_engine && \\
    python -m nse_engine --sync-data /path/to/eod2_data/daily >> logs/nse_engine.log 2>&1
""",
    )
    parser.add_argument(
        "--apollo-dir", type=str, default="",
        help="Path to Apollo engine root (auto-detected if inside apollo_engine/)",
    )
    parser.add_argument(
        "--output-dir", type=str, default="",
        help="Output directory (default: nse_output/)",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Analyze but do NOT modify my_watchlist.json",
    )
    parser.add_argument(
        "--rsi-only", action="store_true",
        help="Only run RSI Dashboard scans",
    )
    parser.add_argument(
        "--gainers-only", action="store_true",
        help="Only run NIFTY 500 Gainer scans",
    )
    parser.add_argument(
        "--threshold", type=float, default=40.0,
        help="Min recovery score (0-100, default: 40)",
    )
    parser.add_argument(
        "--top", type=int, default=100,
        help="Max stocks in output watchlist (default: 100)",
    )
    parser.add_argument(
        "--force-refresh", action="store_true",
        help="Ignore cached data, re-download everything",
    )
    parser.add_argument(
        "--symbols", type=str, default="",
        help="Comma-separated list of stock symbols (e.g., RELIANCE,TCS)",
    )
    parser.add_argument(
        "--sync-data", type=str, default="",
        metavar="EOD2_DIR",
        help=(
            "Path to eod2 daily CSV directory. "
            "Copies top watchlist stocks' CSVs into Apollo's data/ "
            "so the full 34-signal engine can analyze them."
        ),
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    symbols = None
    if args.symbols:
        symbols = [s.strip().upper() for s in args.symbols.split(",") if s.strip()]

    result = run_pipeline(
        apollo_dir=args.apollo_dir,
        output_dir=args.output_dir,
        dry_run=args.dry_run,
        rsi_only=args.rsi_only,
        gainers_only=args.gainers_only,
        recovery_threshold=args.threshold,
        max_watchlist=args.top,
        force_refresh=args.force_refresh,
        symbols=symbols,
        sync_data_dir=args.sync_data,
    )

    if result["status"] == "success":
        print(f"\nPipeline completed: {result['watchlist_count']} stocks curated")
        yf = result.get("yfinance_sync", {})
        total_csvs = yf.get("created", 0) + yf.get("updated", 0)
        if total_csvs > 0:
            print(f"  {total_csvs} CSVs saved to data/ (yfinance daily OHLCV)")
        eod2 = result.get("eod2_sync", {})
        if eod2.get("copied", 0) > 0:
            print(f"  {eod2['copied']} CSVs synced from eod2 (deeper history)")
        print(f"  Live Engine: streamlit run live_engine/dashboard.py")
        return 0
    elif result["status"] == "empty_watchlist":
        print(f"\nNo stocks passed filters. Try --threshold 30")
        return 1
    elif result["status"] == "fetch_error":
        print(f"\nData fetch failed. Check internet connection.")
        return 2
    else:
        print(f"\nPipeline finished with status: {result['status']}")
        for err in result.get("errors", []):
            print(f"  Error: {err}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
