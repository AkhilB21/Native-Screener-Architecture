@echo off
title NSE Data Engine - Apollo Watchlist Curation
echo ===================================================
echo   NSE Data Engine v1.2
echo   Fetching OHLCV from yfinance...
echo   CSVs auto-saved to data/ for Live Engine
echo ===================================================
echo.

cd /d "%~dp0"

REM === EOD2 DEEP HISTORY (optional) ===
REM If you have the eod2 project with 3500+ CSVs, uncomment and set this.
REM This gives deeper history (years) vs yfinance's ~2 years.
REM set "EOD2_DIR=C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\eod2-main\eod2-main\src\eod2_data\daily"

if defined EOD2_DIR (
    python -m nse_engine --sync-data "%EOD2_DIR%" %*
) else (
    python -m nse_engine %*
)

if %errorlevel% equ 0 (
    echo.
    echo ===================================================
    echo   DONE! Top stocks saved to data/ folder.
    echo   Start Live Engine:
    echo     python live_engine\run_live.py
    echo   Or directly:
    echo     streamlit run live_engine\dashboard.py
    echo ===================================================
) else (
    echo.
    echo ERROR: Pipeline failed with error code: %errorlevel%
    echo Make sure you have installed requirements:
    echo   pip install -r requirements.txt
    echo.
)
pause
