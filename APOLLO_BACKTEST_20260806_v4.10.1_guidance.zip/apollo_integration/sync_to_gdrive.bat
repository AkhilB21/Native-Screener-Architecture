@echo off
REM ============================================================
REM  Apollo Data Repository → Google Drive Daily Sync
REM ============================================================
REM
REM  SETUP:
REM  1. Install rclone from https://rclone.org/downloads/
REM  2. Run: rclone config  (follow prompts to connect Google Drive)
REM  3. Test manually: python sync_to_gdrive.py --dry-run
REM  4. Set up Windows Task Scheduler to run this .bat daily
REM
REM  TASK SCHEDULER SETUP:
REM  - Open Task Scheduler → Create Basic Task
REM  - Trigger: Daily at your preferred time (e.g. 11:00 PM)
REM  - Action: Start a Program
REM  - Program: path\to\sync_to_gdrive.bat
REM  - Start in: path\to\APOLLO_BACKTEST_...\
REM
REM ============================================================

echo ============================================
echo  Apollo Data Sync to Google Drive
echo  %date% %time%
echo ============================================

REM Navigate to script directory
cd /d "%~dp0"

REM Run the sync (full, not dry-run)
python sync_to_gdrive.py

if %ERRORLEVEL% EQU 0 (
    echo.
    echo Sync completed successfully.
) else (
    echo.
    echo WARNING: Sync had errors. Check sync_logs/ folder.
)

echo.
echo Done at %date% %time%
timeout /t 10
