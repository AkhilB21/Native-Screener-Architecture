"""APOLLO_DATA_REPOSITORY → Google Drive Daily Sync

This script one-way syncs your local APOLLO_DATA_REPOSITORY to Google Drive
using rclone (recommended) as the sync engine.

Why rclone?
    - Handles 15 TB effortlessly
    - Incremental sync (only changed files are uploaded)
    - Preserves folder structure
    - Free, open-source, battle-tested

Setup (one-time, ~5 minutes):
    1. Download rclone: https://rclone.org/downloads/
       - Place rclone.exe in a folder on your PATH (e.g. C:\Tools\rclone\)
    2. Configure Google Drive remote:
         rclone config
       - Choose 'n' (new remote)
       - Name: "gdrive"
       - Storage: "drive" (Google Drive)
       - client_id/secret: leave blank (press Enter)
       - scope: "1" (full access)
       - service_account_file: leave blank
       - Edit advanced config: "n"
       - Use auto config: "y"  (opens browser for OAuth)
       - Configure as team drive: "n"
       - Confirm: "y"
    3. Test the connection:
         rclone ls gdrive:

Daily Automation (Windows Task Scheduler):
    - Use the provided sync_to_gdrive.bat
    - Or create a Scheduled Task that runs daily at a fixed time

Usage:
    python sync_to_gdrive.py                  # Full sync (all subfolders)
    python sync_to_gdrive.py --dry-run        # Preview what would be synced
    python sync_to_gdrive.py --folders output history regime  # Sync specific folders only
"""

from __future__ import annotations

import argparse
import datetime
import logging
import os
import subprocess
import sys
from pathlib import Path

# ── Configuration ──────────────────────────────────────────────────────

# Local APOLLO_DATA_REPOSITORY path
# Change this if your path differs
LOCAL_REPO = r"C:\Users\Akhilesh Bhardwaj\Desktop\Trading App Research\GITHUB DATA SOL\APOLLO_DATA_REPOSITORY"

# rclone remote name (from `rclone config`)
RCLONE_REMOTE = "gdrive"

# Remote folder inside Google Drive (will be created if not exists)
REMOTE_FOLDER = "ApolloDataRepository"

# Folders to sync (relative to LOCAL_REPO)
DEFAULT_FOLDERS = [
    "output",       # trades.parquet, profiles/, aggregation/
    "history",      # backtest_history.db
    "regime",       # regime_daily.parquet
]

# rclone executable (adjust if not on PATH)
RCLONE_CMD = "rclone"

# Logging
LOG_DIR = Path(__file__).parent / "sync_logs"
LOG_FILE = LOG_DIR / f"sync_{datetime.date.today().isoformat()}.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)


# ── Sync Logic ────────────────────────────────────────────────────────

def check_rclone() -> bool:
    """Check if rclone is available on PATH."""
    try:
        result = subprocess.run(
            [RCLONE_CMD, "version"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            logger.info(f"rclone detected: {result.stdout.strip().split(chr(10))[0]}")
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    logger.error(
        f"rclone not found. Please install from https://rclone.org/downloads/ "
        f"and add to PATH."
    )
    return False


def sync_folder(
    local_base: str,
    folder: str,
    remote_target: str,
    dry_run: bool = False,
) -> tuple[bool, str]:
    """Sync a single folder to Google Drive.

    Returns (success, message).
    """
    local_path = Path(local_base) / folder
    if not local_path.exists():
        return True, f"Skipped (not found): {folder}/"

    remote_path = f"{remote_target}/{folder}"

    cmd = [
        RCLONE_CMD, "sync",
        str(local_path),
        remote_path,
        "--progress",
        "--verbose",
        "--transfers", "4",
        "--checkers", "8",
        "--contimeout", "60s",
        "--timeout", "300s",
        "--retries", "3",
        "--low-level-retries", "10",
        # Skip files larger than 50MB from verbose output (not from sync)
        "--stats", "1s",
        "--stats-log-level", "NOTICE",
    ]

    if dry_run:
        cmd.append("--dry-run")

    logger.info(f"Syncing: {local_path} → {remote_path}" + (" [DRY RUN]" if dry_run else ""))

    try:
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=1800,  # 30 min max per folder
        )
        if result.returncode == 0:
            # Parse stats from output
            stats_line = ""
            for line in (result.stderr or "").split("\n"):
                if "Transferred" in line:
                    stats_line = line.strip()
                    break
            msg = f"OK: {folder}/ " + (f"({stats_line})" if stats_line else "")
            logger.info(msg)
            return True, msg
        else:
            err = result.stderr or result.stdout or "Unknown error"
            # Truncate very long errors
            err = err[-500:] if len(err) > 500 else err
            logger.error(f"FAILED: {folder}/ — {err}")
            return False, f"FAILED: {folder}/ — {err}"
    except subprocess.TimeoutExpired:
        logger.error(f"TIMEOUT: {folder}/ (exceeded 30 min)")
        return False, f"TIMEOUT: {folder}/"
    except Exception as e:
        logger.error(f"ERROR: {folder}/ — {e}")
        return False, f"ERROR: {folder}/ — {e}"


def main():
    parser = argparse.ArgumentParser(
        description="Sync APOLLO_DATA_REPOSITORY to Google Drive",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Preview changes without uploading",
    )
    parser.add_argument(
        "--folders", nargs="*", default=DEFAULT_FOLDERS,
        help=f"Folders to sync (default: {' '.join(DEFAULT_FOLDERS)})",
    )
    parser.add_argument(
        "--local-repo", default=LOCAL_REPO,
        help="Path to local APOLLO_DATA_REPOSITORY",
    )
    args = parser.parse_args()

    logger.info("=" * 60)
    logger.info(f"APOLLO_DATA_REPOSITORY → Google Drive Sync")
    logger.info(f"Local:  {args.local_repo}")
    logger.info(f"Remote: {RCLONE_REMOTE}:{REMOTE_FOLDER}")
    logger.info(f"Folders: {args.folders}")
    logger.info(f"Dry run: {args.dry_run}")
    logger.info("=" * 60)

    # Pre-flight checks
    if not Path(args.local_repo).exists():
        logger.error(f"Local repo not found: {args.local_repo}")
        sys.exit(1)

    if not check_rclone():
        sys.exit(1)

    # Ensure log directory exists
    LOG_DIR.mkdir(parents=True, exist_ok=True)

    # Sync each folder
    remote_target = f"{RCLONE_REMOTE}:{REMOTE_FOLDER}"
    results = []
    for folder in args.folders:
        ok, msg = sync_folder(args.local_repo, folder, remote_target, args.dry_run)
        results.append((folder, ok, msg))

    # Summary
    logger.info("=" * 60)
    logger.info("SYNC SUMMARY")
    ok_count = sum(1 for _, ok, _ in results if ok)
    for folder, ok, msg in results:
        status = "✅" if ok else "❌"
        logger.info(f"  {status} {msg}")
    logger.info(f"Result: {ok_count}/{len(results)} folders synced successfully")

    if ok_count < len(results):
        sys.exit(1)


if __name__ == "__main__":
    main()
